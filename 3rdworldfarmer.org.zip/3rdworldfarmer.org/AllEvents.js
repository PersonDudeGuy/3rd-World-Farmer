export default class AllEvents {
	//constructor(){}
	constructor(lang){

	this.lang = lang;

	this.AnnualEvents = { 
		AngryMobEvent: {
		    image: "angryMob",
		    title: lang.angryMobEventTitle,
		    description: lang.angryMobEvDe,
		    secDescription: lang.angryMobEvDe2nd,
		    shortname: "mob"
		}, 
		BushFireEvent: {
		    image: "bushFire",
		    title: lang.bushFireEventTitle,
		    description: lang.bushFireEvDe,
		    secDescription: lang.bushFireEvDe2nd,
		    shortname: "fire"
		},
		CattleDiseaseEvent: {
		    image: "cattleDisease",
		    title: lang.cattleDiseaseEventTitle,
		    description: lang.cattleDiseaseEvDe,
		    secDescription: lang.cattleDiseaseEvDe2nd,
		    shortname: "cow"
		  },
		  ChickenDiseaseEvent: {
		    image: "chickenDisease",
		    title: lang.chickenDiseaseEventTitle,
		    description: lang.chickenDiseaseEvDe,
		    secDescription: lang.chickenDiseaseEvDe2nd,
		    shortname: "chicken"
		  },
		  CivilWarEvent: {
		    image: "civilWar",
		    title: lang.civilWarEventTitle,
		    description: lang.civilWarEvDe,
		    secDescription: lang.civilWarEvDe2nd,
		    shortname: "civilwar"
		  },
		  CornFailedEvent: {
		    image: "cornFailed",
		    title: lang.cornFailedEventTitle,
		    description: lang.cornFailedEvDe,
		    secDescription: lang.cornFailedEvDe2nd,
		    shortname: "corn"
		  },
		  CorruptOfficialsEvent: {
		    image: "corruptOfficials",
		    title: lang.corruptOfficialsEventTitle,
		    description:  lang.corruptOfficialsEvDe,
		    secDescription: lang.corruptOfficialsEvDe2nd,
		    shortname: "corrupt"
		  },
		  CottonFailedEvent: {
		    image: "cottonFailed",
		    title: lang.cottonFailedEventTitle,
		    description: lang.cottonFailedEvDe,
		    secDescription: lang.cottonFailedEvDe2nd,
		    shortname: "cotton"
		  },
		  DrySeasonEvent: {
		    image: "drySeason",
		    title: lang.drySeasonEventTitle,
		    description: lang.drySeasonEvDe,
		    secDescription: lang.drySeasonEvDe2nd,
		    shortname: "Crop"
		  },
		  ElephantPoachersEvent: {
		    image: "elephantPoachers",
		    title: lang.elephantPoachersEventTitle,
		    description: lang.elephantPoachersEvDe,
		    secDescription: lang.elephantPoachersEvDe2nd,
		    shortname: "elephant"
		  },
		  GoodSeasonEvent: {
		    image: "goodSeason",
		    title: lang.goodSeasonEventTitle,
		    description: lang.goodSeasonEvDe,
		    secDescription: lang.goodSeasonEvDe2nd,
		    shortname: "Good"
		  },
		  GuerillasEvent: {
		    image: "guerillas",
		    title: lang.guerillasEventTitle,
		    description: lang.guerillasEvDe,
		    secDescription: lang.guerillasEvDe2nd,
		    shortname: "guerillas"
		  },
		  MarketPricesEvent: {
		    image: "marketPrices",
		    title: lang.marketPricesEventTitle,
		    description: lang.marketPricesEvDe,
		    secDescription: lang.marketPricesEvDe2nd,
		    shortname: "marketprices"
		  },
		  NationalBankEvent: {
		    image: "nationalBank",
		    title: lang.nationalBankEventTitle,
		    description: lang.nationalBankEvDe,
		    secDescription: lang.nationalBankEvDe2nd,
		    shortname: "nationalbank"
		  },
		  PeanutFailedEvent: {
		    image: "peanutFailed",
		    title: lang.peanutFailedEventTitle,
		    description: lang.peanutFailedEvDe,
		    secDescription: lang.peanutFailedEvDe2nd,
		    shortname: "peanut"
		  },
		  PigDiseaseEvent: {
		    image: "pigDisease",
		    title: lang.pigDiseaseEventTitle,
		    description: lang.pigDiseaseEvDe,
		    secDescription: lang.pigDiseaseEvDe2nd,
		    shortname: "pig"
		  },
		  RefugeesEvent: {
		    image: "refugees",
		    title: lang.refugeesEventTitle,
		    description: lang.refugeesEvDe,
		    secDescription: lang.refugeesEvDe2nd ,
		    shortname: "Livestock"
		  },
		  SicknessEvent: {
		    image: "sickness",
		    title: lang.sicknessEventTitle,
		    description: lang.sicknessEvDe,
		    secDescription: lang.sicknessEvDe2nd,
		    shortname: "sickness"
		  },
		  TheftEvent: {
		    image: "theft",
		    title: lang.theftEventTitle,
		    description: lang.theftEvDe,
		    secDescription: lang.theftEvDe2nd,
		    shortname: "theft"
		  },
		  VeryGoodSeasonEvent: {
		    image: "veryGoodSeason",
		    title: lang.veryGoodSeasonEventTitle,
		    description: lang.veryGoodSeasonEvDe,
		    secDescription: lang.veryGoodSeasonEvDe2nd,
		    shortname: "veryGood"
		  },
		  WellCavesInEvent: {
		    image: "wellCavesIn",
		    title: lang.wellCavesInEventTitle,
		    description: lang.wellCavesInEvDe,
		    secDescription: lang.wellCavesInEvDe2nd,
		    shortname: "wellscavein"
		  },
		  WheatFailedEvent: {
		    image: "wheatFailed",
		    title: lang.wheatFailedEventTitle,
		    description: lang.wheatFailedEvDe,
		    secDescription: lang.wheatFailedEvDe2nd,
		    shortname: "wheat"
		  }
		};
	}
	
}