/**
This is just an attempt at including and exporting all the different Investment types and investments in one file.
	
	Investment, Crop, Livestock, Tool, Construction, Project,
    Corn, Wheat, Cotton, Peanut, Poppy, 
    Chicken, Pig, Cow, Elephant,
    Shovel, Scythe, Plow, Tractor, Harvester,
    Shed, Well, Barn,
    Communications, Infrastructure, Clinic, School, Representative, Insurance

*/

// The base Invstement class
export class Investment {
	constructor(){
		//console.log("Investment constructor()");
		this.categoryName = '';
		this.linkageName = '';
		this.price = 0;
		this.multiplier = 1.0;
		this.amount = 0; // only used for limited crops, poppies
		this.positionMC = null;
		this.clickPositionX = 0;
		this.clickPositionY = 0;
		this.hasTweened = false;
	}	

	setLinkageName(linkageName){
		this.linkageName = linkageName;
	}
		
	getLinkageName(){
		return this.linkageName;
	}

	setCategoryName(s){
		this.categoryName = s;
	}

	getCategoryName() {
		return this.categoryName;
	}

	setPrice(i){
		this.price = i;
	}

	getPrice(){
		return this.price;
	}

	setMultiplier(f){
		this.multiplier = f;
	}

	getMultiplier(){
		return this.multiplier;
	}

	setPositionMC(p){
		this.positionMC = p;
	}
		
	getPositionMC(){
		return this.positionMC;
	}

	setClickPosition(x, y){
		this.clickPositionX = x;
		this.clickPositionY = y;
	};

	set amount(newAmount){
		this._amount = newAmount;
	}

	get amount(){
		return this._amount;
	}
}

// The investment types
export class Crop extends Investment{
	constructor(){
		super();
		this.setCategoryName("Crop");
	}
}

export class Livestock extends Investment{
	constructor(){
		super();
		this.setCategoryName("Livestock");
	}
}

export class Tool extends Investment{
	constructor(){
		super();
		this.setCategoryName("Tool");
	}
}

export class Construction extends Investment{
	constructor(){
		super();
		this.setCategoryName("Construction");
	}
}

export class Project extends Investment{
	constructor(){
		super();
		this.setCategoryName("Project");
	}
}

// The individual investments

export class Barn extends Construction {
	constructor(price, multiplier){
		super();
		this.setLinkageName('barn');
		this.setPrice(price);
		this.setMultiplier(multiplier);
	}
}

export class Chicken extends Livestock {
	constructor(price, multiplier){
		super();
		this.setLinkageName('chicken');
		this.setPrice(price);
		this.setMultiplier(multiplier);
	}
}

export class Clinic extends Project {
	constructor(price, multiplier){
		super();
		this.setLinkageName('clinic');
		this.setPrice(price);
		this.setMultiplier(multiplier);
	}
}


export class Communications extends Project {
	constructor(price, multiplier){
		super();
		this.setLinkageName('communications');
		this.setPrice(price);
		this.setMultiplier(multiplier);
	}
}

export class Corn extends Crop {
	constructor(price, multiplier){
		super();
		this.setLinkageName('corn');
		//console.log('Corn constructor, args', price, multiplier)
		this.setPrice(price);
		this.setMultiplier(multiplier);
	}
}

export class Cotton extends Crop {
	constructor(price, multiplier){
		super();
		this.setLinkageName('cotton');
		this.setPrice(price);
		this.setMultiplier(multiplier);
	}
}

export class Cow extends Livestock {
	constructor(price, multiplier){
		super();
		this.setLinkageName('cow');
		this.setPrice(price);
		this.setMultiplier(multiplier);
		
	}
}

export class Elephant extends Livestock {
	constructor(price, multiplier){
		super();
		this.setLinkageName('elephant');
		this.setPrice(price);
		this.setMultiplier(multiplier);
	}
}

export class Harvester extends Tool {
	constructor(price, multiplier){
		super();
		this.setLinkageName('harvester');
		this.setPrice(price);
		this.setMultiplier(multiplier);
	}
}

export class Infrastructure extends Project {
	constructor(price, multiplier){
		super();
		this.setLinkageName('infrastructure');
		this.setPrice(price);
		this.setMultiplier(multiplier);
	}
}

export class Insurance extends Project {
	constructor(price, multiplier){
		super();
		this.setLinkageName('insurance');
		this.setPrice(price);
		this.setMultiplier(multiplier);
	}
}

export class Expansion extends Project {
	constructor(price, multiplier){
		super();
		this.setLinkageName('expansion');
		this.setPrice(price);
		this.setMultiplier(multiplier);
	}
}

export class Peanut extends Crop {
	constructor(price, multiplier){
		super();
		this.setLinkageName('peanut');
		this.setPrice(price);
		this.setMultiplier(multiplier);
	}
}

export class Plow extends Tool {
	constructor(price, multiplier){
		super();
		this.setLinkageName('plow');
		this.setPrice(price);
		this.setMultiplier(multiplier);
	}
}

export class Poppy extends Crop {
	constructor(price, multiplier){
		super();
		this.setLinkageName('poppy');
		this.setPrice(price);
		this.setMultiplier(multiplier);
	}
}

export class Pig extends Livestock {
	constructor(price, multiplier){
		super();
		this.setLinkageName('pig');
		this.setPrice(price);
		this.setMultiplier(multiplier);
	}
}

export class School extends Project {
	constructor(price, multiplier){		
		super();
		this.setLinkageName('school');
		this.setPrice(price);
		this.setMultiplier(multiplier);
	}
}

export class Representative extends Project {
	constructor(price, multiplier){
		super();
		this.setLinkageName('representative');
		this.setPrice(price);
		this.setMultiplier(multiplier);
	}
}

export class Scythe extends Tool {
	constructor(price, multiplier){
		super();
		this.setLinkageName('scythe');
		this.setPrice(price);
		this.setMultiplier(multiplier);
	}
}

export class Shovel extends Tool {
	constructor(price, multiplier){
		super();
		this.setLinkageName('shovel');
		this.setPrice(price);
		this.setMultiplier(multiplier);
	}
}

export class Shed extends Construction {
	constructor(price, multiplier){
		super();
		this.setLinkageName('shed');
		this.setPrice(price);
		this.setMultiplier(multiplier);
	}
}

export class Tractor extends Tool {
	constructor(price, multiplier){
		super();
		this.setLinkageName('tractor');
		this.setPrice(price);
		this.setMultiplier(multiplier);
	}
}

export class Well extends Construction {
	constructor(price, multiplier){
		super();
		this.setLinkageName('well');
		this.setPrice(price);
		this.setMultiplier(multiplier);
	}
}

export class Wheat extends Crop {
	constructor(price, multiplier){
		super();
		this.setLinkageName('wheat');
		this.setPrice(price);
		this.setMultiplier(multiplier);
	}
}
