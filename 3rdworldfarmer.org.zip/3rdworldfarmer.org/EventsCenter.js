// https://blog.ourcade.co/posts/2020/phaser3-how-to-communicate-between-scenes/
// import Phaser from 'phaser'
const eventsCenter = new Phaser.Events.EventEmitter()
export default eventsCenter

// Since event emitters and listeners are added in many different files, I'll list them centrally here in comments for easier searching.

/*

* 'paint-family' emitted by [FarmModel] listened to by [FamilyView].
* 'request-sellinfo-data' emitted by [SellInfoBox] listened to by [playGame]
* 'submit-sellinfo-data' emitted by [playGame] listened to by [SellInfoBox]
* 'close-sellinfobox' emitted by [SellInfoBox] listened to by [playGame]
* 'menu-item-clicked' emitted by [MenuChoices] listened to by [playGame]
* 'project-item-clicked' emitted by [MenuChoices] listened to by [playGame]

* 'update-projectinfobox' emitted by [playGame] listened to by [ProjectInfoBox]

* 'paint-investments' emitted by [FarmModel] listened to by [InvestmentsView]

* 'paint-labels-and-projects' emitted by [FarmModel] listened to by [playGame]
* 'handle-buy-project-button' emitted by [ItemDetails] listened to by [playGame]
* 'sell-item' emitted by [SellInfoBox] listened to by [playGame]

* 'clicked-family-member' emitted by [FamilyView] listened to by [playGame]

* 'clicked-go-to-school' emitted by [FamilyMemberInfoBox] listened to by [playGame]
* 'closed-go-to-school-infobox' emitted by [GoToSchoolInfoBox] listened to by [playGame]
* 'accept-school' emitted by [GoToSchoolInfoBox] listened to by [playGame]

* 'clicked-have-baby' emitted by [FamilyMemberInfoBox] listened to by [playGame]
* 'closed-have-baby-infobox' emitted by [HaveBabyInfoBox] listened to by [playGame]

* 'clicked-appoint-family-head' emitted by [FamilyMemberInfoBox] listened to by [playGame]
* 'closed-family-head-infobox' emitted by [FamilHeadInfoBox] listened to by [playGame]
* 'accept-family-head' emitted by [FamilyHeadInfoBox] listened to by [playGame]

* 'clicked-leave-farm' emitted by [FamilyMemberInfoBox] listened to by [playGame]
* 'closed-leave-farm-infobox' emitted by [LeaveFarmInfoBox] listened to by [playGame]
* 'leave-farm-accepted' emitted by [LeaveFarmInfoBox] listened to by [playGame]
* 'game-over' emitted by [LeaveFarmInfoBox] listened to by [playGame]

* 'clicked-marry' emitted by [FamilyMemberInfoBox] listened to by [playGame]
* 'closed-marriage-infobox' emitted by [MarriageInfoBox] listened to by [playGame]
* 'marrige-accepted' emitted by [MarriageInfoBox] listened to by [playGame]

* 'clicked-give-medicine' emitted by [FamilyMemberInfoBox] listened to by [playGame]
* 'heal-me-one-unit' emitted by [FamilyMemberInfoBox] listened to by [playGame]
* 'heal-me-fully' emitted by [FamilyMemberInfoBox] listened to by [playGame]
* 'heal-whole-family' emitted by [FamilyMemberInfoBox] listened to by [playGame]
* 'closed-give-medicine-infobox' emitted by [GiveMedicineInfoBox] listened to by [playGame]

* 'clicked-help' emitted by [FamilyMemberInfoBox] listened to by [playGame]
* 'closed-family-help' emitted by [FamilyHelp] listened to by [playGame]

* 'warned-and-built' emitted by [WarningBox] listened to by [playGame]
* 'closed-warning-box' emitted by [WarningBox] listened to by [playGame]

* 'closed-family-member-info-box' emitted by [FamilyMemberInfoBox] listened to by [playGame]

* 'closed-io-box' emitted by [IOBox] listened to by [playGame]

* 'broke-event-accepted' emitted by [BrokeInfoBox] listened to by [playGame]
* 'broke-event-declined' emitted by [BrokeInfoBox] listened to by [playGame]

* 'night-anim-complete' emitted by [nightScene] listened to by [playGame]

* 'submit-score-intent' emitted by [GameOverScreen] listened to by [playGame];
* 'clicked-submit-name' emitted by [NamePrompt] listened to by [playGame];

*/