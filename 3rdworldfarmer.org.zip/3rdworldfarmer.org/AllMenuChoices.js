import eventsCenter from './EventsCenter.js';

/**
	This file exports menuChoices base class and the subclasses used for left side menues: 
	CropMenuChoices, LivestockMenuChoices, ToolMenuChoices, ConstructionMenuChoices and ProjectMenuChoices.

*/

export class MenuChoices extends Phaser.Scene{
	constructor(){
		super();
	}	

	create(){
        // Create and hide the buttons for this menu
        for (var i =0; i < this.buttons.length; i++){
        	this.createSingleButton(i);
        }
	}

	expand(){
		// Repeatedly call showSingleButton in order to animate menu rolling out with each button it contains.
		this.timedEvent = this.time.addEvent({ delay: 150, callback: this.showSingleButton, callbackScope: this, repeat: this.buttons.length-1 });
	}

	// Creates a single button (based on timedEvent.repeatCount) and stores it's elements in relevant object in this.buttons array.
	createSingleButton(i){
		// Add brown connector line between menu items.
		this.buttons[i].brown = this.add.image(this.data.x + (i*55) + 0, this.data.y + 28, 'atlas', 'brownSquare').setDisplaySize(20,4).setVisible(false);

		// Add background graphic for menu item.
		this.buttons[i].bg = this.add.image(this.data.x + (i * 55), this.data.y + 0, 'atlas', 'menu-choice-button-bg').setOrigin(0,0).setVisible(false);
		this.buttons[i].bg.on('pointerdown', this.handleButtonClick.bind(this, this.buttons[i]));

		// Add pricelabel textfield.
		this.buttons[i].tf = this.add.text(this.data.x + (i*55) + 9, this.data.y + 6, '$ 25', { fontSize: 12, fontFamily: 'Arial', color: '#000000'}).setVisible(false);
		
		// Add icon graphic of the specific type of item 
		this.buttons[i].icon = this.add.image(this.data.x + (i * 55) + this.buttons[i].x, this.data.y + this.buttons[i].y, 'atlas', this.buttons[i].picName).setOrigin(0,0).setDisplaySize(this.buttons[i].w,this.buttons[i].h).setVisible(false);
		
		// Add grey overlay 
		this.buttons[i].gray = this.add.image(this.data.x + (i * 55), this.data.y + 8, 'atlas', 'menu-choice-button-grayout').setOrigin(0,0).setVisible(false);

		if (this.isProjectMenu) this.createGreenCheckmark(i);
	}

	showSingleButton(){
		var i = this.buttons.length - this.timedEvent.repeatCount -1;

		// Set a flag to indicate menu is fully expanded after last repeat.
		if (this.timedEvent.repeatCount == 0){
			this.expanded = true;
		}

		// Only show poppybutton if main.poppyAMount is larger than 0.
		if (this.buttons[i].name == 'poppy'){
			//console.log('poppyamount:', this.data.main.poppyAmount);
			if (this.data.main.poppyAmount <= 0){
				return;
			}
		}

		// Add brown connector line between menu items.
		this.buttons[i].brown.setVisible(true);

		// Add background graphic for menu item.
		this.buttons[i].bg.setVisible(true).setInteractive({useHandCursor:true});

		// Add pricelabel textfield.
		this.setPriceLabelText(this.buttons[i]);
		this.buttons[i].tf.setVisible(true);
		
		// Add icon graphic of the specific type of item 
		this.buttons[i].icon.setVisible(true);
		
		// Add grey overlay 
		this.buttons[i].gray.setVisible(this.buttons[i].grayVis); 

		if (this.isProjectMenu) {
			this.buttons[i].green.setVisible(this.buttons[i].greenVis);
		}
	}

	contract(){
		// This hides/disable the menu again.
		this.time.removeAllEvents();

		for (var i=0; i< this.buttons.length; i++){
			this.buttons[i].brown.setVisible(false);
			this.buttons[i].bg.setVisible(false).disableInteractive();
			this.buttons[i].tf.setVisible(false);
			this.buttons[i].icon.setVisible(false);			
			this.buttons[i].gray.setVisible(false); 
			if (this.isProjectMenu){
				this.buttons[i].green.setVisible(false); 
			}
		}
		this.expanded = false;
	}

	getButton(name){
		for (var i of this.buttons){
			if (i.name == name) return i;
		}
	}

	updateButtonPrices(){
		for (var i of this.buttons){
			if ('tf' in i){
				this.setPriceLabelText(i);
			}
		}
	}

	setPriceLabelText(but){
		var t; 
		if (but.price < 10) { t = '$  ' + but.price; }
		else if (but.price < 100) { t = '$ ' + but.price; }
		else { t = '$' + but.price; }

		if (but.name == 'poppy') { t = '   ' + this.data.main.poppyAmount; }
		if ('tf' in but){
			but.tf.setText(t);
		}
	}

	setGrayVisible(but, vis){
		but.grayVis = vis;
		// Neccessary to check if the gray overlay has been created, before we try to update it's visibility.
		if ('gray' in but){
			// Only change visibility of gray overlay if button's background is also visible, or the gray will appear despite menu being contracted.
			if (but.bg.visible){
				but.gray.setVisible(vis);
			}
		}
	}

	handleButtonClick(pointer, what){
		// Click on project menu items are handled differently from other items, since they require a confirmation click to be purchased and are not placed on their corresponding tiles.
		if (this.isProjectMenu){
			eventsCenter.emit('project-item-clicked', pointer);
		} else {
			eventsCenter.emit('menu-item-clicked', pointer);
		}
	}
}

// Export the subclasses

export class CropMenuChoices extends MenuChoices {
	constructor(){
		super('CropMenuChoices');
	}

	init(data){		
		// Config object for the individual buttons in this Menu
		this.buttons = [ { name: 'corn', picName: 'crop-corn-small', x: 14, y: 15, w: 18, h: 30},
						 { name: 'wheat', picName: 'crop-wheat-small', x: 16, y: 15, w: 15, h: 30},
						 { name: 'cotton', picName: 'crop-cotton-small', x: 7, y: 16, w: 33, h: 30},
						 { name: 'peanut', picName: 'crop-peanut-small', x: 14, y: 17, w: 22, h: 27},
						 { name: 'poppy', picName: 'crop-poppy-small', x: 16, y: 15, w: 18, h: 30}
					   ];
		this.data = data;
		this.expanded = false;
	}	
}

export class LivestockMenuChoices extends MenuChoices {
	constructor(){
		super('LivestockMenuChoices');
	}
	
	init(data){		
		// Config object for the individual buttons in this Menu
		this.buttons = [ { name: 'chicken', picName: 'livestock-chicken-small', x: 12, y: 14, w: 25, h: 32},
						 { name: 'pig', picName: 'livestock-pig-small', x: 8, y: 14, w: 36, h: 32},
						 { name: 'cow', picName: 'livestock-cow-small', x: 9, y: 14, w: 32, h: 32},
						 { name: 'elephant', picName: 'livestock-elephant-small', x: 9, y: 15, w: 37, h: 30},
					   ];
		this.data = data;
		this.expanded = false;
	}
}

export class ToolMenuChoices extends MenuChoices {
	constructor(){
		super('ToolMenuChoices');
	}
	
	init(data){		
		// Config object for the individual buttons in this Menu
		this.buttons = [ { name: 'shovel', picName: 'tool-shovel-small', x: 18, y: 12, w: 14, h: 33},
						 { name: 'scythe', picName: 'tool-scythe-small', x: 16, y: 15, w: 18, h: 30},
						 { name: 'plow', picName: 'tool-plow-small', x: 6, y: 15, w: 33, h: 28},
						 { name: 'tractor', picName: 'tool-tractor-small', x: 8, y: 17, w: 33, h: 26},
						 { name: 'harvester', picName: 'tool-harvester-small', x: 8, y: 23, w: 33, h: 17},
					   ];
		this.data = data;
		this.expanded = false;
	}
}

export class ConstructionMenuChoices extends MenuChoices {
	constructor(){
		super('ConstructionMenuChoices');
	}

	init(data){		
		// Config object for the individual buttons in this Menu
		this.buttons = [ { name: 'shed', picName: 'construction-shed-small', x: 6, y: 17, w: 35, h: 29},
						 { name: 'well', picName: 'construction-well-small', x: 7, y: 17, w: 35, h: 24},
						 { name: 'barn', picName: 'construction-barn-small', x: 6, y: 17, w: 36, h: 27},
					   ];
		this.data = data;
		this.expanded = false;
	}
}

export class ProjectMenuChoices extends MenuChoices {
	constructor(){
		super('ProjectMenuChoices');
	}
	
	init(data){		
		// Config object for the individual buttons in this Menu
		this.buttons = [ { name: 'communications', picName: 'project-communications-small', x: 9, y: 10, w: 36, h: 36},
						 { name: 'infrastructure', picName: 'project-infrastructure-small', x: 6, y: 13, w: 35, h: 35},
						 { name: 'school', picName: 'project-school-small', x: 8, y: 18, w: 32, h: 32},
						 { name: 'clinic', picName: 'project-clinic-small', x: 12, y: 17, w: 25, h: 25},
						 { name: 'representative', picName: 'project-representative-small', x: 11, y: 16, w: 27, h: 27},
						 { name: 'insurance', picName: 'project-insurance-small', x: 11, y: 16, w: 27, h: 27},
						 { name: 'expansion', picName: 'project-insurance-small', x: 13, y: 16, w: 27, h: 27},
					   ];
		this.data = data;
		this.expanded = false;
		this.isProjectMenu = true;
	}

	// Project menu choice buttons are special since they can also have a green checkmark overlay to indicate a project has been purchased. 
	// The createGreenCheckmark() function is called from superclasses' createSingleButton function, but is defined here.
	createGreenCheckmark(i){
		this.buttons[i].green = this.add.image(this.data.x + 15 + (i*55), this.data.y + 8 + 14, 'atlas','greencheck').setOrigin(0,0).setScale(0.65).setVisible(false);
	}

	setGreenVisible(but, vis){
		but.greenVis = vis;
		// Neccessary to check if the green checkmark has been created, before we try to update it's visibility.
		if ('green' in but){
			// Only change visibility of green checkmark if button's background is also visible, or the green will appear despite menu being contracted.
			if (but.bg.visible){
				but.green.setVisible(vis);
			}
		}
	}
}