import Language from './Language.js';
import eventsCenter from './EventsCenter.js';
import AllEvents from './AllEvents.js';
import {FarmModel, Person} from './FarmModel.js';
import {MenuChoices, CropMenuChoices, LivestockMenuChoices, ToolMenuChoices, ConstructionMenuChoices, ProjectMenuChoices} from './AllMenuChoices.js';
import {Investment, Crop, Livestock, Tool, Construction, Project, Corn, Wheat, Cotton, Peanut, Poppy, Chicken, Pig, Cow, Elephant, Shovel, Scythe, Plow, Tractor, Harvester, Shed, Well, Barn, Communications, Infrastructure, Clinic, School, Representative, Insurance, Expansion} from './AllInvestments.js';
let gameOptions = {
    language: new Language(),
    currentLanguage: 'flag_en',
    changeLanguage: function(newLang) {
        this.currentLanguage = newLang;
        this.language.setLanguage(newLang)
    }
};
let main = {};
let farmModel = {};
let game;
window.onload = function() {
    let gameConfig = {
        type: Phaser.AUTO,
        scale: {
            mode: Phaser.Scale.NO_SCALE,
            parent: 'thegame',
            width: 960,
            height: 520
        },
        audio: {
            noAudio: true
        },
        render: {
            pixelArt: false
        },
        backgroundColor: "#000818",
        plugins: {
            global: [NineSlice.Plugin.DefaultCfg]
        },
        parent: 'thegame',
        dom: {
            createContainer: true
        },
        scene: [preloadGame, playGame]
    };
    game = new Phaser.Game(gameConfig);
    window.focus()
}
;
class preloadGame extends Phaser.Scene {
    constructor() {
        super("PreloadGame");
        this.flagButtons = []
    }
    preload() {
        var progressBar = this.add.graphics();
        var progressBox = this.add.graphics();
        progressBox.fillStyle(0x4c443e, 0.8);
        progressBox.fillRect(960 / 2 - 320 / 2, 270, 320, 50);
        var width = this.cameras.main.width;
        var height = this.cameras.main.height;
        var loadingText = this.make.text({
            x: width / 2 - 30,
            y: height / 2 - 50,
            text: 'Loading...',
            style: {
                font: '18px Neuton',
                fill: '#ffff00'
            }
        });
        loadingText.setOrigin(0, 0.5);
        var percentText = this.make.text({
            x: width / 2,
            y: height / 2 - 5,
            text: '0%',
            style: {
                font: '16px monospace',
                fill: '#dddddd'
            }
        });
        percentText.setOrigin(0.5, 0.5);
        this.load.on('progress', function(value) {
            percentText.setText(parseInt(value * 100) + '%');
            progressBar.clear();
            progressBar.fillStyle(0xc7b8a7, 1);
            progressBar.fillRect(960 / 2 - 300 / 2, 280, 300 * value, 30)
        });
        var timedEvent = this.time.addEvent({
            delay: 300,
            callback: this.updateLoadingText,
            args: [loadingText],
            callbackScope: this,
            repeat: -1
        });
        this.timedEvent = timedEvent;
        this.load.on('complete', function() {
            progressBar.destroy();
            progressBox.destroy();
            loadingText.destroy();
            percentText.destroy();
            timedEvent.remove()
        });
        this.load.atlas('atlas', 'TexturePackerPr-0.png', 'TexturePackerPr.json')
    }
    updateLoadingText(t) {
        var dots = 3 - this.timedEvent.repeatCount % 4;
        var d = [[''], ['.'], ['..'], ['...']];
        t.setText('Loading' + d[dots])
    }
    create() {
        this.textures.addSpriteSheetFromAtlas('flag_en', {
            atlas: 'atlas',
            frame: 'englishButton',
            frameWidth: 56,
            frameHeight: 40,
            endFrame: 3
        });
        this.textures.addSpriteSheetFromAtlas('flag_es', {
            atlas: 'atlas',
            frame: 'spanishButton',
            frameWidth: 56,
            frameHeight: 40,
            endFrame: 3
        });
        this.textures.addSpriteSheetFromAtlas('flag_da', {
            atlas: 'atlas',
            frame: 'danishButton',
            frameWidth: 56,
            frameHeight: 40,
            endFrame: 3
        });
        this.textures.addSpriteSheetFromAtlas('flag_cz', {
            atlas: 'atlas',
            frame: 'czechButton',
            frameWidth: 56,
            frameHeight: 40,
            endFrame: 3
        });
        this.textures.addSpriteSheetFromAtlas('flag_fr', {
            atlas: 'atlas',
            frame: 'frenchButton',
            frameWidth: 56,
            frameHeight: 40,
            endFrame: 3
        });
        this.textures.addSpriteSheetFromAtlas('flag_it', {
            atlas: 'atlas',
            frame: 'italianButton',
            frameWidth: 56,
            frameHeight: 40,
            endFrame: 3
        });
        this.textures.addSpriteSheetFromAtlas('flag_de', {
            atlas: 'atlas',
            frame: 'germanButton',
            frameWidth: 56,
            frameHeight: 40,
            endFrame: 3
        });
        this.textures.addSpriteSheetFromAtlas('flag_hu', {
            atlas: 'atlas',
            frame: 'hungarianButton',
            frameWidth: 56,
            frameHeight: 40,
            endFrame: 3
        });
        this.textures.addSpriteSheetFromAtlas('flag_pt', {
            atlas: 'atlas',
            frame: 'brazilianButton',
            frameWidth: 56,
            frameHeight: 40,
            endFrame: 3
        });
        this.textures.addSpriteSheetFromAtlas('flag_ch', {
            atlas: 'atlas',
            frame: 'chineseButton',
            frameWidth: 56,
            frameHeight: 40,
            endFrame: 3
        });
        this.textures.addSpriteSheetFromAtlas('flag_tr', {
            atlas: 'atlas',
            frame: 'turkishButton',
            frameWidth: 56,
            frameHeight: 40,
            endFrame: 3
        });
        this.textures.addSpriteSheetFromAtlas('playButton', {
            atlas: 'atlas',
            frame: 'playButton-001',
            frameWidth: 125,
            frameHeight: 56,
            endFrame: 4
        });
        this.textures.addSpriteSheetFromAtlas('tile', {
            atlas: 'atlas',
            frame: 'tile-arrow',
            frameWidth: 16,
            frameHeight: 23
        });
        this.textures.addSpriteSheetFromAtlas('person', {
            atlas: 'atlas',
            frame: 'person',
            frameWidth: 44,
            frameHeight: 96
        });
        this.textures.addSpriteSheetFromAtlas('sell_green_button', {
            atlas: 'atlas',
            frame: 'sell_green_button',
            frameWidth: 40,
            frameHeight: 40
        });
        this.bg = this.add.image(0, 0, 'atlas', 'startmenu-background').setOrigin(0);
        this.bg_tutorial = this.add.image(0, 0, 'atlas', 'startmenu-tutorial-background').setOrigin(0).setDepth(-1);
        let flags = ['flag_en', 'flag_es', 'flag_da', 'flag_cz', 'flag_fr', 'flag_it', 'flag_de', 'flag_hu', 'flag_pt', 'flag_ch', 'flag_tr'];
        for (let i = 0; i < flags.length; i++) {
            var flag = this.add.sprite(430 + (i * 50), 53, flags[i]).setDisplaySize(47, 33.5).setInteractive({
                useHandCursor: true
            }).setName(flags[i]);
            flag.on('pointerdown', this.onFlagButtonDown.bind(flag));
            flag.on('pointerover', this.onFlagButtonOver.bind(flag));
            flag.on('pointerout', this.onFlagButtonOut.bind(flag));
            this.flagButtons.push(flag)
        }
        this.flagButtons[0].setFrame(2);
        this.facebookButton = this.add.image(800, 80, 'atlas', 'facebookButton').setOrigin(0, 0).setInteractive({
            useHandCursor: true
        });
        this.facebookButton.on('pointerup', function(pointer) {
            var url = 'https://www.facebook.com/3rdworldfarmer/';
            var s = window.open(url, '_blank');
            if (s && s.focus) {
                s.focus()
            } else if (!s) {}
        });
        this.tagBox = this.add.text(484, 242, gameOptions.language.tagLine, {
            fontFamily: 'Neuton',
            fontSize: 28,
            color: '#ffff00'
        }).setShadow(2, 2, "#333333", 2, false, true);
        this.endureBox = this.add.text(25, 327, gameOptions.language.endure, {
            fontFamily: 'Neuton',
            fontSize: 38,
            color: '#ffff00'
        }).setShadow(2, 2, "#333333", 2, false, true);
        this.tf0 = this.add.text(27, 85, gameOptions.language.HelpText0, {
            fontFamily: 'Neuton',
            fontSize: 55,
            color: '#ffffff'
        }).setShadow(2, 2, "#222222", 2, false, true).setVisible(false);
        this.tf1 = this.add.text(114 + 26, 113 + 66, gameOptions.language.HelpText1, {
            fontFamily: 'Neuton',
            fontSize: 32,
            color: '#ffffff'
        }).setShadow(2, 2, "#222222", 2, false, true).setVisible(false);
        this.tf2 = this.add.text(114 + 26, 216 + 66, gameOptions.language.HelpText2, {
            fontFamily: 'Neuton',
            fontSize: 32,
            color: '#ffffff'
        }).setShadow(2, 2, "#222222", 2, false, true).setVisible(false);
        this.tf3 = this.add.text(114 + 26, 319 + 66, gameOptions.language.HelpText3, {
            fontFamily: 'Neuton',
            fontSize: 32,
            color: '#ffffff'
        }).setShadow(2, 2, "#222222", 2, false, true).setVisible(false);
        this.tf4 = this.add.text(364 + 26, 319 + 66, gameOptions.language.HelpText4, {
            fontFamily: 'Neuton',
            fontSize: 32,
            color: '#ffffff'
        }).setShadow(2, 2, "#222222", 2, false, true).setVisible(false);
        this.tf5 = this.add.text(122 + 26, 393 + 66, gameOptions.language.HelpText5, {
            fontFamily: 'Neuton',
            fontSize: 25,
            color: '#ffffff',
            align: 'center'
        }).setShadow(2, 2, "#222222", 2, false, true).setVisible(false);
        this.versionLabel = this.add.text(5, 476, 'v. 2.0.100', {
            fontFamily: 'Arial',
            fontSize: 10,
            color: '#cccccc'
        });
        this.playButton = this.add.sprite(915, 460, 'playButton').setInteractive({
            useHandCursor: true
        }).setName('playButton');
        this.anims.create({
            key: 'flash',
            frames: this.anims.generateFrameNumbers('playButton'),
            frameRate: 5,
            repeat: -1
        });
        this.anims.create({
            key: 'blink',
            frames: this.anims.generateFrameNumbers('tile', {
                start: 0,
                end: 11
            }),
            frameRate: 18,
            repeat: -1
        });
        this.playButton.anims.play('flash');
        this.playButton.on('pointerdown', function(pointer) {
            var t = this.scene;
            if (t.bg.visible == true) {
                t.bg.visible = false;
                t.tagBox.visible = false;
                t.endureBox.visible = false;
                t.versionLabel.visible = false;
                t.tf0.visible = true;
                t.tf1.visible = true;
                t.tf2.visible = true;
                t.tf3.visible = true;
                t.tf4.visible = true;
                t.tf5.visible = true
            } else {
                this.scene.scene.start("PlayGame")
            }
        })
    }
    onFlagButtonDown(pointer) {
        gameOptions.changeLanguage(this.name);
        var t = this.scene;
        t.tagBox.setText(gameOptions.language.tagLine);
        t.endureBox.setText(gameOptions.language.endure);
        t.tf0.setText(gameOptions.language.HelpText0);
        t.tf1.setText(gameOptions.language.HelpText1);
        t.tf2.setText(gameOptions.language.HelpText2);
        t.tf3.setText(gameOptions.language.HelpText3);
        t.tf4.setText(gameOptions.language.HelpText4);
        t.tf5.setText(gameOptions.language.HelpText5);
        for (let i in this.scene.flagButtons) {
            this.scene.flagButtons[i].setFrame(0)
        }
        this.setFrame(2)
    }
    onFlagButtonOver(pointer) {
        this.setFrame(1)
    }
    onFlagButtonOut(pointer) {
        if (gameOptions.currentLanguage == this.name) {
            this.setFrame(2)
        } else {
            this.setFrame(0)
        }
    }
}
class Tile extends Phaser.GameObjects.Sprite {
    constructor(config) {
        super(config.scene, config.x, config.y, 'tile');
        this.enabled = true;
        var shape = new Phaser.Geom.Polygon([6, 10, 62, 29, 6, 48, -50, 29, 6, 10]);
        this.shape = shape;
        this.setInteractive(shape, Phaser.Geom.Polygon.Contains);
        config.scene.add.existing(this)
    }
}
class ZigzagWindow extends Phaser.Scene {
    constructor() {
        super()
    }
    createBackground(x, y, width, height) {
        const offsetwh = 16;
        const safeoffset = 14;
        const sideThickness = 8;
        if ((width % 16) !== 0) {
            width = width - (width % 16) + 16
        }
        if ((height % 16) !== 0) {
            height = height - (height % 16) + 16
        }
        this.dlg = this.add.nineslice(x, y, width, height, {
            key: 'atlas',
            frame: 'zigzag-border-edges-5'
        }, offsetwh, safeoffset);
        this.extra_top = this.add.tileSprite(x + offsetwh, y, width - 2 * offsetwh, sideThickness, 'atlas', 'zig-001').setOrigin(0, 0).setTileScale(0.5);
        this.extra_bottom = this.add.tileSprite(x + offsetwh, y + height - sideThickness, width - 2 * offsetwh, sideThickness, 'atlas', 'zig-001').setOrigin(0, 0).setTileScale(0.5);
        this.extra_left = this.add.tileSprite(x, y + offsetwh, sideThickness, height - 2 * offsetwh, 'atlas', 'zag-001').setOrigin(0, 0).setTileScale(0.5);
        this.extra_right = this.add.tileSprite(x + width - sideThickness, y + offsetwh, sideThickness, height - 2 * offsetwh, 'atlas', 'zag-001').setOrigin(0, 0).setTileScale(0.5)
    }
}
class IOBox extends ZigzagWindow {
    constructor() {
        super('IOBox')
    }
    preload() {
        this.load.scenePlugin({
            key: 'rexuiplugin',
            url: 'rexuiplugin.min.js',
            sceneKey: 'rexUI'
        })
    }
    init(data) {
        this.data = data;
        this.COLOR_PRIMARY = 0xf1f1c1;
        this.COLOR_LIGHT = 0x96957a;
        this.COLOR_DARK = 0x333333
    }
    create() {
        this.windowX = 56;
        this.windowY = 5;
        this.createBackground(this.windowX, this.windowY, 848, 512);
        var graphics = this.add.graphics();
        graphics.fillStyle('#000000', 0.05);
        graphics.fillRoundedRect(212 + this.windowX, 63 + this.windowY, 266, 169, 4);
        graphics.fillRoundedRect(542 - 56 + this.windowX, 63 + this.windowY, 335, 169, 4);
        graphics.fillRoundedRect(83 - 56 + this.windowX, 243 + this.windowY, 220, 252, 4);
        graphics.fillRoundedRect(312 - 56 + this.windowX, 243 + this.windowY, 220, 252, 4);
        graphics.fillRoundedRect(542 - 56 + this.windowX, 243 + this.windowY, 335, 252, 4);
        graphics.lineStyle(1, '#000000', 0.15);
        graphics.strokeRoundedRect(212 + this.windowX, 63 + this.windowY, 266, 169, 4);
        graphics.strokeRoundedRect(542 - 56 + this.windowX, 63 + this.windowY, 335, 169, 4);
        graphics.strokeRoundedRect(83 - 56 + this.windowX, 243 + this.windowY, 220, 252, 4);
        graphics.strokeRoundedRect(312 - 56 + this.windowX, 243 + this.windowY, 220, 252, 4);
        graphics.strokeRoundedRect(542 - 56 + this.windowX, 243 + this.windowY, 335, 252, 4);
        this.iobAnn = this.add.text(848 / 2 + this.windowX, 16 + this.windowY, gameOptions.language.iobAnn, {
            fontSize: 18,
            fontStyle: 'bold',
            fontFamily: 'Arial',
            color: '#000000',
            align: 'center'
        }).setOrigin(0.5, 0);
        this.evOfTheYear = this.add.text(24 + this.windowX, 40 + this.windowY, gameOptions.language.evOfTheYear, {
            fontSize: 14,
            fontStyle: 'bold',
            fontFamily: 'Arial',
            color: '#000000',
            align: 'left'
        }).setOrigin(0, 0);
        this.iobSum = this.add.text(495 + this.windowX, 40 + this.windowY, gameOptions.language.iobSum, {
            fontSize: 14,
            fontStyle: 'bold',
            fontFamily: 'Arial',
            color: '#000000',
            align: 'left'
        }).setOrigin(0, 0);
        this.iobCrops = this.add.text(34 + this.windowX, 248 + this.windowY, gameOptions.language.iobCrops, {
            fontSize: 14,
            fontStyle: 'bold',
            fontFamily: 'Arial',
            color: '#000000',
            align: 'left'
        }).setOrigin(0, 0);
        this.iobLivest = this.add.text(263 + this.windowX, 248 + this.windowY, gameOptions.language.iobLivest, {
            fontSize: 14,
            fontStyle: 'bold',
            fontFamily: 'Arial',
            color: '#000000',
            align: 'left'
        }).setOrigin(0, 0);
        this.iobSaE = this.add.text(495 + this.windowX, 248 + this.windowY, gameOptions.language.iobSaE, {
            fontSize: 14,
            fontStyle: 'bold',
            fontFamily: 'Arial',
            color: '#000000',
            align: 'left'
        }).setOrigin(0, 0);
        this.iobAm = this.add.text(31 + 32 + this.windowX, 267 + this.windowY, gameOptions.language.iobAm, {
            fontSize: 11,
            fontStyle: 'normal',
            fontFamily: 'Arial',
            color: '#000000',
            align: 'center'
        }).setOrigin(0.5, 0);
        this.iobType = this.add.text(85 + 25 + this.windowX, 267 + this.windowY, gameOptions.language.iobType, {
            fontSize: 11,
            fontStyle: 'normal',
            fontFamily: 'Arial',
            color: '#000000',
            align: 'center'
        }).setOrigin(0.5, 0);
        this.iobYield1 = this.add.text(128 + 55 + this.windowX, 267 + this.windowY, gameOptions.language.iobYield1, {
            fontSize: 11,
            fontStyle: 'normal',
            fontFamily: 'Arial',
            color: '#000000',
            align: 'center'
        }).setOrigin(0.5, 0);
        this.iobAm2 = this.add.text(260 + 32 + this.windowX, 267 + this.windowY, gameOptions.language.iobAm, {
            fontSize: 11,
            fontStyle: 'normal',
            fontFamily: 'Arial',
            color: '#000000',
            align: 'center'
        }).setOrigin(0.5, 0);
        this.iobType2 = this.add.text(309 + 25 + this.windowX, 267 + this.windowY, gameOptions.language.iobType, {
            fontSize: 11,
            fontStyle: 'normal',
            fontFamily: 'Arial',
            color: '#000000',
            align: 'center'
        }).setOrigin(0.5, 0);
        this.iobYield2 = this.add.text(354 + 56 + this.windowX, 267 + this.windowY, gameOptions.language.iobYield2, {
            fontSize: 11,
            fontStyle: 'normal',
            fontFamily: 'Arial',
            color: '#000000',
            align: 'center'
        }).setOrigin(0.5, 0);
        this.iobToolsB = this.add.text(53 + this.windowX, 443 + this.windowY, gameOptions.language.iobToolsB, {
            fontSize: 12,
            fontStyle: 'bold',
            fontFamily: 'Arial',
            color: '#000000',
            align: 'left'
        }).setOrigin(0, 0);
        this.iobToolsT = this.add.text(53 + this.windowX, 465 + this.windowY, gameOptions.language.iobToolsT, {
            fontSize: 12,
            fontStyle: 'bold',
            fontFamily: 'Arial',
            color: '#000000',
            align: 'left'
        }).setOrigin(0, 0);
        this.iobBuildB = this.add.text(278 + this.windowX, 443 + this.windowY, gameOptions.language.iobBuildB, {
            fontSize: 12,
            fontStyle: 'bold',
            fontFamily: 'Arial',
            color: '#000000',
            align: 'left'
        }).setOrigin(0, 0);
        this.iobBuildT = this.add.text(278 + this.windowX, 465 + this.windowY, gameOptions.language.iobBuildT, {
            fontSize: 12,
            fontStyle: 'bold',
            fontFamily: 'Arial',
            color: '#000000',
            align: 'left'
        }).setOrigin(0, 0);
        this.iobBase = this.add.text(497 + this.windowX, 284 + this.windowY, gameOptions.language.iobBase, {
            fontSize: 12,
            fontStyle: 'bold',
            fontFamily: 'Arial',
            color: '#000000',
            align: 'left'
        }).setOrigin(0, 0);
        this.iobWorkCap = this.add.text(497 + this.windowX, 317 + this.windowY, gameOptions.language.iobWorkCap, {
            fontSize: 12,
            fontStyle: 'bold',
            fontFamily: 'Arial',
            color: '#000000',
            align: 'left'
        }).setOrigin(0, 0);
        this.iobAnnEvMod = this.add.text(497 + this.windowX, 342 + this.windowY, gameOptions.language.iobAnnEvMod, {
            fontSize: 12,
            fontStyle: 'bold',
            fontFamily: 'Arial',
            color: '#000000',
            align: 'left'
        }).setOrigin(0, 0);
        this.IOcalcString = this.add.text(497 + this.windowX, 365 + this.windowY, 'Income this year:\n(45 * 1.50) :', {
            fontSize: 12,
            fontStyle: 'bold',
            fontFamily: 'Arial',
            color: '#000000',
            align: 'left'
        }).setOrigin(0, 0);
        this.iobSaved = this.add.text(497 + this.windowX, 411 + this.windowY, gameOptions.language.iobSaved, {
            fontSize: 12,
            fontStyle: 'bold',
            fontFamily: 'Arial',
            color: '#000000',
            align: 'left'
        }).setOrigin(0, 0);
        this.iobLivCost = this.add.text(497 + this.windowX, 437 + this.windowY, gameOptions.language.iobLivCost, {
            fontSize: 12,
            fontStyle: 'bold',
            fontFamily: 'Arial',
            color: '#000000',
            align: 'left'
        }).setOrigin(0, 0);
        this.iobTot = this.add.text(497 + this.windowX, 466 + this.windowY, gameOptions.language.iobTot, {
            fontSize: 12,
            fontStyle: 'bold',
            fontFamily: 'Arial',
            color: '#000000',
            align: 'left'
        }).setOrigin(0, 0);
        this.exitButton = this.add.image(757 + this.windowX, 18 + this.windowY, 'atlas', 'button-play').setDisplaySize(60, 38).setOrigin(0, 0);
        this.exitButton.setInteractive({
            useHandCursor: true
        }).on('pointerdown', this.handleExitClick.bind(this));
        let dols = [[157, 291], [157, 322], [157, 353], [157, 383], [157, 414], [157, 465], [386, 291], [386, 333], [386, 371], [386, 413], [386, 465], [694, 284], [694, 371], [694, 410], [694, 436], [694, 465]];
        dols.forEach(this.addDollarSign.bind(this));
        var textConfig1 = {
            fontSize: 18,
            fontStyle: 'bold',
            fontFamily: 'Arial',
            color: '#000000',
            align: 'left'
        };
        var textConfig2 = {
            fontSize: 14,
            fontStyle: 'normal',
            fontFamily: 'Arial',
            color: '#000000',
            align: 'right'
        };
        this.cornAmount = this.add.text(56 + this.windowX, 291 + this.windowY, '0', textConfig1).setOrigin(0, 0);
        this.wheatAmount = this.add.text(56 + this.windowX, 322 + this.windowY, '0', textConfig1).setOrigin(0, 0);
        this.cottonAmount = this.add.text(56 + this.windowX, 353 + this.windowY, '0', textConfig1).setOrigin(0, 0);
        this.peanutAmount = this.add.text(56 + this.windowX, 383 + this.windowY, '0', textConfig1).setOrigin(0, 0);
        this.poppyAmount = this.add.text(56 + this.windowX, 414 + this.windowY, '0', textConfig1).setOrigin(0, 0);
        this.cornYield = this.add.text(212 + this.windowX, 291 + this.windowY, '10.0', textConfig2).setOrigin(1, 0);
        this.wheatYield = this.add.text(212 + this.windowX, 322 + this.windowY, '0.0', textConfig2).setOrigin(1, 0);
        this.cottonYield = this.add.text(212 + this.windowX, 353 + this.windowY, '0.2', textConfig2).setOrigin(1, 0);
        this.peanutYield = this.add.text(212 + this.windowX, 383 + this.windowY, '100.0', textConfig2).setOrigin(1, 0);
        this.poppyYield = this.add.text(212 + this.windowX, 414 + this.windowY, '0.0', textConfig2).setOrigin(1, 0);
        this.chickenAmount = this.add.text(282 + this.windowX, 291 + this.windowY, '0', textConfig1).setOrigin(0, 0);
        this.pigAmount = this.add.text(282 + this.windowX, 333 + this.windowY, '0', textConfig1).setOrigin(0, 0);
        this.cowAmount = this.add.text(282 + this.windowX, 371 + this.windowY, '0', textConfig1).setOrigin(0, 0);
        this.elephantAmount = this.add.text(282 + this.windowX, 413 + this.windowY, '0', textConfig1).setOrigin(0, 0);
        this.chickenYield = this.add.text(443 + this.windowX, 291 + this.windowY, '10.0', textConfig2).setOrigin(1, 0);
        this.pigYield = this.add.text(443 + this.windowX, 333 + this.windowY, '0.0', textConfig2).setOrigin(1, 0);
        this.cowYield = this.add.text(443 + this.windowX, 371 + this.windowY, '0.2', textConfig2).setOrigin(1, 0);
        this.elephantYield = this.add.text(443 + this.windowX, 413 + this.windowY, '000', textConfig2).setOrigin(1, 0);
        this.IOtoolsBonus = this.add.text(181 + this.windowX, 443 + this.windowY, '+ 0 %', {
            fontSize: 12,
            fontStyle: 'normal',
            fontFamily: 'Arial',
            color: '#000000',
            align: 'left'
        }).setOrigin(0, 0);
        this.IOcropsTotal = this.add.text(176 + 47 + this.windowX, 466 + this.windowY, '000', textConfig2).setOrigin(1, 0);
        this.IObuildingBonus = this.add.text(412 + this.windowX, 443 + this.windowY, '+ 0 %', {
            fontSize: 12,
            fontStyle: 'normal',
            fontFamily: 'Arial',
            color: '#000000',
            align: 'left'
        }).setOrigin(0, 0);
        this.IOlivestockTotal = this.add.text(402 + 47 + this.windowX, 466 + this.windowY, '000', textConfig2).setOrigin(1, 0);
        this.IOsum = this.add.text(765 + this.windowX, 284 + this.windowY, '45', textConfig2).setOrigin(1, 0);
        this.IOworkload = this.add.text(755 + this.windowX, 317 + this.windowY, '150%', {
            fontSize: 12,
            fontStyle: 'normal',
            fontFamily: 'Arial',
            color: '#000000',
            align: 'center'
        }).setOrigin(0.5, 0);
        this.IOeventModifier = this.add.text(755 + this.windowX, 342 + this.windowY, '0 %', {
            fontSize: 12,
            fontStyle: 'normal',
            fontFamily: 'Arial',
            color: '#000000',
            align: 'center'
        }).setOrigin(0.5, 0);
        this.IOtotal = this.add.text(765 + this.windowX, 370 + this.windowY, '000', textConfig2).setOrigin(1, 0);
        this.IOsavedFromLastYear = this.add.text(765 + this.windowX, 410 + this.windowY, '000', textConfig2).setOrigin(1, 0);
        this.IOlivingCosts = this.add.text(765 + this.windowX, 436 + this.windowY, '000', textConfig2).setOrigin(1, 0);
        this.IOtotalFinal = this.add.text(765 + this.windowX, 464 + this.windowY, '000', textConfig2).setOrigin(1, 0);
        this.add.image(114 + this.windowX, 280 + this.windowY, 'atlas', 'inv/inv-0001').setOrigin(0.5, 0).setScale(0.45);
        this.add.image(114 + this.windowX, 318 + this.windowY, 'atlas', 'inv/inv-0002').setOrigin(0.5, 0).setScale(0.38);
        this.add.image(116 + this.windowX, 316 + this.windowY, 'atlas', 'inv/inv-0003').setOrigin(0.5, 0).setScale(0.82);
        this.add.image(114 + this.windowX, 358 + this.windowY, 'atlas', 'inv/inv-0004').setOrigin(0.5, 0).setScale(0.65);
        this.add.image(114 + this.windowX, 408 + this.windowY, 'atlas', 'inv/inv-0005').setOrigin(0.5, 0).setScale(0.40);
        this.add.image(338 + this.windowX, 252 + this.windowY, 'atlas', 'inv/inv-0006').setOrigin(0.5, 0).setScale(0.8);
        this.add.image(338 + this.windowX, 312 + this.windowY, 'atlas', 'inv/inv-0007').setOrigin(0.5, 0).setScale(0.55);
        this.add.image(338 + this.windowX, 346 + this.windowY, 'atlas', 'inv/inv-0008').setOrigin(0.5, 0).setScale(0.55);
        this.add.image(338 + this.windowX, 400 + this.windowY, 'atlas', 'inv/inv-0009').setOrigin(0.5, 0).setScale(0.4);
        this.print1 = this.add.text(0, 0, '', {
            fontSize: 12,
            fontFamily: 'Arial',
            color: '#000000'
        });
        this.content1 = "";
        this.scrollablePanel1 = this.rexUI.add.scrollablePanel({
            x: 56 + 214 + 129,
            y: 5 + 65 + 82,
            width: 268,
            height: 170,
            scrollMode: 0,
            background: this.rexUI.add.roundRectangle(0, 0, 2, 2, 0, this.COLOR_PRIMARY).setStrokeStyle(1, 0x666666, 1),
            panel: {
                child: this.rexUI.add.fixWidthSizer({
                    space: {
                        left: 3,
                        right: 3,
                        top: 3,
                        bottom: 3,
                        item: 4,
                        line: 2,
                    }
                }),
                mask: {
                    padding: 1
                },
            },
            slider: {
                background: this.add.image(0, 0, 'atlas', 'brownSquare').setAlpha(0.1),
                track: this.rexUI.add.roundRectangle(0, 0, 24, 20, 2, this.COLOR_LIGHT).setAlpha(0.01),
                thumb: this.rexUI.add.roundRectangle(0, 0, 24, 20, 2, this.COLOR_LIGHT),
            },
            space: {
                left: 10,
                right: 10,
                top: 10,
                bottom: 10,
                panel: 10
            }
        });
        this.print2 = this.add.text(0, 0, '', {
            fontSize: 12,
            fontFamily: 'Arial',
            color: '#000000'
        });
        this.content2 = "";
        this.scrollablePanel2 = this.rexUI.add.scrollablePanel({
            x: 56 + 490 + 164,
            y: 5 + 65 + 82,
            width: 336,
            height: 170,
            scrollMode: 0,
            background: this.rexUI.add.roundRectangle(0, 0, 2, 2, 0, this.COLOR_PRIMARY).setStrokeStyle(1, 0x666666, 1),
            panel: {
                child: this.rexUI.add.fixWidthSizer({
                    space: {
                        left: 3,
                        right: 3,
                        top: 3,
                        bottom: 3,
                        item: 4,
                        line: 2,
                    }
                }),
                mask: {
                    padding: 1
                },
            },
            slider: {
                background: this.add.image(0, 0, 'atlas', 'brownSquare').setAlpha(0.1),
                track: this.rexUI.add.roundRectangle(0, 0, 24, 20, 2, this.COLOR_LIGHT).setAlpha(0.01),
                thumb: this.rexUI.add.roundRectangle(0, 0, 24, 20, 2, this.COLOR_LIGHT),
            },
            space: {
                left: 10,
                right: 10,
                top: 10,
                bottom: 10,
                panel: 10
            }
        });
        this.picTargetMC = this.add.image(26 + this.windowX, 63 + this.windowY, '').setOrigin(0, 0);
        eventsCenter.emit('created-step', 'IOBox')
    }
    addDollarSign(pos) {
        this.add.text(this.windowX + pos[0], this.windowY + pos[1], '$', {
            fontSize: 14,
            fontStyle: 'normal',
            fontFamily: 'Arial',
            color: '#000000',
            align: 'left'
        }).setOrigin(0, 0)
    }
    setContent(p) {}
    handleExitClick() {
        eventsCenter.emit('closed-io-box')
    }
    updatePanel(panel, content) {
        var sizer = panel.getElement('panel');
        var scene = panel.scene;
        sizer.clear(true);
        var lines = content.split('\n');
        for (var li = 0, lcnt = lines.length; li < lcnt; li++) {
            var words = lines[li].split(' ');
            for (var wi = 0, wcnt = words.length; wi < wcnt; wi++) {
                sizer.add(scene.add.text(0, 0, words[wi], {
                    fontSize: 12,
                    fontFamily: 'Arial',
                    color: '#000000'
                }).setInteractive().on('pointerdown', function() {
                    scene.print1.text = this.text
                }))
            }
            if (li < (lcnt - 1)) {
                sizer.addNewLine()
            }
        }
        panel.layout();
        return panel
    }
}
class nightScene extends Phaser.Scene {
    constructor() {
        super("NightScene")
    }
    preload() {}
    updateMonth() {
        this.monthText.setText(gameOptions.language.months[11 - this.timedEvent.repeatCount])
    }
    animComplete() {
        this.tweens.killAll();
        eventsCenter.emit('night-anim-complete')
    }
    create() {}
    startAnim() {
        this.scene.bringToTop('NightScene');
        this.night_bg = this.add.image(0, 0, 'atlas', 'night-blue').setOrigin(0, 0).setDisplaySize(960, 520).setAlpha(0);
        this.tweens.add({
            targets: this.night_bg,
            alpha: 0.6,
            duration: 800,
            yoyo: true,
            ease: 'Linear',
            hold: 800
        });
        this.calendar = this.add.image(380, 130, 'atlas', 'calendar-bg').setDisplaySize(200, 260).setAlpha(0).setOrigin(0, 0);
        this.monthText = this.add.text(390, 145, '', {
            fontFamily: 'Arial',
            fontSize: 32,
            color: '#000000'
        }).setAlpha(0);
        this.tweens.add({
            targets: [this.monthText, this.calendar],
            alpha: 1,
            duration: 200,
            yoyo: true,
            ease: 'Linear',
            hold: 2200,
            onComplete: this.animComplete,
            onCompleteScope: this
        });
        this.timedEvent = this.time.addEvent({
            delay: 200,
            callback: this.updateMonth,
            callbackScope: this,
            repeat: 11
        })
    }
}
class BlackCover extends Phaser.Scene {
    constructor() {
        super('BlackCover')
    }
    create() {
        this.bg = this.add.graphics();
        this.bg.fillStyle(0x000000, 1);
        this.bg.fillRect(0, 0, 960, 520)
    }
}
class playGame extends Phaser.Scene {
    constructor() {
        super("PlayGame")
    }
    preload() {}
    stepCreate(param) {
        this.stepsCreated++;
        this.game.scene.bringToTop('BlackCover');
        var d = new Date();
        var n = d.getMilliseconds();
        if (this.stepsCreated == 15) {
            this.game.scene.remove('BlackCover')
        }
    }
    create() {
        this.blackCover = this.scene.add('BlackCover', BlackCover, true);
        this.stepsCreated = 0;
        eventsCenter.on('created-step', this.stepCreate, this);
        main = new Main();
        this.allEvents = new AllEvents(gameOptions.language);
        this.farm_bg = this.add.image(0, 0, 'atlas', 'farm-background').setOrigin(0, 0);
        this.frames_for_menu = this.add.image(0, 0, 'atlas', 'frames-for-menu').setOrigin(0, 0);
        this.project_road = this.add.image(617 - 334, 185 - 33, 'atlas', 'project-road').setOrigin(0, 0).setVisible(false);
        this.hut = this.add.image(526 - 52, 282 - 104, 'atlas', 'hut').setOrigin(0, 0);
        this.project_school = this.add.image(529, 142, 'atlas', 'project-school').setOrigin(0, 0).setVisible(false);
        this.project_clinic = this.add.image(729, 176, 'atlas', 'project-clinic').setOrigin(0, 0).setVisible(false);
        this.project_representative = this.add.image(600, 264, 'atlas', 'project-representative').setOrigin(0, 0).setVisible(false);
        
        this.project_communications = this.add.image(526 - 68, 155, 'atlas', 'project-communications').setOrigin(0, 0).setFlipX(true).setVisible(false);
        
        this.project_insurance = this.add.image(507, 242, 'atlas', 'project-insurance').setOrigin(0, 0).setAngle(-4.6).setScale(0.15).setVisible(false);
        this.project_expansion = this.add.image(1000, 264, 'atlas', 'project-expansion').setOrigin(0, 0).setVisible(true);
        this.projects = [this.project_road, this.project_school, this.project_clinic, this.project_representative, this.project_communications, this.project_expansion, this.project_insurance];
        for (let i = 0; i < this.projects.length; i++) {
            let pro = this.projects[i];
            pro.on('pointerdown', function(pro) {
                this.scene.wake(this.projectInfoBox);
                this.showProjectInfoBox(pro)
            }
            .bind(this, pro));
            pro.on('pointerover', function(pro) {
                this.setBlendMode(Phaser.BlendModes.SCREEN)
            }
            .bind(pro));
            pro.on('pointerout', function(pro) {
                this.setBlendMode(Phaser.BlendModes.NORMAL)
         
            }
            .bind(pro))
        }
        this.sellButton = this.add.image(765, 33, 'atlas', 'button-sell').setOrigin(0, 0).setScale(1.15).disableInteractive();
        this.sellButton.on('pointerdown', this.handleSellButtonClick.bind(this));
        this.playButton = this.add.image(859, 33, 'atlas', 'button-play').setOrigin(0, 0).setScale(1.15).disableInteractive();
        this.chem_barrel = this.add.image(546 - 44, 335 - 5, 'atlas', 'chem-barrels').setOrigin(0, 0).setVisible(false);
        this.mil_camp = this.add.image(82, 102, 'atlas', 'mil-camp').setOrigin(0, 0).setVisible(false);
        this.familyView = this.scene.add('FamilyView', FamilyView, true, {
            x: 457,
            y: 266
        });
        eventsCenter.on('clicked-family-member', this.handleClickedFamilyMember, this);
        this.investmentTarget = this.scene.add('InvestmentsView', InvestmentsView, true, {
            x: 0,
            y: 0
        });
        this.disposeMC = this.add.image(0, 0, 'atlas', 'brownSquare').setOrigin(0, 0).setInteractive();
        this.disposeMC.input.hitArea.setTo(0, 0, 960, 520);
        this.disposeMC.on('pointerdown', function() {
            this.handleClickDisposeMC()
        }
        .bind(this));
        let ymod = -25;
        this.toolTile1 = new Tile({
            scene: this,
            x: 675.55,
            y: 284.25 + ymod
        }).setOrigin(0, 0);
        this.toolTile2 = new Tile({
            scene: this,
            x: 805.55,
            y: 285.25 + ymod
        }).setOrigin(0, 0);
        this.toolTile3 = new Tile({
            scene: this,
            x: 749.8,
            y: 303 + ymod
        }).setOrigin(0, 0);
        this.toolTile4 = new Tile({
            scene: this,
            x: 677.5,
            y: 322 + ymod
        }).setOrigin(0, 0);
        this.constructionTile1 = new Tile({
            scene: this,
            x: 146.05,
            y: 286 + ymod
        }).setOrigin(0, 0);
        this.constructionTile2 = new Tile({
            scene: this,
            x: 80.5,
            y: 305 + ymod
        }).setOrigin(0, 0);
        this.constructionTile3 = new Tile({
            scene: this,
            x: 147,
            y: 323 + ymod
        }).setOrigin(0, 0);
        this.constructionTile4 = new Tile({
            scene: this,
            x: 81.05,
            y: 343 + ymod
        }).setOrigin(0, 0);
        this.constructionTile5 = new Tile({
            scene: this,
            x: 875,
            y: 341 + ymod
        }).setOrigin(0, 0);
        this.constructionTile6 = new Tile({
            scene: this,
            x: 809,
            y: 362 + ymod
        }).setOrigin(0, 0);
        this.constructionTile7 = new Tile({
            scene: this,
            x: 880,
            y: 380 + ymod
        }).setOrigin(0, 0);
        this.cropTile1 = new Tile({
            scene: this,
            x: 345.5,
            y: 306 + ymod
        }).setOrigin(0, 0);
        this.cropTile2 = new Tile({
            scene: this,
            x: 413.5,
            y: 325 + ymod
        }).setOrigin(0, 0);
        this.cropTile3 = new Tile({
            scene: this,
            x: 480.5,
            y: 342 + ymod
        }).setOrigin(0, 0);
        this.cropTile4 = new Tile({
            scene: this,
            x: 345.9,
            y: 344 + ymod
        }).setOrigin(0, 0);
        this.cropTile5 = new Tile({
            scene: this,
            x: 412.5,
            y: 361 + ymod
        }).setOrigin(0, 0);
        this.cropTile6 = new Tile({
            scene: this,
            x: 477.5,
            y: 382 + ymod
        }).setOrigin(0, 0);
        this.cropTile7 = new Tile({
            scene: this,
            x: 281.8,
            y: 362 + ymod
        }).setOrigin(0, 0);
        this.cropTile8 = new Tile({
            scene: this,
            x: 345.3,
            y: 381 + ymod
        }).setOrigin(0, 0);
        this.cropTile9 = new Tile({
            scene: this,
            x: 410.4,
            y: 401 + ymod
        }).setOrigin(0, 0);
        this.cropTile10 = new Tile({
            scene: this,
            x: 210,
            y: 380 + ymod
        }).setOrigin(0, 0);
        this.cropTile11 = new Tile({
            scene: this,
            x: 273.5,
            y: 399 + ymod
        }).setOrigin(0, 0);
        this.cropTile12 = new Tile({
            scene: this,
            x: 346.8,
            y: 421 + ymod
        }).setOrigin(0, 0);
        this.cropTile13 = new Tile({
            scene: this,
            x: 142.8,
            y: 400 + ymod
        }).setOrigin(0, 0);
        this.cropTile14 = new Tile({
            scene: this,
            x: 206,
            y: 420 + ymod
        }).setOrigin(0, 0);
        this.cropTile15 = new Tile({
            scene: this,
            x: 276.4,
            y: 438 + ymod
        }).setOrigin(0, 0);
        this.cropTile16 = new Tile({
            scene: this,
            x: 144.5,
            y: 439 + ymod
        }).setOrigin(0, 0);
        this.cropTile17 = new Tile({
            scene: this,
            x: 208.5,
            y: 459 + ymod
        }).setOrigin(0, 0);
        this.cropTile18 = new Tile({
            scene: this,
            x: 276.4,
            y: 476 + ymod
        }).setOrigin(0, 0);
        this.cropTile19 = new Tile({
            scene: this,
            x: 477.5,
            y: 422 + ymod
        }).setOrigin(0, 0);

        this.cropTile20 = new Tile({
            scene: this,
            x: 410.4,
            y: 441 + ymod
        }).setOrigin(0, 0);
        
        this.cropTile21 = new Tile({
            scene: this,
            x: 346.8,
            y: 461 + ymod
        }).setOrigin(0, 0);
        this.cropTile22 = new Tile({
            scene: this,
            x: 544.5,
            y: 401 + ymod
        }).setOrigin(0, 0);
        this.livestockTile1 = new Tile({
            scene: this,
            x: 674.6,
            y: 402 + ymod
        }).setOrigin(0, 0);
        this.livestockTile2 = new Tile({
            scene: this,
            x: 609.2,
            y: 418 + ymod
        }).setOrigin(0, 0);
        this.livestockTile3 = new Tile({
            scene: this,
            x: 543,
            y: 437 + ymod
        }).setOrigin(0, 0);
        this.livestockTile4 = new Tile({
            scene: this,
            x: 479,
            y: 457 + ymod
        }).setOrigin(0, 0);
        this.livestockTile5 = new Tile({
            scene: this,
            x: 737.2,
            y: 419 + ymod
        }).setOrigin(0, 0);
        this.livestockTile6 = new Tile({
            scene: this,
            x: 671.2,
            y: 440 + ymod
        }).setOrigin(0, 0);
        this.livestockTile7 = new Tile({
            scene: this,
            x: 605,
            y: 458 + ymod
        }).setOrigin(0, 0);
        this.livestockTile8 = new Tile({
            scene: this,
            x: 541,
            y: 477.8 + ymod
        }).setOrigin(0, 0);
        this.itemDetails = this.scene.add('ItemDetails', ItemDetails, true, {
            x: 0,
            y: 433
        });
        this.hideItemDetails();
        eventsCenter.on('handle-buy-project-button', this.handleBuyProjectButton, this);
        eventsCenter.on('clicked-help', this.clickedHelp, this);
        farmModel = new FarmModel(main,gameOptions.language);
        eventsCenter.on('paint-labels-and-projects', this.paintLabelsAndProjects, this);
        this.familyMemberInfoBox = this.scene.add('FamilyMemberInfoBox', FamilyMemberInfoBox, true, {
            x: 0,
            y: 0,
            farmModel: farmModel
        });
        this.scene.sleep(this.familyMemberInfoBox);
        eventsCenter.on('closed-family-member-info-box', this.closedFamilyMembers, this);
        this.giveMedicineInfoBox = this.scene.add('GiveMedicineInfoBox', GiveMedicineInfoBox, true, {
            x: 0,
            y: 0,
            farmModel: farmModel
        });
        this.scene.sleep(this.giveMedicineInfoBox);
        eventsCenter.on('clicked-give-medicine', this.clickedGiveMedicine, this);
        eventsCenter.on('heal-me-one-unit', this.healMeOneUnit, this);
        eventsCenter.on('heal-me-fully', this.healMeFully, this);
        eventsCenter.on('heal-whole-family', this.healWholeFamily, this);
        eventsCenter.on('closed-give-medicine-infobox', this.closeGiveMedicine, this);
        this.haveBabyInfoBox = this.scene.add('HaveBabyInfoBox', HaveBabyInfoBox, true, {
            x: 0,
            y: 0,
            farmModel: farmModel
        });
        this.scene.sleep(this.haveBabyInfoBox);
        eventsCenter.on('clicked-have-baby', this.clickedHaveBaby, this);
        eventsCenter.on('closed-have-baby-infobox', this.closeHaveBaby, this);
        this.goToSchoolInfoBox = this.scene.add('GoToSchoolInfoBox', GoToSchoolInfoBox, true, {
            x: 0,
            y: 0,
            farmModel: farmModel
        });
        this.scene.sleep(this.goToSchoolInfoBox);
        eventsCenter.on('clicked-go-to-school', this.clickedGoToSchool, this);
        eventsCenter.on('closed-go-to-school-infobox', this.closeGoToSchool, this);
        eventsCenter.on('accept-school', this.acceptSchool, this);
        this.familyHeadInfoBox = this.scene.add('FamilyHeadInfoBox', FamilyHeadInfoBox, true, {
            x: 0,
            y: 0,
            farmModel: farmModel
        });
        this.scene.sleep(this.familyHeadInfoBox);
        eventsCenter.on('clicked-appoint-family-head', this.clickedAppointFamilyHead, this);
        eventsCenter.on('closed-family-head-infobox', this.closeFamilyHead, this);
        eventsCenter.on('accept-family-head', this.acceptFamilyHead, this);
        this.leaveFarmInfoBox = this.scene.add('LeaveFarmInfoBox', LeaveFarmInfoBox, true, {
            x: 0,
            y: 0,
            farmModel: farmModel
        });
        this.scene.sleep(this.leaveFarmInfoBox);
        eventsCenter.on('clicked-leave-farm', this.clickedLeaveFarm, this);
        eventsCenter.on('closed-leave-farm-infobox', this.closeLeaveFarm, this);
        eventsCenter.on('leave-farm-accepted', this.leaveFarmAccepted, this);
        eventsCenter.on('game-over', this.handleGameOver, this);
        this.marriageInfoBox = this.scene.add('MarriageInfoBox', MarriageInfoBox, true, {
            x: 0,
            y: 0
        });
        this.scene.sleep(this.marriageInfoBox);
        eventsCenter.on('clicked-marry', this.clickedMarry, this);
        eventsCenter.on('closed-marriage-infobox', this.closeMarriageInfoBox, this);
        eventsCenter.on('marriage-accepted', this.marriageAccepted, this);
        this.moneyLabel = this.add.text(752, 8, gameOptions.language.money, {
            fontFamily: 'Arial',
            fontSize: 14,
            color: '#483A24'
        });
        this.moneyText = this.add.text(813, 8, '' + main.startMoney, {
            fontFamily: 'Arial',
            fontSize: 14,
            color: '#483A24'
        });
        this.roundLabel = this.add.text(869, 8, gameOptions.language.round, {
            fontFamily: 'Arial',
            fontSize: 14,
            color: '#483A24'
        });
        this.turnTextLabel = this.add.text(926, 8, '' + main.turnCount, {
            fontFamily: 'Arial',
            fontSize: 14,
            color: '#483A24'
        });
        this.cropMenuChoices = this.scene.add('CropMenuChoices', CropMenuChoices, true, {
            x: 50,
            y: 5,
            main: main
        });
        this.livestockMenuChoices = this.scene.add('LivestockMenuChoices', LivestockMenuChoices, true, {
            x: 50,
            y: 53
        });
        this.toolMenuChoices = this.scene.add('ToolMenuChoices', ToolMenuChoices, true, {
            x: 50,
            y: 101
        });
        this.constructionMenuChoices = this.scene.add('ConstructionMenuChoices', ConstructionMenuChoices, true, {
            x: 50,
            y: 149
        });
        this.projectMenuChoices = this.scene.add('ProjectMenuChoices', ProjectMenuChoices, true, {
            x: 50,
            y: 197
        });
        eventsCenter.on('menu-item-clicked', this.handleMenuItemClicked, this);
        eventsCenter.on('project-item-clicked', this.handleProjectItemClicked, this);
        this.cropMenu = this.add.image(5, 17, 'atlas', 'menu-crops').setOrigin(0, 0).setInteractive({
            useHandCursor: true
        });
        this.livestockMenu = this.add.image(5, 64, 'atlas', 'menu-livestock').setOrigin(0, 0).setInteractive({
            useHandCursor: true
        });
        this.toolMenu = this.add.image(5, 111, 'atlas', 'menu-tools').setOrigin(0, 0).setInteractive({
            useHandCursor: true
        });
        this.constructionMenu = this.add.image(5, 158, 'atlas', 'menu-construction').setOrigin(0, 0).setInteractive({
            useHandCursor: true
        });
        this.projectMenu = this.add.image(5, 205, 'atlas', 'menu-projects').setOrigin(0, 0).setInteractive({
            useHandCursor: true
        });
        this.cropMenu.on('pointerdown', this.handleMenuClick.bind(this, this.cropMenu));
        this.livestockMenu.on('pointerdown', this.handleMenuClick.bind(this, this.livestockMenu));
        this.toolMenu.on('pointerdown', this.handleMenuClick.bind(this, this.toolMenu));
        this.constructionMenu.on('pointerdown', this.handleMenuClick.bind(this, this.constructionMenu));
        this.projectMenu.on('pointerdown', this.handleMenuClick.bind(this, this.projectMenu));
        this.nightScene = this.scene.add('NightScene', nightScene, true);
        this.scene.sleep(this.nightScene);
        eventsCenter.on('night-anim-complete', this.handleNightAnimComplete, this);
        this.IObox = this.scene.add('IOBox', IOBox, true, {
            x: 0,
            y: 0
        });
        this.scene.sleep(this.IObox);
        eventsCenter.on('closed-io-box', this.handleCloseIOBox, this);
        this.sellInfoBox = this.scene.add('SellInfoBox', SellInfoBox, true, {
            x: 0,
            y: 0
        });
        this.scene.sleep(this.sellInfoBox);
        eventsCenter.on('request-sellinfo-data', this.submitSellInfoData, this);
        eventsCenter.on('close-sellinfobox', this.sellInfoBoxExitButtonClick, this);
        eventsCenter.on('sell-item', this.sellItem, this);
        this.playButton.on('pointerdown', this.handlePlayButtonClick.bind(this));
        this.projectInfoBox = this.scene.add('ProjectInfoBox', ProjectInfoBox, true, {
            x: 0,
            y: 0
        });
        this.scene.sleep(this.projectInfoBox);
        this.warningBox = this.scene.add('WarningBox', WarningBox, true, {
            x: 0,
            y: 0
        });
        this.scene.sleep(this.warningBox);
        eventsCenter.on('warned-and-built', this.buildFinalProject, this);
        eventsCenter.on('closed-warning-box', this.closeWarningBox, this);
        this.brokeInfoBox = this.scene.add('BrokeInfoBox', BrokeInfoBox, true, {
            X: 0,
            y: 0,
            farmModel: farmModel
        });
        this.scene.sleep(this.brokeInfoBox);
        eventsCenter.on('broke-event-accepted', this.handleBrokeEvent, this);
        eventsCenter.on('broke-event-declined', this.handleBrokeEventDeclined, this);
        this.gameOverScreen = this.scene.add('GameOverScreen', GameOverScreen, true, {
            X: 0,
            y: 0,
            farmModel: farmModel
        });
        this.scene.sleep(this.gameOverScreen);
        eventsCenter.on('submit-score-intent', this.showNamePrompt.bind(this));
        this.prepareForPlayerActions()
    }
    handleNightAnimComplete() {
        this.scene.sleep(this.nightScene);
        this.scene.wake(this.IObox)
    }
    handleClickedFamilyMember(member) {
        this.toggleInteractive(this.sellButton, false);
        this.cropMenuChoices.contract();
        this.livestockMenuChoices.contract();
        this.toolMenuChoices.contract();
        this.constructionMenuChoices.contract();
        this.projectMenuChoices.contract();
        this.closeGiveMedicine();
        this.closeHaveBaby();
        this.closeGoToSchool();
        this.closeFamilyHead();
        this.closeLeaveFarm();
        this.closeMarriageInfoBox();
        this.scene.sleep(this.projectInfoBox);
        this.familyMemberInfoBox.setContent(member);
        this.scene.wake(this.familyMemberInfoBox)
    }
    closedFamilyMembers() {
        this.scene.sleep(this.familyMemberInfoBox);
        this.closeGiveMedicine();
        this.closeHaveBaby();
        this.closeGoToSchool();
        this.closeFamilyHead();
        this.closeLeaveFarm();
        this.closeMarriageInfoBox();
        this.toggleInteractive(this.sellButton, true);
        this.familyView.paintFamily(farmModel.family)
    }
    sellItem(item) {
        let itemName = item[0].toUpperCase() + item.substring(1);
        main['sell' + itemName + 'Avail'] -= 1;
        farmModel.setMoney(farmModel.getMoney() + main['sell' + itemName + 'Price']);
        farmModel.removeOneInvestment(item);
        farmModel.farmGraphicViewPaint()
    }
    clickedHelp() {
        var url = 'https://3rdworldfarmer.org/manual/game-concepts/family-overview/';
        switch (gameOptions.currentLanguage) {
        case 'flag_en':
            url = 'https://3rdworldfarmer.org/manual/game-concepts/family-overview/';
            break;
        case 'flag_da':
            url = 'https://3rdworldfarmer.org/manual/da/familie-oversigt/';
            break;
        case 'flag_ch':
            url = 'https://3rdworldfarmer.org/manual/zh/%e5%ae%b6%e5%ba%ad%e6%80%bb%e8%ae%a1/';
            break;
        case 'flag_de':
            url = 'https://3rdworldfarmer.org/manual/de-de/familienubersicht/';
            break;
        case 'flag_cz':
            url = 'https://3rdworldfarmer.org/manual/cs/prehled-rodiny/';
            break;
        case 'flag_fr':
            url = 'https://3rdworldfarmer.org/manual/fr/la-famille/';
            break;
        case 'flag_hu':
            url = 'https://3rdworldfarmer.org/manual/hu/csalad-attekintese/';
            break;
        case 'flag_es':
            url = 'https://3rdworldfarmer.org/manual/es/la-familia/';
            break;
        case 'flag_pt':
            url = 'https://3rdworldfarmer.org/manual/pt/resumo-da-familia/';
            break;
        case 'flag_tr':
            url = 'https://3rdworldfarmer.org/manual/tr/aileye-genel-bakis/';
            break;
        case 'flag_it':
            url = 'https://3rdworldfarmer.org/manual/it/panoramica-famiglia/';
            break;
        default:
            url = 'https://3rdworldfarmer.org/manual/game-concepts/family-overview/';
            break
        }
        var s = window.open(url, '_blank');
        if (s && s.focus) {
            s.focus()
        } else if (!s) {}
    }
    clickedGiveMedicine() {
        var t = main.whichFamilyMemberActive;
        var fam = farmModel.family;
        var cost = 0;
        var costWholeFamily = 0;
        var costOneUnit = 2;
        var clinicText = '';
        if (main.clinicBuilt) {
            costOneUnit = 1;
            clinicText = gameOptions.language.medLowCost
        } else {
            costOneUnit = 2;
            clinicText = gameOptions.language.medHiCost
        }
        for (var i = 0; i < fam.length; i++) {
            if (fam[i].getID() == t) {
                cost = (100 - (fam[i].getHealth()))
            }
            costWholeFamily += (100 - (fam[i].getHealth()))
        }
        cost *= costOneUnit;
        costWholeFamily *= costOneUnit;
        this.closeAllOptions();
        this.giveMedicineInfoBox.setContent(clinicText, costOneUnit, cost, costWholeFamily);
        this.scene.wake(this.giveMedicineInfoBox)
    }
    healMeOneUnit() {
        var t = main.whichFamilyMemberActive;
        var fam = farmModel.family;
        for (var i = 0; i < fam.length; i++) {
            if (fam[i].getID() == t) {
                var cost = main.clinicBuilt ? 1 : 2;
                farmModel.setMoney(farmModel.getMoney() - cost);
                farmModel.incrementFamilyMemberHealth(i)
            }
        }
        farmModel.farmGraphicViewPaint();
        this.clickedGiveMedicine();
        this.familyMemberInfoBox.setContent(fam[farmModel.getFamilyMemberById(t)])
    }
    healMeFully() {
        var t = main.whichFamilyMemberActive;
        var fam = farmModel.family;
        for (var i = 0; i < fam.length; i++) {
            if (fam[i].getID() == t) {
                var cost = 100 - fam[i].getHealth();
                if (!main.clinicBuilt) {
                    cost *= 2
                }
                farmModel.setMoney(farmModel.getMoney() - cost);
                farmModel.setFamilyMemberHealth(i, 100)
            }
        }
        farmModel.farmGraphicViewPaint();
        this.clickedGiveMedicine();
        this.familyMemberInfoBox.setContent(fam[farmModel.getFamilyMemberById(t)])
    }
    healWholeFamily() {
        var t = main.whichFamilyMemberActive;
        var fam = farmModel.family;
        var cost = 0;
        for (var i = 0; i < fam.length; i++) {
            cost += (100 - fam[i].getHealth());
            farmModel.setFamilyMemberHealth(i, 100)
        }
        if (!main.clinicBuilt) {
            cost *= 2
        }
        farmModel.setMoney(farmModel.getMoney() - cost);
        farmModel.farmGraphicViewPaint();
        this.clickedGiveMedicine();
        this.familyMemberInfoBox.setContent(fam[farmModel.getFamilyMemberById(t)])
    }
    closeGiveMedicine() {
        this.scene.sleep(this.giveMedicineInfoBox)
    }
    clickedGoToSchool() {
        this.closeAllOptions();
        this.goToSchoolInfoBox.setContent();
        this.scene.wake(this.goToSchoolInfoBox)
    }
    closeGoToSchool() {
        this.scene.sleep(this.goToSchoolInfoBox)
    }
    acceptSchool() {
        this.scene.sleep(this.goToSchoolInfoBox);
        this.familyMemberInfoBox.setContent(farmModel.family[farmModel.getFamilyMemberById(farmModel.main.whichFamilyMemberActive)]);
        farmModel.farmGraphicViewPaint()
    }
    clickedHaveBaby() {
        var namestring = '';
        var explanation = '';
        var t = main.whichFamilyMemberActive;
        for (var i = 0; i < farmModel.family.length; i++) {
            let temp = farmModel.family[i];
            if (temp.getID() == t) {
                namestring = temp.getName() + ' ';
                if (!temp.getFertile()) {
                    if (temp.getAge() < 15) {
                        explanation = namestring + gameOptions.language.bbIsTooYoung
                    } else if (temp.getHealth() < 50) {
                        explanation = namestring + gameOptions.language.bbIsBadHealth
                    } else if (temp.getAge() > 38) {
                        explanation = namestring + gameOptions.language.bbHasLostToAge
                    }
                } else if (farmModel.getFamilyMembers() > 7) {
                    explanation = namestring + gameOptions.language.bbIDontWant
                } else {
                    explanation = namestring + gameOptions.language.bbIsNowPreg;
                    farmModel.setFamilyMemberPregnant(i, true)
                }
                this.familyMemberInfoBox.setContent(farmModel.family[farmModel.getFamilyMemberById(farmModel.main.whichFamilyMemberActive)])
            }
        }
        this.closeAllOptions();
        this.haveBabyInfoBox.setContent(explanation);
        this.scene.wake(this.haveBabyInfoBox)
    }
    closeHaveBaby() {
        this.scene.sleep(this.haveBabyInfoBox)
    }
    clickedAppointFamilyHead() {
        var namestring = '';
        var explanation = '';
        var t = main.whichFamilyMemberActive;
        for (var i = 0; i < farmModel.family.length; i++) {
            let temp = farmModel.family[i];
            if (temp.getID() == t) {
                namestring = temp.getName()
            }
        }
        explanation = gameOptions.language.appoint1 + namestring + gameOptions.language.appoint2;
        this.closeAllOptions();
        this.familyHeadInfoBox.setContent(explanation);
        this.scene.wake(this.familyHeadInfoBox)
    }
    acceptFamilyHead() {
        this.scene.sleep(this.familyHeadInfoBox);
        this.familyMemberInfoBox.setContent(farmModel.family[farmModel.getFamilyMemberById(farmModel.main.whichFamilyMemberActive)])
    }
    closeFamilyHead() {
        this.scene.sleep(this.familyHeadInfoBox)
    }
    closeLeaveFarm() {
        this.scene.sleep(this.leaveFarmInfoBox)
    }
    closeAllOptions() {
        this.scene.sleep(this.familyHeadInfoBox);
        this.scene.sleep(this.leaveFarmInfoBox);
        this.scene.sleep(this.haveBabyInfoBox);
        this.scene.sleep(this.marriageInfoBox);
        this.scene.sleep(this.goToSchoolInfoBox);
        this.scene.sleep(this.giveMedicineInfoBox)
    }
    clickedLeaveFarm() {
        var t = main.whichFamilyMemberActive;
        var fam = farmModel.family;
        var p = fam[farmModel.getFamilyMemberById(t)];
        var explanation = '';
        var genderName = p.getGender() ? gameOptions.language.wordHim : gameOptions.language.wordHer;
        var tAge = p.getAge();
        var tName = p.getName();
        var tEducation = p.getEducationLvl();
        var tHealth = p.getHealth();
        var tPregnant = p.getPregnant();
        var tPoints = 0;
        var tPrice = 0;
        var canLeave = true;
        if (tAge < 3) {
            explanation = tName + gameOptions.language.leaveFB1 + genderName + gameOptions.language.leaveFB2 + genderName + gameOptions.language.leaveFB3;
            tPoints = 0;
            tPrice = main.leaveFarmBaby
        } else if (tAge < 18) {
            if (tEducation < 2) {
                tPoints = 0;
                tPrice = Math.round((main.leaveFarmChildNoEd * tHealth) / 100);
                explanation = tName + gameOptions.language.leaveFC1 + genderName + gameOptions.language.leaveFC2 + tPrice + gameOptions.language.leaveFC3 + tName + gameOptions.language.leaveFC4
            } else {
                tPoints = 1;
                tPrice = Math.round((main.leaveFarmChildEd * tHealth) / 100);
                explanation = tName + gameOptions.language.leaveFCE1 + tPrice + gameOptions.language.leaveFCE2 + tName + gameOptions.language.leaveFCE3
            }
        } else {
            if (tEducation < 2) {
                tPoints = 2;
                tPrice = Math.round((main.leaveFarmAdultNoEd * tHealth) / 100);
                explanation = tName + gameOptions.language.leaveFA1 + tPrice + gameOptions.language.leaveFA2 + tName
            } else if (tEducation < 6) {
                tPoints = 3;
                tPrice = Math.round((main.leaveFarmAdultSomeEd * tHealth) / 100);
                explanation = tName + gameOptions.language.leaveFAE1 + tPrice + gameOptions.language.leaveFAE2
            } else {
                tPoints = 5;
                tPrice = Math.round((main.leaveFarmAdultHighEd * tHealth) / 100);
                explanation = tName + gameOptions.language.leaveFAHE1 + tPrice + gameOptions.language.leaveFAHE2
            }
        }
        if (fam.length == 1) {
            explanation += gameOptions.language.leaveFLast
        }
        if (tPregnant) {
            explanation = tName + gameOptions.language.leaveFPreg;
            canLeave = false
        }
        this.closeAllOptions();
        main.leaveFarmReward = tPrice;
        main.leaveFarmPointsAwarded = tPoints;
        this.leaveFarmInfoBox.setContent(explanation, canLeave);
        this.scene.wake(this.leaveFarmInfoBox)
    }
    leaveFarmAccepted() {
        this.scene.sleep(this.leaveFarmInfoBox);
        this.scene.sleep(this.familyMemberInfoBox);
        farmModel.farmGraphicViewPaint()
    }
    handleGameOver() {
        this.playButton.disableInteractive();
        this.sellButton.disableInteractive();
        this.setStuffInvisible();
        this.familyView.setAllUnclickable();
        this.cropMenu.disableInteractive();
        this.livestockMenu.disableInteractive();
        this.toolMenu.disableInteractive();
        this.constructionMenu.disableInteractive();
        this.projectMenu.disableInteractive();
        this.gameOverScreen.setContent(main);
        this.scene.wake(this.gameOverScreen)
    }
    clickedMarry() {
        var t = main.whichFamilyMemberActive;
        var edu;
        var health;
        var age;
        var male;
        var tName;
        var tHead;
        var explanation;
        var genderName;
        var marPrice;
        var marBefore;
        var proposalFound;
        if (!main.marriageThisYear && (farmModel.getFamilyMembers() < 8)) {
            var fam = farmModel.getFamily();
            for (var i = 0; i < fam.length; i++) {
                if (fam[i].getID() == t) {
                    edu = fam[i].getEducationLvl();
                    health = fam[i].getHealth();
                    age = fam[i].getAge();
                    male = fam[i].getGender();
                    tName = fam[i].getName();
                    tHead = fam[i].getHeadOfFamily();
                    marBefore = fam[i].getMarriedBefore()
                }
            }
            marPrice = 9000;
            if (marPrice < 1) {
                marPrice = 2
            }
            if (marBefore) {
                marPrice = Math.ceil(marPrice / 10)
            }
            main.marriageProposalPrice = marPrice;
            if (male) {
                explanation = tName + gameOptions.language.couldMarryWoman + marPrice
            } else {
                explanation = tName + gameOptions.language.couldMarryMan + marPrice
            }
            if (tHead) {
                explanation += gameOptions.language.willMoveIn
            } else {
                explanation += ". " + tName + gameOptions.language.willMoveOut
            }
            proposalFound = true
        } else {
            explanation = gameOptions.language.noSpouseFound;
            proposalFound = false
        }
        this.marriageInfoBox.setContent(explanation, proposalFound);
        this.scene.wake(this.marriageInfoBox)
    }
    marriageAccepted() {
        var t = main.whichFamilyMemberActive;
        var fam = farmModel.getFamily();
        var headGet;
        var maleGet;
        var age;
        var educationLvl;
        var newAge, newEducation;
        for (var i = 0; i < fam.length; i++) {
            if (fam[i].getID() == t) {
                headGet = fam[i].getHeadOfFamily();
                maleGet = fam[i].getGender();
                age = fam[i].getAge();
                educationLvl = fam[i].getEducationLvl()
            }
        }
        if (headGet) {
            if (maleGet) {
                newAge = Math.min(29 + Math.floor(Math.random() * 6), age + (Math.floor(Math.random() * 4) - 2));
                newEducation = Math.max(0, educationLvl + (Math.floor(Math.random() * 4) - 2));
                if (newEducation > 10)
                    newEducation = 10;
                farmModel.addFamilyMember(new Person(false,newAge,true,farmModel.uniquePersonIDCounter++,main));
                var newWifeId;
                var oldHusbandId;
                fam = farmModel.getFamily();
                for (i = 0; i < fam.length; i++) {
                    if (fam[i].getSpouse()) {
                        newWifeId = fam[i].getID()
                    } else if (fam[i].getHeadOfFamily()) {
                        oldHusbandId = fam[i].getID()
                    }
                }
                farmModel.marryById(oldHusbandId, newWifeId);
                farmModel.setPersonEducationLvl(newWifeId, newEducation)
            } else {
                newAge = age + (Math.floor(Math.random() * 5));
                newEducation = Math.max(0, educationLvl + (Math.floor(Math.random() * 4) - 2));
                farmModel.addFamilyMember(new Person(true,newAge,true,farmModel.uniquePersonIDCounter++,main));
                var newHusbandId;
                var oldWifeId;
                fam = farmModel.getFamily();
                for (i = 0; i < fam.length; i++) {
                    if (fam[i].getSpouse()) {
                        newHusbandId = fam[i].getID()
                    } else if (fam[i].getHeadOfFamily()) {
                        oldWifeId = fam[i].getID()
                    }
                }
                farmModel.marryById(oldWifeId, newHusbandId);
                farmModel.setPersonEducationLvl(newHusbandId, newEducation)
            }
        } else {
            farmModel.removeOneFamilyMember(farmModel.getFamilyMemberById(main.whichFamilyMemberActive))
        }
        farmModel.setMoney(farmModel.getMoney() + main.marriageProposalPrice);
        main.newscore += main.marriagePointsAwarded;
        this.scene.sleep(this.familyMemberInfoBox);
        this.scene.sleep(this.marriageInfoBox);
        farmModel.farmGraphicViewPaint();
        main.marriageThisYear = true;
        main.totalMarriageCount++
    }
    closeMarriageInfoBox() {
        this.scene.sleep(this.marriageInfoBox)
    }
    buildFinalProject() {
        main.numberOfProjectsBuilt = 6;
        var price = 0;
        if (!main.infrastructureBuilt) {
            price = main.infrastructurePrice;
            main.infrastructureBuilt = true
        } else if (!main.communicationsBuilt) {
            price = main.communicationsPrice;
            main.communicationsBuilt = true
        } else if (!main.schoolBuilt) {
            price = main.schoolPrice;
            main.schoolBuilt = true
        } else if (!main.clinicBuilt) {
            price = main.clinicPrice;
            main.clinicBuilt = true
        } else if (!main.representativeBuilt) {
            price = main.representativePrice;
            main.representativeBuilt = true
        } else if (!main.insuranceBuilt) {
            price = main.insurancePrice;
            main.insuranceBuilt = true
        } else if (!main.expansionBuilt) {
            price = main.expansionPrice;
            main.expansionBuilt = true
        }
        farmModel.setMoney(farmModel.getMoney() - price);
        farmModel.farmGraphicViewPaint();
        this.showParticleSplash(main.investment.getLinkageName());
        this.updateButtons();
        this.closeWarningBox()
    }
    closeWarningBox() {
        this.scene.sleep(this.warningBox);
        this.hideItemDetails()
    }
    paintLabelsAndProjects(money, turn) {
        this.moneyText.setText(money);
        this.turnTextLabel.setText(turn);
        this.updateButtons();
        this.toggleInteractive(this.project_communications, main.communicationsBuilt);
        this.toggleInteractive(this.project_road, main.infrastructureBuilt);
        this.toggleInteractive(this.project_school, main.schoolBuilt);
        this.toggleInteractive(this.project_clinic, main.clinicBuilt);
        this.toggleInteractive(this.project_representative, main.representativeBuilt);
        this.toggleInteractive(this.project_insurance, main.insuranceBuilt);
        this.toggleInteractive(this.project_expansion, main.expansionBuilt);
    }
    showProjectInfoBox(project) {
        if (main.gamePhase == 1) {
            let tt = project.frame.name;
            let tText;
            switch (tt) {
            case "project-road":
                tText = gameOptions.language.roadDesc;
                break;
            case "project-communications":
                tText = gameOptions.language.comDesc;
                break;
            case "project-clinic":
                tText = gameOptions.language.clinDesc;
                break;
            case "project-school":
                tText = gameOptions.language.schoolDesc;
                break;
            case "project-representative":
                tText = gameOptions.language.repDesc;
                break;
            case "project-insurance":
                tText = gameOptions.language.insDesc;
                break;
            case "project-expansion":
                tText = gameOptions.language.expDesc;
                break;
            default:
                tText = "";
                break
            }
            eventsCenter.emit('update-projectinfobox', tText)
        }
    }
    prepareForPlayerActions() {
        main.gamePhase = 1;
        this.setStuffInvisible();
        this.setStuffVisible();
        main.whichFamilyMemberActive = 0;
        main.marriageProposalPrice = 0;
        main.leaveFarmReward = 0;
        main.leaveFarmPointsAwarded = 0;
        main.cornPrice = 5 + (Math.floor(Math.random() * 9));
        main.wheatPrice = 8 + (Math.floor(Math.random() * 13));
        main.cottonPrice = 15 + (Math.floor(Math.random() * 9));
        main.peanutPrice = 23 + (Math.floor(Math.random() * 5));
        main.cornMultiplier = (0.95 + (Math.random() * 0.15)) * main.cornPrice;
        main.wheatMultiplier = (0.90 + (Math.random() * 0.25)) * main.wheatPrice;
        main.cottonMultiplier = (0.85 + (Math.random() * 0.35)) * main.cottonPrice;
        main.peanutMultiplier = (0.80 + (Math.random() * 0.45)) * main.peanutPrice;
        if (main.infrastructureBuilt) {
            main.cornPrice--;
            main.wheatPrice--;
            main.cottonPrice--;
            main.peanutPrice--
        }
        if (main.communicationsBuilt) {
            main.cornMultiplier *= 1.1;
            main.wheatMultiplier *= 1.1;
            main.cottonMultiplier *= 1.1;
            main.peanutMultiplier *= 1.1
        }
        main.sellChickenPrice = Math.round(main.chickenPrice / 2 + Math.random() * 10 - 5);
        main.sellPigPrice = Math.round(main.pigPrice / 2 + Math.random() * 10 - 5);
        main.sellCowPrice = Math.round(main.cowPrice / 2 + Math.random() * 10 - 5);
        main.sellElephantPrice = Math.round(main.elephantPrice / 2 + Math.random() * 10 - 5);
        main.sellWellPrice = Math.round(main.wellPrice / 2 + Math.random() * 10 - 5);
        main.sellShedPrice = Math.round(main.shedPrice / 2 + Math.random() * 10 - 5);
        main.sellBarnPrice = Math.round(main.barnPrice / 2 + Math.random() * 10 - 5);
        main.sellShovelPrice = Math.round(main.shovelPrice / 2 + Math.random() * 10 - 5);
        main.sellScythePrice = Math.round(main.scythePrice / 2 + Math.random() * 10 - 5);
        main.sellPlowPrice = Math.round(main.plowPrice / 2 + Math.random() * 10 - 5);
        main.sellTractorPrice = Math.round(main.tractorPrice / 2 + Math.random() * 10 - 5);
        main.sellHarvesterPrice = Math.round(main.harvesterPrice / 2 + Math.random() * 10 - 5);
        main.activityCounter = 0;
        main.familyMemberDied = false;
        main.starvation = false;
        main.childBornThisYear = false;
        main.marriageThisYear = false;
        if (Math.random() < 0.6) {
            main.marriageThisYear = true
        }
        farmModel.updateWorkEfficiency();
        farmModel.farmGraphicViewPaint();
        main.annualExpenses = main.livingCostsPP * farmModel.getFamilyMembers() + (Math.floor(Math.random() * 5) - 2);
        this.disposeMC.disableInteractive();
        this.setTilesVisibility("cropTile", false);
        this.setTilesVisibility("constructionTile", false);
        this.setTilesVisibility("toolTile", false);
        this.setTilesVisibility("livestockTile", false);
        this.initButtons();
        this.cropMenu.setInteractive({
            useHandCursor: true
        });
        this.livestockMenu.setInteractive({
            useHandCursor: true
        });
        this.toolMenu.setInteractive({
            useHandCursor: true
        });
        this.constructionMenu.setInteractive({
            useHandCursor: true
        });
        this.projectMenu.setInteractive({
            useHandCursor: true
        });
        this.setButtonDependencies();
        this.updateButtons();
        this.setButtonPrices();
        this.initTiles();
        this.sellButton.setInteractive({
            useHandCursor: true
        });
        for (let i = 0; i < this.projects.length; i++) {
            this.projects[i].setInteractive({
                useHandCursor: true
            })
        }
        this.playButton.setInteractive({
            useHandCursor: true
        })
    }
    initButtons() {
        for (var i of this.cropMenuChoices.buttons) {
            i.price = main[i.name + 'Price']
        }
        for (var i of this.livestockMenuChoices.buttons) {
            i.price = main[i.name + 'Price']
        }
        for (var i of this.toolMenuChoices.buttons) {
            i.price = main[i.name + 'Price']
        }
        for (var i of this.constructionMenuChoices.buttons) {
            i.price = main[i.name + 'Price']
        }
        for (var i of this.projectMenuChoices.buttons) {
            i.price = main[i.name + 'Price']
        }
    }
    updateButtons() {
        var m = farmModel.getMoney();
        var res;
        for (var i of this.cropMenuChoices.buttons) {
            this.cropMenuChoices.setGrayVisible(i, m < i.price);
            if (i.name == 'poppy') {
                this.cropMenuChoices.setPriceLabelText(i);
                if (main.poppyAmount > 0) {
                    this.cropMenuChoices.setGrayVisible(i, !main.longTimeEffectOpium)
                } else {
                    this.cropMenuChoices.setGrayVisible(i, true)
                }
            }
        }
        for (var i of this.livestockMenuChoices.buttons) {
            if (i.price <= m) {
                res = false;
                if (i.dependency.length > 0) {
                    for (var j of i.dependency) {
                        if (!farmModel.checkInvestment(j)) {
                            res = true;
                            break
                        }
                    }
                }
            } else {
                res = true
            }
            this.livestockMenuChoices.setGrayVisible(i, res)
        }
        for (var i of this.toolMenuChoices.buttons) {
            this.toolMenuChoices.setGrayVisible(i, i.price > m)
        }
        for (var i of this.constructionMenuChoices.buttons) {
            this.constructionMenuChoices.setGrayVisible(i, i.price > m)
        }
        for (var i of this.projectMenuChoices.buttons) {
            let setCheck = false;
            console.log(i.name);
            if (i.name == 'communications' && main.communicationsBuilt) {
                setCheck = true
            } else if (i.name == 'infrastructure' && main.infrastructureBuilt) {
                setCheck = true
            } else if (i.name == 'school' && main.schoolBuilt) {
                setCheck = true
            } else if (i.name == 'clinic' && main.clinicBuilt) {
                setCheck = true
            } else if (i.name == 'representative' && main.representativeBuilt) {
                setCheck = true
            } else if (i.name == 'insurance' && main.insuranceBuilt) {
                setCheck = true
            } else if (i.name == 'expansion' && main.expansionBuilt) {
                setCheck = true
            }
            if (setCheck) {
                this.projectMenuChoices.setGrayVisible(i, false);
                this.projectMenuChoices.setGreenVisible(i, true)
            } else {
                this.projectMenuChoices.setGreenVisible(i, false);
                this.projectMenuChoices.setGrayVisible(i, i.price > m);
                if (i.name == 'insurance' && !main.representativeBuilt) {
                    this.projectMenuChoices.setGrayVisible(i, true)
                }
            }
        }
    }
    setButtonPrices() {
        this.cropMenuChoices.updateButtonPrices();
        this.livestockMenuChoices.updateButtonPrices();
        this.toolMenuChoices.updateButtonPrices();
        this.constructionMenuChoices.updateButtonPrices();
        this.projectMenuChoices.updateButtonPrices()
    }
    setButtonDependencies() {
        this.cropMenuChoices.getButton('corn').dependency = main.cornDependency;
        this.cropMenuChoices.getButton('wheat').dependency = main.wheatDependency;
        this.cropMenuChoices.getButton('cotton').dependency = main.cottonDependency;
        this.cropMenuChoices.getButton('peanut').dependency = main.peanutDependency;
        this.cropMenuChoices.getButton('poppy').dependency = main.poppyDependency;
        this.livestockMenuChoices.getButton('chicken').dependency = main.chickenDependency;
        this.livestockMenuChoices.getButton('pig').dependency = main.pigDependency;
        this.livestockMenuChoices.getButton('cow').dependency = main.cowDependency;
        this.livestockMenuChoices.getButton('elephant').dependency = main.elephantDependency;
        this.toolMenuChoices.getButton('shovel').dependency = main.shovelDependency;
        this.toolMenuChoices.getButton('scythe').dependency = main.scytheDependency;
        this.toolMenuChoices.getButton('plow').dependency = main.plowDependency;
        this.toolMenuChoices.getButton('tractor').dependency = main.tractorDependency;
        this.toolMenuChoices.getButton('harvester').dependency = main.harvesterDependency;
        this.constructionMenuChoices.getButton('shed').dependency = main.shedDependency;
        this.constructionMenuChoices.getButton('well').dependency = main.wellDependency;
        this.constructionMenuChoices.getButton('barn').dependency = main.barnDependency;
        this.projectMenuChoices.getButton('communications').dependency = main.communicationsDependency;
        this.projectMenuChoices.getButton('school').dependency = main.schoolDependency;
        this.projectMenuChoices.getButton('infrastructure').dependency = main.infrastructureDependency;
        this.projectMenuChoices.getButton('clinic').dependency = main.clinicDependency;
        this.projectMenuChoices.getButton('representative').dependency = main.representativeDependency;
        this.projectMenuChoices.getButton('insurance').dependency = main.insuranceDependency;
        this.projectMenuChoices.getButton('expansion').dependency = main.expansionDependency;
    }
    drawTileShape(sprite) {
        var graphics = this.add.graphics({
            x: sprite.x - sprite.displayOriginX,
            y: sprite.y - sprite.displayOriginY
        });
        graphics.lineStyle(1, 0x00aa00);
        graphics.beginPath();
        var shape = sprite.shape;
        graphics.moveTo(shape.points[0].x, shape.points[0].y);
        for (var i = 1; i < shape.points.length; i++) {
            graphics.lineTo(shape.points[i].x, shape.points[i].y)
        }
        graphics.closePath();
        graphics.strokePath()
    }
    initTiles() {
        let te;
        let i;
        for (i = 1; i <= 18 + main.extraTiles; i++) {
            te = this['cropTile' + i];
            te.setInteractive();
            te.on('pointerdown', function(t) {
                if (t.enabled) {
                    main.investment.setPositionMC(t);
                    main.investment.setClickPosition(this.input.x, this.input.y);
                    farmModel.addInvestment(main.investment);
                    farmModel.farmGraphicViewPaint();
                    main.activityCounter++;
                    t.visible = false;
                    t.enabled = false;
                    let temp = main.investment.getLinkageName();
                    main.investment = this.classForName(temp);
                    var lastPoppy = ((main.investment.getPrice() == 0) && (main[main.investment.getLinkageName() + "Amount"] <= 0)) ? true : false;
                    if ((farmModel.getMoney() < main.investment.getPrice()) || lastPoppy) {
                        this.handleClickDisposeMC1()
                    }
                }
            }
            .bind(this, te))
        }
        for (i = 1; i <= 7; i++) {
            te = this['constructionTile' + i];
            te.setInteractive();
            te.on('pointerdown', function(t) {
                if (t.enabled) {
                    main.investment.setPositionMC(t);
                    main.investment.setClickPosition(this.input.x, this.input.y);
                    farmModel.addInvestment(main.investment);
                    farmModel.farmGraphicViewPaint();
                    t.visible = false;
                    t.enabled = false;
                    let temp = main.investment.getLinkageName();
                    main.investment = this.classForName(temp);
                    if (farmModel.getMoney() < main.investment.getPrice()) {
                        this.handleClickDisposeMC1()
                    }
                }
            }
            .bind(this, te))
        }
        for (i = 1; i <= 4; i++) {
            te = this['toolTile' + i];
            te.setInteractive();
            te.on('pointerdown', function(t) {
                if (t.enabled) {
                    main.investment.setPositionMC(t);
                    main.investment.setClickPosition(this.input.x, this.input.y);
                    farmModel.addInvestment(main.investment);
                    farmModel.farmGraphicViewPaint();
                    t.visible = false;
                    t.enabled = false;
                    let temp = main.investment.getLinkageName();
                    main.investment = this.classForName(temp);
                    if (farmModel.getMoney() < main.investment.getPrice()) {
                        this.handleClickDisposeMC1()
                    }
                }
            }
            .bind(this, te))
        }
        for (i = 1; i <= 8; i++) {
            te = this['livestockTile' + i];
            te.setInteractive();
            te.on('pointerdown', function(t) {
                if (t.enabled) {
                    main.investment.setPositionMC(t);
                    main.investment.setClickPosition(this.input.x, this.input.y);
                    farmModel.addInvestment(main.investment);
                    farmModel.farmGraphicViewPaint();
                    t.visible = false;
                    t.enabled = false;
                    let temp = main.investment.getLinkageName();
                    main.investment = this.classForName(temp);
                    if (farmModel.getMoney() < main.investment.getPrice()) {
                        this.handleClickDisposeMC1()
                    }
                }
            }
            .bind(this, te))
        }
    }
    handleMenuClick(pointer, what) {
        this.closedFamilyMembers();
        this.handleClickDisposeMC1();
        if (pointer == this.cropMenu) {
            if (!this.cropMenuChoices.expanded) {
                this.cropMenuChoices.expand()
            } else {
                this.cropMenuChoices.contract()
            }
        } else if (pointer == this.livestockMenu) {
            if (!this.livestockMenuChoices.expanded) {
                this.livestockMenuChoices.expand()
            } else {
                this.livestockMenuChoices.contract()
            }
        } else if (pointer == this.toolMenu) {
            if (!this.toolMenuChoices.expanded) {
                this.toolMenuChoices.expand()
            } else {
                this.toolMenuChoices.contract()
            }
        } else if (pointer == this.constructionMenu) {
            if (!this.constructionMenuChoices.expanded) {
                this.constructionMenuChoices.expand()
            } else {
                this.constructionMenuChoices.contract()
            }
        } else if (pointer == this.projectMenu) {
            if (!this.projectMenuChoices.expanded) {
                this.projectMenuChoices.expand()
            } else {
                this.projectMenuChoices.contract()
            }
        }
    }
    sellInfoBoxExitButtonClick() {
        this.scene.sleep('SellInfoBox');
        this.cropMenu.setInteractive({
            useHandCursor: true
        });
        this.livestockMenu.setInteractive({
            useHandCursor: true
        });
        this.toolMenu.setInteractive({
            useHandCursor: true
        });
        this.constructionMenu.setInteractive({
            useHandCursor: true
        });
        this.projectMenu.setInteractive({
            useHandCursor: true
        });
        farmModel.farmGraphicViewPaint()
    }
    closeStuffForSellInfoBox() {
        this.closedFamilyMembers();
        this.scene.sleep(this.projectInfoBox);
        this.familyView.setAllUnclickable();
        this.hideItemDetails();
        this.cropMenuChoices.contract();
        this.livestockMenuChoices.contract();
        this.toolMenuChoices.contract();
        this.constructionMenuChoices.contract();
        this.projectMenuChoices.contract();
        this.cropMenu.disableInteractive();
        this.livestockMenu.disableInteractive();
        this.toolMenu.disableInteractive();
        this.constructionMenu.disableInteractive();
        this.projectMenu.disableInteractive()
    }
    handleSellButtonClick(pointer) {
        if (this.scene.isActive('SellInfoBox')) {
            this.sellInfoBoxExitButtonClick()
        } else {
            this.closeStuffForSellInfoBox();
            this.scene.wake('SellInfoBox')
        }
    }
    submitSellInfoData(pointer) {
        main.sellChickenAvail = farmModel.checkInvestmentCount("chicken");
        main.sellShovelAvail = farmModel.checkInvestmentCount("shovel");
        main.sellPigAvail = farmModel.checkInvestmentCount("pig");
        main.sellCowAvail = farmModel.checkInvestmentCount("cow");
        main.sellElephantAvail = farmModel.checkInvestmentCount("elephant");
        main.sellWellAvail = farmModel.checkInvestmentCount("well");
        main.sellShedAvail = farmModel.checkInvestmentCount("shed");
        main.sellBarnAvail = farmModel.checkInvestmentCount("barn");
        main.sellScytheAvail = farmModel.checkInvestmentCount("scythe");
        main.sellPlowAvail = farmModel.checkInvestmentCount("plow");
        main.sellTractorAvail = farmModel.checkInvestmentCount("tractor");
        main.sellHarvesterAvail = farmModel.checkInvestmentCount("harvester");
        var arr = [[main.sellChickenAvail, main.sellChickenPrice], [main.sellPigAvail, main.sellPigPrice], [main.sellCowAvail, main.sellCowPrice], [main.sellElephantAvail, main.sellElephantPrice], [main.sellShovelAvail, main.sellShovelPrice], [main.sellScytheAvail, main.sellScythePrice], [main.sellPlowAvail, main.sellPlowPrice], [main.sellTractorAvail, main.sellTractorPrice], [main.sellWellAvail, main.sellWellPrice], [main.sellShedAvail, main.sellShedPrice], [main.sellBarnAvail, main.sellBarnPrice], [main.sellHarvesterAvail, main.sellHarvesterPrice]];
        eventsCenter.emit('submit-sellinfo-data', arr)
    }
    handlePlayButtonClick(pointer) {
        var cond = (typeof this.IObox.picTargetMC !== "undefined");
        if (cond) {
            this.hideItemDetails();
            this.sellInfoBoxExitButtonClick();
            this.closedFamilyMembers();
            this.scene.sleep(this.projectInfoBox);
            this.familyView.setAllUnclickable();
            this.project_communications.disableInteractive();
            this.project_road.disableInteractive();
            this.project_school.disableInteractive();
            this.project_clinic.disableInteractive();
            this.project_representative.disableInteractive();
            this.project_insurance.disableInteractive();
            this.project_expansion.disableInteractive();
            main.playerActivity.push(main.activityCounter);
            main.playerActivity.shift();
            main.whoDiedFromLowHealth = farmModel.ageing();
            this.makeAnnualEvent();
            this.phase2to4();
            this.scene.wake(this.nightScene);
            this.nightScene.startAnim();
            main.turnCount++
        }
    }
    makeAnnualEvent() {
        var c = 0;
        var cm = main.playerActivity.length;
        for (var i = 0; i < cm; i++) {
            c += main.playerActivity[i]
        }
        if (c < 4) {
            this.generateNormalEvent()
        } else if (((farmModel.getMoney() > main.maxMoney || farmModel.getInvestmentsValue() > main.maxMoney) && (Math.random() < 0.5)) || (Math.random() < 0.15)) {
            this.generateRichEvent()
        } else {
            this.generateNormalEvent()
        }
        //main.currentEvent = this.allEvents.AnnualEvents.VeryGoodSeasonEvent;

        farmModel.handleEvent();
        farmModel.calculate(this.IObox)
    }
    generateAngryMobEvent() {
        main.currentEvent = this.allEvents.AnnualEvents.AngryMobEvent
    }
    generateRichEvent() {
        main.currentEvent = this.allEvents.AnnualEvents.GoodSeasonEvent;
        var r = Math.floor(Math.random() * 6) + 1;
        switch (r) {
        case 1:
            main.currentEvent = this.allEvents.AnnualEvents.MarketPricesEvent;
            break;
        case 2:
            main.currentEvent = this.allEvents.AnnualEvents.NationalBankEvent;
            break;
        case 3:
            main.currentEvent = this.allEvents.AnnualEvents.SicknessEvent;
            break;
        case 4:
            main.currentEvent = this.allEvents.AnnualEvents.CivilWarEvent;
            break;
        case 5:
            main.currentEvent = this.allEvents.AnnualEvents.GuerillasEvent;
            break;
        case 6:
            main.currentEvent = this.allEvents.AnnualEvents.CorruptOfficialsEvent;
            break;
        default:
            console.log("invalid index in playGame.generateRichEvent()");
            break
        }
    }
    generateNormalEvent() {
        var r = Math.floor(Math.random() * 15) + 1;
        switch (r) {
        case 1:
            main.currentEvent = this.allEvents.AnnualEvents.DrySeasonEvent;
            break;
        case 2:
            main.currentEvent = this.allEvents.AnnualEvents.RefugeesEvent;
            break;
        case 3:
            main.currentEvent = this.allEvents.AnnualEvents.CornFailedEvent;
            break;
        case 4:
            main.currentEvent = this.allEvents.AnnualEvents.WheatFailedEvent;
            break;
        case 5:
            main.currentEvent = this.allEvents.AnnualEvents.CottonFailedEvent;
            break;
        case 6:
            main.currentEvent = this.allEvents.AnnualEvents.PeanutFailedEvent;
            break;
        case 7:
            main.currentEvent = this.allEvents.AnnualEvents.ChickenDiseaseEvent;
            break;
        case 8:
            main.currentEvent = this.allEvents.AnnualEvents.PigDiseaseEvent;
            break;
        case 9:
            main.currentEvent = this.allEvents.AnnualEvents.CattleDiseaseEvent;
            break;
        case 10:
            main.currentEvent = this.allEvents.AnnualEvents.GoodSeasonEvent;
            break;
        case 11:
            main.currentEvent = this.allEvents.AnnualEvents.VeryGoodSeasonEvent;
            break;
        case 12:
            main.currentEvent = this.allEvents.AnnualEvents.BushFireEvent;
            break;
        case 13:
            main.currentEvent = this.allEvents.AnnualEvents.WellCavesInEvent;
            break;
        case 14:
            main.currentEvent = this.allEvents.AnnualEvents.ElephantPoachersEvent;
            break;
        case 15:
            main.currentEvent = this.allEvents.AnnualEvents.TheftEvent;
            break;
        default:
            console.log("Invalid index in playGame.generateNormalEvent()");
            break
        }
    }
    phase2to4() {
        main.gamePhase = 2;
        this.frames_for_menu.setVisible(false);
        this.toggleInteractive(this.playButton, false);
        this.toggleInteractive(this.sellButton, false);
        this.cropMenuChoices.contract();
        this.livestockMenuChoices.contract();
        this.toolMenuChoices.contract();
        this.constructionMenuChoices.contract();
        this.projectMenuChoices.contract();
        this.cropMenu.setVisible(false);
        this.livestockMenu.setVisible(false);
        this.toolMenu.setVisible(false);
        this.constructionMenu.setVisible(false);
        this.projectMenu.setVisible(false);
        this.moneyLabel.setVisible(false);
        this.moneyText.setVisible(false);
        this.roundLabel.setVisible(false);
        this.turnTextLabel.setVisible(false);
        this.hideItemDetails()
    }
    handleCloseIOBox() {
        this.scene.sleep(this.IObox);
        this.chem_barrel.setVisible(false);
        this.mil_camp.setVisible(false);
        //farmModel.setMoney(1000);
        if (main.numberOfProjectsBuilt >= 6) {
            main.reasonForGameEnd = "win";
            this.handleGameOver();
            return
        }
        if (farmModel.getFamilyMembers() < 1) {
            this.handleGameOver();
            return
        } else {
            farmModel.setAllAtSchool(false);
            if (farmModel.getOldestAge() < 8) {
                main.reasonForGameEnd = "noadultsleft";
                this.handleGameOver();
                return
            }
            if (farmModel.getMoney() >= main.minMoney) {
                this.prepareForPlayerActions()
            } else if ((Math.random() > 0.125) && (Math.random() > main.poorEventCounter)) {
                if (main.poorEventCounter < 0.9) {
                    main.poorEventCounter += 0.1
                }
                var eventFound = false;
                var poorEventId;
                var evArr = [];
                /*for (var j = 0; j < 10; j++) {
                    evArr.push(1);
                    evArr.push(5);
                    evArr.push(6);
                    evArr.push(8);
                    evArr.push(9);
                    evArr.push(10);
                    if (j % 2 == 0) {
                        evArr.push(2);
                        evArr.push(3);
                        evArr.push(7);
                        evArr.push(11)
                    }
                }*/
                evArr.push(4);
                //evArr.push(12);
                while (!eventFound) {
                    poorEventId = evArr[Math.floor(Math.random() * evArr.length)];
                    eventFound = true;
                    if (poorEventId == 5 && farmModel.getFamilyMembers() < 2)
                        eventFound = false;
                    else if (poorEventId == 8 && farmModel.getFamilyMembers() < 2)
                        eventFound = false;
                    else if (poorEventId == 12 && farmModel.getFamilyMembers() > 6)
                        eventFound = false
                }
                if (poorEventId == 4) {
                    main.poppyAmount = Math.ceil(Math.random() * 4) + 900
                }
                this.brokeInfoBox.setContent(poorEventId);
                this.scene.wake(this.brokeInfoBox)
            } else {
                this.prepareForPlayerActions()
            }
        }
        main.effectAffectuatedChemical = false;
        main.effectAffectuatedOpium = false;
        main.effectAffectuatedParamilitary = false;
        main.effectAffectuatedFirewood = false;
        main.effectAffectuatedEpidemic = false;
        main.effectAffectuatedCattleHerding = false;
        main.effectAffectuatedBirds = false;
        main.effectAffectuatedMine = false
    }
    setTilesVisibility(tileType, vis) {
        
        var n = (tileType == "cropTile") ? (18 + main.extraTiles) : (tileType == "constructionTile") ? 7 : (tileType == "toolTile") ? 4 : 8;
        var t;
        console.log("n: " + n);
        for (var i = 1; i <= n; i++) {
            t = this[tileType + i];
            if (t.enabled) {
                t.visible = vis;
                t.anims.play('blink')
            } else {
                t.visible = false
            }
        }
    }
    toggleInteractive(obj, interactive) {
        if (interactive == true) {
            obj.setInteractive().setVisible(true)
        } else {
            obj.disableInteractive().setVisible(false)
        }
    }
    setStuffInvisible() {
        this.toggleInteractive(this.project_communications, main.communicationsBuilt);
        this.toggleInteractive(this.project_road, main.infrastructureBuilt);
        this.toggleInteractive(this.project_school, main.schoolBuilt);
        this.toggleInteractive(this.project_clinic, main.clinicBuilt);
        this.toggleInteractive(this.project_representative, main.representativeBuilt);
        this.toggleInteractive(this.project_insurance, main.insuranceBuilt);
        this.toggleInteractive(this.project_expansion, main.expansionBuilt);
        this.scene.sleep(this.projectInfoBox);
        this.scene.sleep(this.brokeInfoBox);
        this.scene.sleep(this.warningBox);
        this.scene.sleep(this.sellInfoBox);
        this.scene.sleep(this.IObox);
        this.scene.sleep(this.marriageInfoBox);
        this.scene.sleep(this.leaveFarmInfoBox);
        this.scene.sleep(this.familyHeadInfoBox);
        this.scene.sleep(this.goToSchoolInfoBox);
        this.scene.sleep(this.haveBabyInfoBox);
        this.scene.sleep(this.giveMedicineInfoBox);
        this.scene.sleep(this.familyMemberInfoBox);
        this.project_communications.disableInteractive();
        this.project_road.disableInteractive();
        this.project_school.disableInteractive();
        this.project_clinic.disableInteractive();
        this.project_representative.disableInteractive();
        this.project_insurance.disableInteractive();
        this.project_expansion.disableInteractive();
    }
    setStuffVisible() {
        this.cropMenu.setVisible(true);
        this.livestockMenu.setVisible(true);
        this.toolMenu.setVisible(true);
        this.constructionMenu.setVisible(true);
        this.projectMenu.setVisible(true);
        this.toggleInteractive(this.playButton, true);
        this.toggleInteractive(this.sellButton, true);
        this.frames_for_menu.setVisible(true);
        this.moneyLabel.setVisible(true);
        this.moneyText.setVisible(true);
        this.roundLabel.setVisible(true);
        this.turnTextLabel.setVisible(true)
    }
    handleBrokeEventDeclined() {
        this.scene.sleep(this.brokeInfoBox);
        this.prepareForPlayerActions()
    }
    handleBrokeEvent(id) {
        switch (id) {
        case 1:
            farmModel.setMoney(farmModel.getMoney() + main.brokeEarningTribalDance);
            break;
        case 2:
            this.chem_barrel.setVisible(true);
            farmModel.setMoney(farmModel.getMoney() + main.brokeEarningChemical);
            main.longTimeEffectChemical = true;
            break;
        case 3:
            this.mil_camp.setVisible(true);
            farmModel.setMoney(farmModel.getMoney() + main.brokeEarningParamilitary);
            main.longTimeEffectParamilitary = true;
            break;
        case 4:
            farmModel.setMoney(farmModel.getMoney() + main.brokeEarningOpium);
            main.longTimeEffectOpium = true;
            break;
        case 5:
            farmModel.removeOneFamilyMember(Math.floor(Math.random() * farmModel.getFamily().length));
            farmModel.setMoney(farmModel.getMoney() + main.brokeEarningCityMigrate);
            farmModel.farmGraphicViewPaint();
            break;
        case 6:
            farmModel.setMoney(farmModel.getMoney() + main.brokeEarningFirewood);
            main.longTimeEffectFirewood = true;
            break;
        case 7:
            farmModel.setMoney(farmModel.getMoney() + main.brokeEarningEpidemic);
            main.longTimeEffectEpidemic = true;
            break;
        case 8:
            farmModel.removeOneFamilyMember(Math.floor(Math.random() * farmModel.getFamily().length));
            farmModel.setMoney(farmModel.getMoney() + main.brokeEarningSeedTrade);
            farmModel.farmGraphicViewPaint();
            break;
        case 9:
            farmModel.setMoney(farmModel.getMoney() + main.brokeEarningCattleHerding);
            main.longTimeEffectCattleHerding = true;
            break;
        case 10:
            farmModel.setMoney(farmModel.getMoney() + main.brokeEarningBirds);
            main.longTimeEffectBirds = true;
            break;
        case 11:
            farmModel.setMoney(farmModel.getMoney() + main.brokeEarningMine);
            main.longTimeEffectMine = true;
            break;
        case 12:
            farmModel.setMoney(farmModel.getMoney() + main.brokeEarningWitch);
            farmModel.addFamilyMember(new Person(Math.random() > 0.5 ? true : false,5,false,farmModel.uniquePersonIDCounter++,main));
            farmModel.farmGraphicViewPaint();
            break
        }
        this.scene.sleep(this.brokeInfoBox);
        this.prepareForPlayerActions()
    }
    handleBuyProjectButton() {
        if (main.numberOfProjectsBuilt == 6) {
            this.openWarningBox()
        } else {
            var price = 0;
            console.log("bought projects: " + main.investment.getLinkageName());

            switch (main.investment.getLinkageName()) {
            case "infrastructure":
                main.infrastructureBuilt = true;
                price = main.infrastructurePrice;
                break;
            case "communications":
                main.communicationsBuilt = true;
                price = main.communicationsPrice;
                break;
            case "clinic":
                main.clinicBuilt = true;
                price = main.clinicPrice;
                break;
            case "school":
                main.schoolBuilt = true;
                price = main.schoolPrice;
                break;
            case "representative":
                main.representativeBuilt = true;
                price = main.representativePrice;
                break;
            case "insurance":
                main.insuranceBuilt = true;
                price = main.insurancePrice;
                break;
            case "expansion":
                main.extraTiles += 4;
                console.log("extra tiles: " + main.extraTiles);
                main.expansionBuilt = true;
                price = main.expansionPrice;
                break;
            }
            
            main.numberOfProjectsBuilt += 1;
            farmModel.setMoney(farmModel.getMoney() - price);

            farmModel.farmGraphicViewPaint();
            
            this.showParticleSplash(main.investment.getLinkageName());
            this.updateButtons();
            this.hideItemDetails()
        }
    }
    showParticleSplash(name) {
        var dust = this.add.particles('atlas', 'dust-001');
        var sparkle = this.add.particles('atlas', 'white');
        var emitter = dust.createEmitter({
            x: 0,
            y: 0,
            blendMode: 'NORMAL',
            alpha: 0.5,
            scale: {
                start: 1,
                end: 0
            },
            speedx: {
                min: -10,
                max: 10
            },
            speedY: {
                min: -10,
                max: -30
            },
            angle: {
                min: 0,
                max: 360
            },
            quantity: 50,
            lifespan: {
                min: 800,
                max: 1200
            }
        });
        var emitter2 = sparkle.createEmitter({
            blendMode: 'ADD',
            alpha: 0.5,
            scale: {
                start: 0.2,
                end: 0
            },
            speedx: {
                min: -30,
                max: 30
            },
            speedY: {
                min: -30,
                max: -60
            },
            angle: {
                min: 0,
                max: 360
            },
            quantity: 50,
            lifespan: {
                min: 800,
                max: 1200
            }
        });
        if (name == "infrastructure") {
            emitter.setPosition(this.project_road.x, this.project_road.y);
            emitter.setEmitZone({
                source: new Phaser.Geom.Polygon([[0, 0], [960, 60], [960, 90], [0, 0]]),
                type: 'edge',
                quantity: 80
            });
            emitter.explode();
            emitter2.setVisible(false)
        } else if (name == 'communications') {
            emitter2.setPosition(this.project_communications.x, this.project_communications.y);
            emitter2.setEmitZone({
                source: new Phaser.Geom.Ellipse(20,20,100,50),
                type: 'random',
                quantity: 40
            });
            emitter2.explode();
            emitter.setVisible(false)
        } else if (name == 'clinic') {
            emitter.setSpeedX({
                min: -30,
                max: 30
            });
            emitter.setSpeedY({
                min: -30,
                max: -80
            });
            emitter.setLifespan({
                min: 500,
                max: 1400
            });
            emitter.setPosition(this.project_clinic.x, this.project_clinic.y);
            emitter.setEmitZone({
                source: new Phaser.Geom.Polygon([[60, 80], [100, 100], [200, 80], [100, 100]]),
                type: 'edge',
                quantity: 12
            });
            emitter.explode();
            emitter2.setVisible(false)
        } else if (name == 'school') {
            emitter.setSpeedX({
                min: -30,
                max: 30
            });
            emitter.setSpeedY({
                min: -30,
                max: -80
            });
            emitter.setLifespan({
                min: 500,
                max: 1400
            });
            emitter.setPosition(this.project_school.x, this.project_school.y);
            emitter.setEmitZone({
                source: new Phaser.Geom.Polygon([[10, 50], [170, 80], [200, 70], [170, 80]]),
                type: 'edge',
                quantity: 16
            });
            emitter.explode();
            emitter2.setVisible(false)
        } else if (name == 'representative') {
            emitter2.setPosition(this.project_representative.x, this.project_representative.y);
            emitter2.setEmitZone({
                source: new Phaser.Geom.Ellipse(10,10,60,40),
                type: 'random',
                quantity: 16
            });
            emitter2.explode();
            emitter.setVisible(false)
        } else if (name == 'insurance') {
            emitter2.setPosition(this.project_insurance.x, this.project_insurance.y);
            emitter2.setEmitZone({
                source: new Phaser.Geom.Ellipse(0,0,30,30),
                type: 'random',
                quantity: 16
            });
            emitter2.explode();
            emitter.setVisible(false)
        } else if (name == 'expansion') {
            emitter2.setPosition(this.project_expansion.x, this.project_expansion.y);
            emitter2.setEmitZone({
                source: new Phaser.Geom.Ellipse(0,0,30,30),
                type: 'random',
                quantity: 16
            });
            emitter2.explode();
            emitter.setVisible(false)
        } 
        this.time.delayedCall(3000, function() {
            dust.destroy();
            sparkle.destroy()
        })
    }
    openWarningBox() {
        this.scene.wake(this.warningBox)
    }
    handleProjectItemClicked(pointer) {
        console.log("project item clicked: " + pointer.name);
        if (pointer.grayVis) {} else {
            main.investment = this.classForName(pointer.name)
        }
        this.showItemDetails(pointer, true)
    }
    handleMenuItemClicked(pointer) {
        console.log("menu item clicked: " + pointer.name);
        if (pointer.grayVis) {} else {
            main.investment = this.classForName(pointer.name);
            this.handleClickDisposeMC();
            let categoryName = main.investment.getCategoryName().toLowerCase();
            this.setTilesVisibility(categoryName + "Tile", true);
            this.disposeMC.setInteractive()
        }
        this.showItemDetails(pointer, false)
    }
    classForName(name) {
        var price = main[name + 'Price'];
        var multiplier = main[name + 'Multiplier'];
        switch (name) {
        case 'corn':
            return new Corn(price,multiplier);
            break;
        case 'wheat':
            return new Wheat(price,multiplier);
            break;
        case 'cotton':
            return new Cotton(price,multiplier);
            break;
        case 'peanut':
            return new Peanut(price,multiplier);
            break;
        case 'poppy':
            return new Poppy(price,multiplier);
            break;
        case 'chicken':
            return new Chicken(price,multiplier);
            break;
        case 'pig':
            return new Pig(price,multiplier);
            break;
        case 'cow':
            return new Cow(price,multiplier);
            break;
        case 'elephant':
            return new Elephant(price,multiplier);
            break;
        case 'shovel':
            return new Shovel(price,multiplier);
            break;
        case 'scythe':
            return new Scythe(price,multiplier);
            break;
        case 'plow':
            return new Plow(price,multiplier);
            break;
        case 'tractor':
            return new Tractor(price,multiplier);
            break;
        case 'harvester':
            return new Harvester(price,multiplier);
            break;
        case 'shed':
            return new Shed(price,multiplier);
            break;
        case 'well':
            return new Well(price,multiplier);
            break;
        case 'barn':
            return new Barn(price,multiplier);
            break;
        case 'communications':
            return new Communications(price,multiplier);
            break;
        case 'infrastructure':
            return new Infrastructure(price,multiplier);
            break;
        case 'school':
            return new School(price,multiplier);
            break;
        case 'clinic':
            return new Clinic(price,multiplier);
            break;
        case 'representative':
            return new Representative(price,multiplier);
            break;
        case 'insurance':
            return new Insurance(price,multiplier);
            break;
        case 'expansion':
            return new Expansion(price,multiplier);
            break;
        default:
            return new Investment()
        }
    }
    handleClickDisposeMC1() {
        this.handleClickDisposeMC()
    }
    handleClickDisposeMC() {
        this.setTilesVisibility("cropTile", false);
        this.setTilesVisibility("livestockTile", false);
        this.setTilesVisibility("toolTile", false);
        this.setTilesVisibility("constructionTile", false);
        this.disposeMC.disableInteractive();
        this.hideItemDetails()
    }
    showItemDetails(pointer, isProject) {
        let item = pointer.name;
        console.log(item);
        let isCrop = (item == "corn" || item == "wheat" || item == "cotton" || item == "peanut" || item == "poppy") ? true : false;
        let line = gameOptions.language[item + 'tip'].split('.');
        let header = line[0];
        let tip = line[1];
        let dep = main[item + 'Dependency'];
        var i;
        var dl = dep.length;
        var req = '';
        var te;
        for (i = 0; i < dl; i++) {
            te = dep[i];
            req += gameOptions.language[te + 'tip'].split('.')[0];
            if (i < (dl - 1))
                req += ', '
        }
        if (req != '') {
            req = gameOptions.language.need + " " + req
        }
        let price = '$ ' + main[item + "Price"];
        let imageName = pointer.picName;
        let canAffordProject = false;
        let projectNotBuilt = false;
        if (isProject) {
            canAffordProject = !pointer.gray.visible;
            projectNotBuilt = !pointer.green.visible
        }
        this.itemDetails.setContent(isCrop, header, tip, req, price, imageName, isProject, canAffordProject, projectNotBuilt, pointer);
        this.scene.wake(this.itemDetails)
    }
    hideItemDetails() {
        this.scene.sleep(this.itemDetails)
    }
    showNamePrompt() {
        this.namePrompt = this.scene.add('NamePrompt', NamePrompt, true, {
            x: 0,
            y: 0
        });
        eventsCenter.once('clicked-submit-name', this.submittedName.bind(this))
    }
    submittedName(name) {
        this.scene.remove(this.namePrompt);
        if ((name.replace(/\s/g, '').length > 0) && name.replace(/[^a-z0-9áéíóúñü \.,_-]/gim, "").length > 0) {
            var leaderboardId = '1003';
            var functionToCall = "submitScore";
            var data = "playerName=" + name + "&score=" + main.score + "&leaderboard_id=" + leaderboardId + "&functionToCall=" + functionToCall;
            var url = "https://creativesparkstudios.com/api/scores.php";
            $.post(url, data).done(function(data) {
                this.getScoresTest()
            }
            .bind(this))
        }
    }
    getScoresTest() {
        var leaderboardId = '1003';
        var functionToCall = "getCategorizedScores";
        var data = "leaderboard_id=" + leaderboardId + "&functionToCall=" + functionToCall;
        var url = "https://creativesparkstudios.com/api/scores.php";
        $.post(url, data).done(function(data) {
            var xmlDoc = $.parseXML(data);
            var $xml = $(xmlDoc);
            var searchString = 'alltimeScores';
            this.leaderBoard = this.scene.add('Leaderboard', Leaderboard, true);
            var $scores = $xml.find(searchString);
            var i = 1;
            var lb = this.leaderBoard;
            $scores.find('entry').each(function() {
                lb.setLine(i, $(this).find('playerName').text(), $(this).find('score').text());
                i++
            })
        }
        .bind(this))
    }
}
export class FamilyView extends Phaser.Scene {
    constructor() {
        super('FamilyView')
    }
    init(data) {
        this.data = data;
        this.persons = [];
        this.fam = []
    }
    create() {
        eventsCenter.on('paint-family', this.paintFamily, this);
        this.events.on(Phaser.Scenes.Events.SHUTDOWN, () => {
            eventsCenter.off('paint-family', this.paintFamily, this)
        }
        );
        eventsCenter.emit('created-step', 'FamilyView')
    }
    paintFamily(fam) {
        for (var j = 0; j < this.persons.length; j++) {
            this.persons[j].removeAllListeners();
            this.persons[j].destroy();
            this.persons[j] = null
        }
        this.persons = [];
        this.add.displayList.removeAll();
        this.children.removeAll();
        this.fam = fam;
        for (var i = 0; i < fam.length; i++) {
            var frameNumber = fam[i].getImage();
            var x = this.data.x - 7 - (i * 25);
            var y = this.data.y - 50;
            this.persons[i] = this.add.sprite(x, y, 'person').setFrame(frameNumber).setOrigin(0, 0).setScale(0.75).setInteractive({
                useHandCursor: true
            });
            this.persons[i].input.hitArea.setTo(0, 0, 30, 70);
            this.persons[i].on('pointerdown', this.handlePersonClick.bind(this, this.persons[i]))
        }
    }
    setAllUnclickable() {
        for (var j = 0; j < this.persons.length; j++) {
            this.persons[j].removeAllListeners()
        }
    }
    handlePersonClick(pointer, what) {
        var p = null;
        for (var i = 0; i < this.persons.length; i++) {
            this.persons[i].setBlendMode(Phaser.BlendModes.NORMAL);
            if (pointer == this.persons[i]) {
                p = this.fam[i];
                this.persons[i].setBlendMode(Phaser.BlendModes.SCREEN)
            }
        }
        eventsCenter.emit('clicked-family-member', p)
    }
}
export class InvestmentsView extends Phaser.Scene {
    constructor() {
        super('InvestmentsView')
    }
    init(data) {
        this.data = data;
        this.imgs = [];
        this.inv = []
    }
    create() {
        eventsCenter.on('paint-investments', this.paintInvestments, this);
        this.events.on(Phaser.Scenes.Events.SHUTDOWN, () => {
            eventsCenter.off('paint-investments', this.paintInvestments, this)
        }
        );
        eventsCenter.emit('created-step', 'InvestmentsView')
    }
    getNumberForName(inv) {
        switch (inv) {
        case 'corn':
            return '0001';
        case 'wheat':
            return '0002';
        case 'cotton':
            return '0003';
        case 'peanut':
            return '0004';
        case 'poppy':
            return '0005';
        case 'chicken':
            return '0006';
        case 'pig':
            return '0007';
        case 'cow':
            return '0008';
        case 'elephant':
            return '0009';
        case 'shovel':
            return '0010';
        case 'scythe':
            return '0011';
        case 'plow':
            return '0012';
        case 'tractor':
            return '0013';
        case 'harvester':
            return '0014';
        case 'shed':
            return '0015';
        case 'well':
            return '0016';
        case 'barn':
            return '0017';
        default:
            return '0000'
        }
    }
    paintInvestments(inv) {
        this.add.displayList.removeAll();
        this.inv = inv;
        for (var i = 0; i < inv.length; i++) {
            var t = this.inv[i];
            var x = t.clickPositionX;
            var y = t.clickPositionY;
            this.imgs[i] = this.add.image(x, y, 'atlas', 'inv/inv-' + this.getNumberForName(t.getLinkageName())).setOrigin(0.48, 0.41);
            this.imgs[i].inv = t;
            if (!t.hasTweened) {
                this.tweens.add({
                    targets: this.imgs[i],
                    x: t.positionMC.x,
                    y: t.positionMC.y,
                    duration: 300,
                    onComplete: function(tween, target) {
                        target[0].inv.clickPositionX = target[0].x;
                        target[0].inv.clickPositionY = target[0].y;
                        target[0].inv.hasTweened = true
                    }
                })
            }
        }
        for (var j = 0; j < this.imgs.length; j++) {
            this.imgs[j].setDepth(Math.round(this.imgs[j].y))
        }
    }
}
export class GameOverScreen extends Phaser.Scene {
    constructor() {
        super('GameOverScreen')
    }
    init(data) {
        this.data = data
    }
    create() {
        this.windowX = 0;
        this.windowY = 0;
        this.createContent()
    }
    createContent() {
        this.LEADERBOARD_ID = "1003";
        var graphics = this.add.graphics();
        graphics.fillStyle(0x000000, 0.55);
        graphics.fillRoundedRect(0, 0, 960, 520, 0);
        this.gameOverTextHeading = this.add.text(960 / 2, 20, gameOptions.language.gameOver, {
            fontSize: 37,
            fontFamily: 'Arial',
            color: '#ffff00',
            align: 'center'
        }).setOrigin(0.5, 0);
        this.gameOverTextBread = this.add.text(960 / 2, 72, 'Circumstances here', {
            fontSize: 16,
            fontFamily: 'Arial',
            color: '#ffff00',
            align: 'center',
            wordWrap: {
                width: 700
            }
        }).setOrigin(0.5, 0);
        this.copyright = this.add.text(14, 493, '© 3rd World Farmer Team', {
            fontSize: 10,
            fontFamily: 'Arial',
            color: '#ffffff'
        }).setOrigin(0, 0);
        var graphics2 = this.add.graphics();
        graphics2.fillStyle(0xffffff, 0.2);
        graphics2.fillRoundedRect(14, 270, 150, 210, 0);
        var credits = gameOptions.language.creditsTextLang.replace(/<br ?\/?>/g, "\n");
        this.creditsTf = this.add.text(18, 275, credits, {
            fontSize: 9,
            fontFamily: 'Arial',
            color: '#ffff00',
            wordWrap: {
                width: 144
            }
        }).setOrigin(0, 0);
        var graphics3 = this.add.graphics();
        graphics3.fillStyle(0xffffff, 0.1);
        graphics3.fillRoundedRect(230, 440, 500, 70, 0);
        graphics3.lineStyle(2, 0xffffff, 0.2);
        graphics3.strokeRoundedRect(230, 440, 500, 70, 0);
        var textture1 = graphics3.generateTexture('learnMore', 500, 70);
        this.linkButton = this.add.image(230, 440, 'learnMore').setOrigin(0, 0).setInteractive({
            useHandCursor: true
        }).on('pointerup', this.linkButtonClick.bind(this));
        this.about24000 = this.add.text(960 / 2, 448, gameOptions.language.about24000, {
            fontSize: 14,
            fontFamily: 'Arial',
            color: '#ffff00',
            align: 'center',
            wordWrap: {
                width: 483
            }
        }).setOrigin(0.5, 0);
        this.clickHere = this.add.text(960 / 2, 488, gameOptions.language.clickHere, {
            fontSize: 14,
            fontFamily: 'Arial',
            color: '#ffff00',
            align: 'center',
            wordWrap: {
                width: 483
            }
        }).setOrigin(0.5, 0);
        var graphics4 = this.add.graphics();
        graphics4.fillStyle(0xffffff, 0.2);
        graphics4.fillRoundedRect(339, 143, 282, 294, 0);
        this.yourScore = this.add.text(345, 148, gameOptions.language.yourScore, {
            fontSize: 16,
            fontFamily: 'Arial',
            color: '#00ff00'
        });
        this.reasons = this.add.text(345, 170, 'Turns: 100 (x10)\nBabies born: 5 (x25)\n-----------------------------\nTOTAL', {
            fontSize: 10,
            fontFamily: 'Arial',
            color: '#00ff00',
            wordWrap: {
                width: 200
            }
        });
        this.results = this.add.text(575, 170, '= 1000\n= 125\n------------\n= 1125', {
            fontSize: 10,
            fontFamily: 'Arial',
            color: '#00ff00',
            align: 'right',
            wordWrap: {
                width: 55
            }
        });
        this.fbButton = this.add.image(770, 454, 'atlas', 'facebookButton').setOrigin(0, 0).setInteractive({
            useHandCursor: true
        });
        this.fbButton.on('pointerup', function(pointer) {
            var url = 'https://www.facebook.com/3rdworldfarmer/';
            var s = window.open(url, '_blank');
            if (s && s.focus) {
                s.focus()
            } else if (!s) {}
        });
        var graphics5 = this.add.graphics();
        graphics5.fillStyle(0x006600, 1);
        graphics5.fillRoundedRect(0, 0, 130, 30, 4);
        graphics5.lineStyle(2, 0x00cc00, 1);
        graphics5.strokeRoundedRect(1, 1, 128, 28, 4);
        var texture2 = graphics5.generateTexture('playAgainTexture', 130, 30);
        graphics5.clear();
        this.submitScoreButton1 = this.add.image(411 - 65, 435 - 32, 'playAgainTexture').setOrigin(0, 0).setInteractive({
            useHandCursor: true
        }).on('pointerup', this.submitScoreButton1Click.bind(this));
        this.playAgainButton = this.add.image(548 - 65, 435 - 32, 'playAgainTexture').setOrigin(0, 0).setInteractive({
            useHandCursor: true
        }).on('pointerup', this.playAgainButtonClick.bind(this));
        this.submitText = this.add.text(411, 410, gameOptions.language.submitScore, {
            fontSize: 14,
            fontFamily: 'Arial',
            color: '#ccff99',
            align: 'center'
        }).setOrigin(0.5, 0);
        this.playAgainText = this.add.text(548, 410, gameOptions.language.bPlayAgain, {
            fontSize: 14,
            fontFamily: 'Arial',
            color: '#ccff99',
            align: 'center'
        }).setOrigin(0.5, 0)
    }
    setContent(main) {
        var s = '';
        var re = main.reasonForGameEnd;
        var reasonString = '';
        var resultString = '';
        if (re == "everyoneDied") {
            s = gameOptions.language.gameOverReason1
        } else if (re == "noadultsleft") {
            s = gameOptions.language.gameOverReason2
        } else if (re == "win") {
            s = gameOptions.language.gameOverReason3
        }
        s += "\n" + gameOptions.language.roundsOutput1 + main.turnCount + gameOptions.language.roundsOutput2;
        main.score = main.turnCount * 10;
        reasonString = gameOptions.language.sbTurns + main.turnCount + " (x 10)\n";
        resultString = "= " + (main.turnCount * 10) + "\n";
        if (main.totalSchoolCount > 0) {
            main.score += (main.totalSchoolCount * 10);
            reasonString += gameOptions.language.sbYearsInSchool + "" + main.totalSchoolCount + " (x 10)\n";
            resultString += "= " + (main.totalSchoolCount * 10) + "\n"
        }
        if (main.totalBabyCount > 0) {
            main.score += (main.totalBabyCount * 25);
            reasonString += gameOptions.language.sbBabiesBorn + main.totalBabyCount + "(x 25)\n";
            resultString += "= " + (main.totalBabyCount * 25) + "\n"
        }
        if (main.totalMarriageCount > 0) {
            main.score += (main.totalMarriageCount * 25);
            reasonString += gameOptions.language.sbMarriages + main.totalMarriageCount + " (x 25)\n";
            resultString += "= " + (main.totalMarriageCount * 25) + "\n"
        }
        var projectCount = 0;
        if (main.communicationsBuilt) {
            reasonString += gameOptions.language.sbComBuilt + "\n";
            resultString += "= 50\n";
            main.score += 50;
            projectCount++
        }
        if (main.infrastructureBuilt) {
            reasonString += gameOptions.language.sbInfBuilt + "\n";
            resultString += "= 50\n";
            main.score += 50;
            projectCount++
        }
        if (main.schoolBuilt) {
            reasonString += gameOptions.language.sbSchBuilt + "\n";
            resultString += "= 50\n";
            main.score += 50;
            projectCount++
        }
        if (main.clinicBuilt) {
            reasonString += gameOptions.language.sbCliBuilt + "\n";
            resultString += "= 50\n";
            main.score += 50;
            projectCount++
        }
        if (main.representativeBuilt) {
            reasonString += gameOptions.language.sbRepBuilt + "\n";
            resultString += "= 50\n";
            main.score += 50;
            projectCount++
        }
        if (main.insuranceBuilt) {
            reasonString += gameOptions.language.sbInsBuilt + "\n";
            resultString += "= 50\n";
            main.score += 50;
            projectCount++
        }
        if (main.expansionBuilt) {
            reasonString += gameOptions.language.sbInsBuilt + "\n";
            resultString += "= 50\n";
            main.score += 50;
            projectCount++
        }
        if (projectCount == 6) {
            reasonString += gameOptions.language.sbBonus + "\n";
            resultString += "= 500\n";
            main.score += 500
        }
        reasonString += "-------------------------------\n";
        resultString += "--------\n";
        reasonString += "TOTAL";
        resultString += "= " + main.score;
        this.reasons.text = reasonString;
        this.results.text = resultString;
        this.gameOverTextBread.text = s;
        this.finalScore = main.score
    }
    submitScoreButton1Click() {
        this.submitScoreButton1.destroy();
        this.submitText.destroy();
        eventsCenter.emit('submit-score-intent')
    }
    playAgainButtonClick() {
        location.reload()
    }
    linkButtonClick() {
        var url = 'https://3rdworldfarmer.org/take-action.html';
        var s = window.open(url, '_blank');
        if (s && s.focus) {
            s.focus()
        } else if (!s) {}
    }
}
export class Leaderboard extends Phaser.Scene {
    constructor() {
        super('Leaderboard')
    }
    init(data) {
        this.data = data
    }
    create() {
        this.windowX = 0;
        this.windowY = 0;
        var graphics = this.add.graphics();
        graphics.fillStyle(0x000000, 0.5);
        graphics.fillRoundedRect(0, 0, 960, 520, 0);
        graphics.fillStyle(0x000000, 1);
        graphics.fillRoundedRect(300, 30, 360, 450, 0);
        this.allTime = this.add.text(960 / 2, 35, gameOptions.language.scAllTime, {
            fontSize: 24,
            fontFamily: 'Arial',
            color: '#ffffcc',
            align: 'center'
        }).setOrigin(0.5, 0);
        this.scRank = this.add.text(330, 102, gameOptions.language.scRank, {
            fontSize: 14,
            fontFamily: 'Arial',
            color: '#ffffcc',
            align: 'left'
        }).setOrigin(0, 0);
        this.scName = this.add.text(428, 102, gameOptions.language.scName, {
            fontSize: 14,
            fontFamily: 'Arial',
            color: '#ffffcc',
            align: 'left'
        }).setOrigin(0, 0);
        this.scScore = this.add.text(580, 102, gameOptions.language.scScore, {
            fontSize: 14,
            fontFamily: 'Arial',
            color: '#ffffcc',
            align: 'center'
        }).setOrigin(0.5, 0);
        var i;
        for (i = 1; i < 11; i++) {
            this["rank" + i] = this.add.text(330, 130 + (i * 25), '#' + i, {
                fontSize: 14,
                fontFamily: 'Arial',
                color: '#ffcc00',
                align: 'left'
            }).setOrigin(0, 0);
            this["name" + i] = this.add.text(428, 130 + (i * 25), '-', {
                fontSize: 14,
                fontFamily: 'Arial',
                color: '#ffcc00',
                align: 'left'
            }).setOrigin(0, 0);
            this["score" + i] = this.add.text(580, 130 + (i * 25), '-', {
                fontSize: 14,
                fontFamily: 'Arial',
                color: '#ffcc00',
                align: 'center'
            }).setOrigin(0.5, 0)
        }
        var graphics2 = this.add.graphics();
        graphics2.fillStyle(0x000000, 1);
        graphics2.fillRoundedRect(335, 424, 192, 25, 4);
        graphics2.lineStyle(2, 0xffcc00, 1);
        graphics2.strokeRoundedRect(335, 424, 192, 25, 4);
        this.scoresOnlineButton = this.add.text(338 + 86, 428, gameOptions.language.scSeeOnline, {
            fontSize: 11,
            fontFamily: 'Arial',
            color: '#cccccc',
            align: 'center'
        }).setOrigin(0.5, 0);
        var textture1 = graphics2.generateTexture('scoresOnlineButtonTexture', 192, 25);
        this.scoresOnlineButtonImage = this.add.image(335, 424, 'scoresOnlineButtonTexture').setOrigin(0, 0).setInteractive({
            useHandCursor: true
        }).on('pointerup', this.linkButtonClick.bind(this));
        var graphics3 = this.add.graphics();
        graphics3.fillStyle(0x000000, 1);
        graphics3.fillRoundedRect(560, 424, 60, 25, 4);
        graphics3.lineStyle(2, 0xffcc00, 1);
        graphics3.strokeRoundedRect(560, 424, 60, 25, 4);
        this.okayButton = this.add.text(563 + 30, 428, gameOptions.language.scOkay, {
            fontSize: 11,
            fontFamily: 'Arial',
            color: '#cccccc',
            align: 'center'
        }).setOrigin(0.5, 0);
        var textture2 = graphics3.generateTexture('okayButtonTexture', 60, 25);
        this.okayButtonImage = this.add.image(560, 424, 'okayButtonTexture').setOrigin(0, 0).setInteractive({
            useHandCursor: true
        }).on('pointerdown', this.okayClick.bind(this))
    }
    setLine(i, name, score) {
        this["name" + i].setText(name);
        this["score" + i].setText(score)
    }
    linkButtonClick() {
        var url = 'https://3rdworldfarmer.org/scores.php';
        var s = window.open(url, '_blank');
        if (s && s.focus) {
            s.focus()
        } else if (!s) {}
    }
    okayClick() {
        this.scene.remove()
    }
}
export class Main {
    constructor() {
        this.ANDROID_BUILD = true;
        this.gamePhase = 1;
        this.extraTiles = 0;
        this.PopUpText = '';
        this.allStrings = [];
        this.livingCostsPP = 3;
        this.currentEvent = null;
        this.turnCount = 1;
        this.poorEventCounter = 0.1;
        this.playerActivity = [1, 1, 1, 1, 1, 1, 1, 1, 1, 1];
        this.score = 0;
        this.playerName = "_";
        this.newscore = 0;
        this.leaveFarmReward = 0;
        this.leaveFarmPointsAwarded = 0;
        this.marriagePointsAwarded = 2;
        this.leaveFarmBaby = 0;
        this.leaveFarmChildNoEd = 10;
        this.leaveFarmChildEd = 15;
        this.leaveFarmAdultNoEd = 20;
        this.leaveFarmAdultSomeEd = 25;
        this.leaveFarmAdultHighEd = 50;
        this.longTimeEffectChemical = false;
        this.longTimeEffectOpium = false;
        this.longTimeEffectParamilitary = false;
        this.longTimeEffectFirewood = false;
        this.longTimeEffectEpidemic = false;
        this.longTimeEffectCattleHerding = false;
        this.longTimeEffectBirds = false;
        this.longTimeEffectMine = false;
        this.effectAffectuatedChemical = false;
        this.effectAffectuatedOpium = false;
        this.effectAffectuatedParamilitary = false;
        this.effectAffectuatedFirewood = false;
        this.effectAffectuatedEpidemic = false;
        this.effectAffectuatedCattleHerding = false;
        this.effectAffectuatedBirds = false;
        this.effectAffectuatedMine = false;
        this.familyMemberDied = false;
        this.starvation = false;
        this.childBornThisYear = false;
        this.clinicBuilt = false;
        this.schoolBuilt = false;
        this.infrastructureBuilt = false;
        this.communicationsBuilt = false;
        this.representativeBuilt = false;
        this.insuranceBuilt = false;
        this.expansionBuilt = false;
        this.numberOfProjectsBuilt = 0;
        this.whoDiedFromLowHealth = '';
        this.startMoney = 50;
        this.maxMoney = 300;
        this.minMoney = 1;
        this.brokeEarningChemical = 75;
        this.brokeEarningTribalDance = 50;
        this.brokeEarningOpium = 25;
        this.brokeEarningParamilitary = 80;
        this.brokeEarningCityMigrate = 65;
        this.brokeEarningFirewood = 30;
        this.brokeEarningEpidemic = 10;
        this.brokeEarningSeedTrade = 50;
        this.brokeEarningCattleHerding = 60;
        this.brokeEarningBirds = 30;
        this.brokeEarningMine = 100;
        this.brokeEarningWitch = 1;
        this.newWifeDowryEarning = 100;
        this.schoolFee = 30;
        this.goodSeasonEventModifier = 50;
        this.veryGoodSeasonEventModifier = 100;
        this.cornPrice = 0;
        this.cornMultiplier = 11;
        this.wheatPrice = 13;
        this.wheatMultiplier = 13;
        this.cottonPrice = 15;
        this.cottonMultiplier = 16;
        this.peanutPrice = 18;
        this.peanutMultiplier = 22;
        this.poppyPrice = 0;
        this.poppyMultiplier = 20;
        this.poppyAmount = 0;
        this.chickenPrice = 25;
        this.chickenMultiplier = 8;
        this.pigPrice = 45;
        this.pigMultiplier = 15;
        this.cowPrice = 100;
        this.cowMultiplier = 40;
        this.elephantPrice = 500;
        this.elephantMultiplier = 120;
        this.shovelPrice = 15;
        this.shovelMultiplier = 0.08;
        this.scythePrice = 35;
        this.scytheMultiplier = 0.13;
        this.plowPrice = 175;
        this.plowMultiplier = 0.4;
        this.tractorPrice = 500;
        this.tractorMultiplier = 0.8;
        this.harvesterPrice = 750;
        this.harvesterMultiplier = 1;
        this.shedPrice = 50;
        this.shedMultiplier = 0.1;
        this.wellPrice = 120;
        this.wellMultiplier = 0.15;
        this.barnPrice = 180;
        this.barnMultiplier = 0.3;
        this.communicationsPrice = 250;
        this.infrastructurePrice = 350;
        this.schoolPrice = 450;
        this.clinicPrice = 600;
        this.representativePrice = 800;
        this.insurancePrice = 125;
        this.expansionPrice = 1;
        this.communicationsDependency = [];
        this.infrastructureDependency = [];
        this.schoolDependency = [];
        this.clinicDependency = [];
        this.representativeDependency = [];
        this.insuranceDependency = ["representative"];
        this.expansionDependency = [];
        this.communicationsMultiplier = 0;
        this.infrastructureMultiplier = 0;
        this.schoolMultiplier = 0;
        this.clinicMultiplier = 0;
        this.representativeMultiplier = 0;
        this.insuranceMultiplier = 0;
        this.expansionMultiplier = 0;
        this.cornDependency = [];
        this.wheatDependency = [];
        this.cottonDependency = [];
        this.peanutDependency = [];
        this.poppyDependency = [];
        this.chickenDependency = ["shed"];
        this.pigDependency = ["shed", "well"];
        this.cowDependency = ["barn", "well"];
        this.elephantDependency = ["barn", "well"];
        this.shovelDependency = [];
        this.scytheDependency = [];
        this.plowDependency = [];
        this.tractorDependency = [];
        this.harvesterDependency = [];
        this.shedDependency = [];
        this.wellDependency = [];
        this.barnDependency = [];
        this.Choises = ["Nothing", "corn", "wheat", "cotton", "peanut", "poppy", "chicken", "pig", "cow", "elephant", "shovel", "scythe", "plow", "tractor", "harvester", "shed", "well", "barn", "communications", "infrastructure", "school", "clinic", "representative", "insurance", "expansion"];
        this.sellChickenPrice = 0;
        this.sellPigPrice = 0;
        this.sellCowPrice = 0;
        this.sellElephantPrice = 0;
        this.sellWellPrice = 0;
        this.sellShedPrice = 0;
        this.sellBarnPrice = 0;
        this.sellShovelPrice = 0;
        this.sellScythePrice = 0;
        this.sellPlowPrice = 0;
        this.sellTractorPrice = 0;
        this.sellHarvesterPrice = 0;
        this.sellChickenAvail = 0;
        this.sellPigAvail = 0;
        this.sellCowAvail = 0;
        this.sellElephantAvail = 0;
        this.sellWellAvail = 0;
        this.sellShedAvail = 0;
        this.sellBarnAvail = 0;
        this.sellShovelAvail = 0;
        this.sellScytheAvail = 0;
        this.sellPlowAvail = 0;
        this.sellTractorAvail = 0;
        this.sellHarvesterAvail = 0;
        this.IOcornAmount = 0;
        this.IOwheatAmount = 0;
        this.IOcottonAmount = 0;
        this.IOpeanutAmount = 0;
        this.IOpoppyAmount = 0;
        this.IOchickenAmount = 0;
        this.IOpigAmount = 0;
        this.IOcowAmount = 0;
        this.IOelephantAmount = 0;
        this.IOcornYield = 0;
        this.IOwheatYield = 0;
        this.IOcottonYield = 0;
        this.IOpeanutYield = 0;
        this.IOpoppyYield = 0;
        this.IOchickenYield = 0;
        this.IOpigYield = 0;
        this.IOcowYield = 0;
        this.IOelephantYield = 0;
        this.IOtoolsBonus = "15 %";
        this.IOcropsTotal = 0;
        this.IObuildingBonus = "15 %";
        this.IOlivestockTotal = 0;
        this.IOsum = 0;
        this.IOworkload = "140 %";
        this.IOtotal = 0;
        this.IOeventModifierNumber = 0;
        this.IOeventModifier = "100 %";
        this.IOcalcString = "Income this year<br>(calculation here):";
        this.IOsavedfromlastyear = 0;
        this.IOlivingCosts = 0;
        this.IOtotalFinal = 0;
        this.reasonForGameEnd = "everyoneDied";
        this.totalSchoolCount = 0;
        this.totalBabyCount = 0;
        this.totalMarriageCount = 0;
        this.familyMembersText = '';
        this.annualExpenses = 0;
        this.currentRevenue = 0;
        this.marriageProposalPrice = 0;
        this.whichFamilyMemberActive = 0;
        this.activityCounter = 0;
        this.marriageThisYear = false;
        this.investment = null;
        this.aButtons = [];
        this.bButtons = []
    }
}
export class BrokeInfoBox extends ZigzagWindow {
    constructor() {
        super('BrokeInfoBox')
    }
    init(data) {
        this.data = data
    }
    create() {
        this.windowX = 255;
        this.windowY = 65;
        this.createBackground(this.windowX, this.windowY, 464, 352);
        this.createContent();
        this.currentEventId = 0;
        this.content = {
            1: {
                name: 'TribalDance',
                headingText: gameOptions.language.perform1,
                descriptionText: gameOptions.language.perform2,
                payment: gameOptions.language.perform3,
                accept: gameOptions.language.perform4,
                earning: this.data.farmModel.main.brokeEarningTribalDance,
                pic: 'tribalDance'
            },
            2: {
                name: 'Chemical',
                headingText: gameOptions.language.chem1,
                descriptionText: gameOptions.language.chem2,
                payment: gameOptions.language.chem3,
                accept: gameOptions.language.chem4,
                earning: this.data.farmModel.main.brokeEarningChemical,
                pic: 'chemical'
            },
            3: {
                name: 'Paramilitary',
                headingText: gameOptions.language.camp1,
                descriptionText: gameOptions.language.camp2,
                payment: gameOptions.language.camp3,
                accept: gameOptions.language.camp4,
                earning: this.data.farmModel.main.brokeEarningParamilitary,
                pic: 'trainingCamp'
            },
            4: {
                name: 'Opium',
                headingText: gameOptions.language.opium1,
                descriptionText: gameOptions.language.opium2 + '\n' + gameOptions.language.opium4,
                payment: gameOptions.language.opium3,
                accept: gameOptions.language.opium5,
                earning: this.data.farmModel.main.brokeEarningOpium,
                pic: 'opium'
            },
            5: {
                name: 'CityMigrate',
                headingText: gameOptions.language.city1,
                descriptionText: gameOptions.language.city2,
                payment: gameOptions.language.city3,
                accept: gameOptions.language.city4,
                earning: this.data.farmModel.main.brokeEarningCityMigrate,
                pic: 'cityMigrate'
            },
            6: {
                name: 'CollectFirewood',
                headingText: gameOptions.language.evFirewoodHeading,
                descriptionText: gameOptions.language.evFirewoodDesc,
                payment: gameOptions.language.evFirewoodPayment,
                accept: gameOptions.language.evFirewoodAccept,
                earning: this.data.farmModel.main.brokeEarningFirewoood,
                pic: 'collectFirewood'
            },
            7: {
                name: 'Epidemic',
                headingText: gameOptions.language.evEpidemicHeading,
                descriptionText: gameOptions.language.evEpidemicDesc,
                payment: gameOptions.language.evEpidemicPayment,
                accept: gameOptions.language.evEpidemicAccept,
                earning: this.data.farmModel.main.brokeEarningEpidemic,
                pic: 'epidemicWarning'
            },
            8: {
                name: 'SeedTrade',
                headingText: gameOptions.language.evSeedTradeHeading,
                descriptionText: gameOptions.language.evSeedTradeDesc,
                payment: gameOptions.language.evSeedTradePayment,
                accept: gameOptions.language.evSeedTradeAccept,
                earning: this.data.farmModel.main.brokeEarningSeedTrade,
                pic: 'seedTrade'
            },
            9: {
                name: 'CattleHerding',
                headingText: gameOptions.language.evCattleHerdingHeading,
                descriptionText: gameOptions.language.evCattleHerdingDesc,
                payment: gameOptions.language.evCattleHerdingPayment,
                accept: gameOptions.language.evCattleHerdingAccept,
                earning: this.data.farmModel.main.brokeEarningCattleHerding,
                pic: 'cattleHerding'
            },
            10: {
                name: 'Birds',
                headingText: gameOptions.language.evBirdsHeading,
                descriptionText: gameOptions.language.evBirdsDesc,
                payment: gameOptions.language.evBirdsPayment,
                accept: gameOptions.language.evBirdsAccept,
                earning: this.data.farmModel.main.brokeEarningBirds,
                pic: 'birdTrapping'
            },
            11: {
                name: 'Mine',
                headingText: gameOptions.language.evMineHeading,
                descriptionText: gameOptions.language.evMineDesc,
                payment: gameOptions.language.evMinePayment,
                accept: gameOptions.language.evMineAccept,
                earning: this.data.farmModel.main.brokeEarningMine,
                pic: 'artisanalMining'
            },
            12: {
                name: 'Witch',
                headingText: gameOptions.language.evWitchHeading,
                descriptionText: gameOptions.language.evWitchDesc,
                payment: gameOptions.language.evWitchPayment,
                accept: gameOptions.language.evWitchAccept,
                earning: this.data.farmModel.main.brokeEarningWitch,
                pic: 'childWitch'
            }
        };
        eventsCenter.emit('created-step', 'BrokeInfoBox')
    }
    createContent() {
        this.heading = this.add.text(45 + this.windowX, 21 + this.windowY, 'Heading', {
            fontSize: 17,
            fontFamily: 'Arial',
            color: '#483A24'
        }).setOrigin(0, 0);
        this.description = this.add.text(42 + this.windowX, 53 + this.windowY, 'Description', {
            fontSize: 14,
            fontFamily: 'Arial',
            color: '#483A24',
            wordWrap: {
                width: 230
            },
            lineSpacing: 3.5
        }).setOrigin(0, 0);
        this.payment = this.add.text(45 + this.windowX, 227 + this.windowY, 'Payment', {
            fontSize: 14,
            fontFamily: 'Arial',
            color: '#483A24'
        }).setOrigin(0, 0);
        this.brokeEarning = this.add.text(45 + this.windowX, 248 + this.windowY, '100', {
            fontSize: 14,
            fontFamily: 'Arial',
            color: '#483A24'
        }).setOrigin(0, 0);
        this.doYouAccept = this.add.text(45 + this.windowX, 273 + this.windowY, 'Do you accept?', {
            fontSize: 14,
            fontFamily: 'Arial',
            color: '#483A24',
            wordWrap: {
                width: 214
            },
            lineSpacing: 3.5
        }).setOrigin(0, 0);
        this.picTargetMC = this.add.image(286 + this.windowX, 56 + this.windowY, '').setOrigin(0, 0);
        this.acceptButton = new BigButton(this,274 + 80 + this.windowX,222 + 25 + this.windowY,gameOptions.language.bAccept);
        this.declineButton = new BigButton(this,274 + 80 + this.windowX,272 + 25 + this.windowY,gameOptions.language.bDecline);
        this.add.existing(this.acceptButton);
        this.add.existing(this.declineButton);
        this.acceptButton.setInteractive({
            useHandCursor: true
        }).on('pointerdown', this.clickedAccept.bind(this));
        this.declineButton.setInteractive({
            useHandCursor: true
        }).on('pointerdown', this.clickedDecline.bind(this))
    }
    setContent(eventId) {
        this.currentEventId = eventId;
        var obj = this.content[eventId];
        this.heading.text = obj.headingText;
        this.description.text = obj.descriptionText;
        if (eventId == 4) {
            this.description.text += ' ' + this.data.farmModel.main.poppyAmount
        }
        this.payment.text = obj.payment;
        this.brokeEarning.text = obj.earning;
        this.doYouAccept.text = obj.accept;
        this.picTargetMC.setTexture('atlas', 'offers/' + obj.pic + '.jpeg')
    }
    clickedAccept() {
        eventsCenter.emit('broke-event-accepted', this.currentEventId)
    }
    clickedDecline() {
        eventsCenter.emit('broke-event-declined')
    }
}
export class FamilyHeadInfoBox extends ZigzagWindow {
    constructor() {
        super('FamilyHeadInfoBox')
    }
    init(data) {
        this.data = data
    }
    create() {
        this.windowX = 260;
        this.windowY = 210;
        this.createBackground(this.windowX, this.windowY, 224, 304);
        this.createContent();
        eventsCenter.emit('created-step', 'FamilyHeadInfoBox')
    }
    createContent() {
        this.explanationLabel = this.add.text(18 + this.windowX, 16 + this.windowY, 'empty', {
            fontSize: 13,
            fontFamily: 'Arial',
            color: '#000000',
            wordWrap: {
                width: 180
            },
            lineSpacing: 3.5
        }).setOrigin(0, 0);
        this.appointNewQuest = this.add.text(20 + this.windowX, 139 + this.windowY, gameOptions.language.appointNewQuest, {
            fontSize: 10,
            fontFamily: 'Arial',
            color: '#000000',
            wordWrap: {
                width: 180
            },
            lineSpacing: 3.5
        }).setOrigin(0, 0);
        this.acceptButton = new BigButton(this,35 + 80 + this.windowX,186 + 25 + this.windowY,gameOptions.language.bAccept);
        this.closeBoxButton = new BigButton(this,35 + 80 + this.windowX,237 + 25 + this.windowY,gameOptions.language.bClose);
        this.add.existing(this.acceptButton);
        this.add.existing(this.closeBoxButton);
        this.closeBoxButton.setInteractive({
            useHandCursor: true
        }).on('pointerdown', this.clickedClose.bind(this));
        this.acceptButton.setInteractive({
            useHandCursor: true
        }).on('pointerdown', this.clickedAccept.bind(this))
    }
    setContent(explanation) {
        this.explanationLabel.setText(explanation)
    }
    clickedClose() {
        eventsCenter.emit('closed-family-head-infobox')
    }
    clickedAccept() {
        var farmModel = this.data.farmModel;
        var t = farmModel.main.whichFamilyMemberActive;
        for (var i = 0; i < farmModel.family.length; i++) {
            if (farmModel.family[i].getID() == t) {
                farmModel.setPersonFamilyHead(i);
                var marTo = farmModel.family[i].getMarriedTo();
                if (marTo != -1) {
                    farmModel.family[farmModel.getFamilyMemberById(marTo)].setSpouse(true)
                }
            }
        }
        eventsCenter.emit('accept-family-head')
    }
}
export class FamilyMemberInfoBox extends ZigzagWindow {
    constructor() {
        super('FamilyMemberInfoBox')
    }
    init(data) {
        this.data = data
    }
    create() {
        this.windowX = 505;
        this.windowY = 35;
        this.createBackground(this.windowX, this.windowY, 384, 480);
        this.famName = this.add.text(20 + this.windowX, 29 + this.windowY, gameOptions.language.famName, {
            fontSize: 18,
            fontFamily: 'Arial',
            color: '#000000'
        }).setOrigin(0, 0);
        this.famGender = this.add.text(20 + this.windowX, 54 + this.windowY, gameOptions.language.famGender, {
            fontSize: 18,
            fontFamily: 'Arial',
            color: '#000000'
        }).setOrigin(0, 0);
        this.famAge = this.add.text(20 + this.windowX, 79 + this.windowY, gameOptions.language.famAge, {
            fontSize: 18,
            fontFamily: 'Arial',
            color: '#000000'
        }).setOrigin(0, 0);
        this.famTitle = this.add.text(20 + this.windowX, 104 + this.windowY, gameOptions.language.famTitle, {
            fontSize: 18,
            fontFamily: 'Arial',
            color: '#000000'
        }).setOrigin(0, 0);
        this.famEducation = this.add.text(20 + this.windowX, 128 + this.windowY, gameOptions.language.famEducation, {
            fontSize: 18,
            fontFamily: 'Arial',
            color: '#000000'
        }).setOrigin(0, 0);
        this.famFertile = this.add.text(20 + this.windowX, 153 + this.windowY, gameOptions.language.famFertile, {
            fontSize: 18,
            fontFamily: 'Arial',
            color: '#000000'
        }).setOrigin(0, 0);
        this.famWorkload = this.add.text(20 + this.windowX, 178 + this.windowY, gameOptions.language.famWorkload, {
            fontSize: 18,
            fontFamily: 'Arial',
            color: '#000000'
        }).setOrigin(0, 0);
        this.famHealth = this.add.text(20 + this.windowX, 203 + this.windowY, gameOptions.language.famHealth, {
            fontSize: 18,
            fontFamily: 'Arial',
            color: '#000000'
        }).setOrigin(0, 0);
        this.famMarriedTo = this.add.text(20 + this.windowX, 230 + this.windowY, gameOptions.language.famMarriedTo, {
            fontSize: 18,
            fontFamily: 'Arial',
            color: '#000000'
        }).setOrigin(0, 0);
        this.nameLabel = this.add.text(170 + this.windowX, 29 + this.windowY, 'empty', {
            fontSize: 18,
            fontFamily: 'Arial',
            color: '#000000'
        }).setOrigin(0, 0);
        this.genderLabel = this.add.text(170 + this.windowX, 54 + this.windowY, 'empty', {
            fontSize: 18,
            fontFamily: 'Arial',
            color: '#000000'
        }).setOrigin(0, 0);
        this.ageLabel = this.add.text(170 + this.windowX, 79 + this.windowY, 'empty', {
            fontSize: 18,
            fontFamily: 'Arial',
            color: '#000000'
        }).setOrigin(0, 0);
        this.titleLabel = this.add.text(170 + this.windowX, 104 + this.windowY, 'empty', {
            fontSize: 18,
            fontFamily: 'Arial',
            color: '#000000'
        }).setOrigin(0, 0);
        this.educationLabel = this.add.text(170 + this.windowX, 128 + this.windowY, 'empty', {
            fontSize: 18,
            fontFamily: 'Arial',
            color: '#000000'
        }).setOrigin(0, 0);
        this.fertileLabel = this.add.text(170 + this.windowX, 153 + this.windowY, 'empty', {
            fontSize: 18,
            fontFamily: 'Arial',
            color: '#000000'
        }).setOrigin(0, 0);
        this.workloadLabel = this.add.text(170 + this.windowX, 178 + this.windowY, 'empty', {
            fontSize: 18,
            fontFamily: 'Arial',
            color: '#000000'
        }).setOrigin(0, 0);
        this.healthLabel = this.add.text(170 + this.windowX, 203 + this.windowY, 'empty', {
            fontSize: 18,
            fontFamily: 'Arial',
            color: '#000000'
        }).setOrigin(0, 0);
        this.maritalLabel = this.add.text(170 + this.windowX, 230 + this.windowY, 'empty', {
            fontSize: 18,
            fontFamily: 'Arial',
            color: '#000000'
        }).setOrigin(0, 0);
        var graphics = this.add.graphics();
        graphics.fillStyle('#000000', 0.1);
        graphics.fillRoundedRect(28 + this.windowX, 268 + this.windowY, 156, 40, 4);
        graphics.fillRoundedRect(194 + this.windowX, 268 + this.windowY, 156, 40, 4);
        graphics.fillRoundedRect(28 + this.windowX, 316 + this.windowY, 156, 40, 4);
        graphics.fillRoundedRect(194 + this.windowX, 316 + this.windowY, 156, 40, 4);
        graphics.fillRoundedRect(28 + this.windowX, 364 + this.windowY, 156, 40, 4);
        graphics.fillRoundedRect(194 + this.windowX, 364 + this.windowY, 156, 40, 4);
        this.giveMedicineButton = new BigButton(this,28 + 80 + this.windowX,268 + 25 + this.windowY,gameOptions.language.giveMedicineBut);
        this.goToSchoolButton = new BigButton(this,194 + 80 + this.windowX,268 + 25 + this.windowY,gameOptions.language.goToSchoolBut);
        this.haveBabyButton = new BigButton(this,28 + 80 + this.windowX,316 + 25 + this.windowY,gameOptions.language.haveBabyBut);
        this.appointHeadOfFamilyButton = new BigButton(this,194 + 80 + this.windowX,316 + 25 + this.windowY,gameOptions.language.familyHeadBut);
        this.marryButton = new BigButton(this,28 + 80 + this.windowX,364 + 25 + this.windowY,gameOptions.language.marriageBut);
        this.leaveFarmButton = new BigButton(this,194 + 80 + this.windowX,364 + 25 + this.windowY,gameOptions.language.leaveFarmBut);
        this.closeFamilyMemberInfoBoxButton = new BigButton(this,109 + 80 + this.windowX,414 + 25 + this.windowY,gameOptions.language.bClose);
        this.add.existing(this.goToSchoolButton);
        this.add.existing(this.marryButton);
        this.add.existing(this.haveBabyButton);
        this.add.existing(this.appointHeadOfFamilyButton);
        this.add.existing(this.leaveFarmButton);
        this.add.existing(this.giveMedicineButton);
        this.add.existing(this.closeFamilyMemberInfoBoxButton);
        this.goToSchoolButton.setInteractive({
            useHandCursor: true
        }).on('pointerdown', this.clickedGoToSchool.bind(this));
        this.marryButton.setInteractive({
            useHandCursor: true
        }).on('pointerdown', this.clickedMarry.bind(this));
        this.haveBabyButton.setInteractive({
            useHandCursor: true
        }).on('pointerdown', this.clickedHaveBaby.bind(this));
        this.appointHeadOfFamilyButton.setInteractive({
            useHandCursor: true
        }).on('pointerdown', this.clickedAppointHeadOfFamily.bind(this));
        this.leaveFarmButton.setInteractive({
            useHandCursor: true
        }).on('pointerdown', this.clickedLeaveFarm.bind(this));
        this.giveMedicineButton.on('pointerdown', this.clickedGiveMedicine.bind(this));
        this.closeFamilyMemberInfoBoxButton.setInteractive({
            useHandCursor: true
        }).on('pointerdown', this.closeClicked.bind(this));
        this.helpButton = this.add.image(325 + this.windowX, 20 + this.windowY, 'atlas', 'questionmarkButton').setOrigin(0, 0);
        this.helpButton.setInteractive({
            useHandCursor: true
        }).on('pointerup', this.clickedHelp.bind(this));
        this.healthBar = this.add.graphics();
        eventsCenter.emit('created-step', 'FamilyMemberInfoBox')
    }
    drawHealthBar(h, g) {
        let green = 0x00FF00;
        let yellow = 0xFFFF00;
        let red = 0xFF0000;
        var col = (h > 74) ? green : (h > 24) ? yellow : red;
        g.clear();
        g.lineStyle(1, 0x000000, 1.0);
        g.fillStyle(col, 1.0);
        g.fillRect(212 + this.windowX, 202 + this.windowY, (h / 100) * 130, 20);
        g.strokeRect(212 + this.windowX, 202 + this.windowY, 130, 20)
    }
    setContent(p) {
        var nname = p.getName();
        var ngender = p.getGender();
        var nage = p.getAge();
        var nhealth = p.getHealth();
        var nfertile = p.getFertile();
        var neducation = p.getEducationLvl();
        var nspouse = p.getSpouse();
        var nheadoffamily = p.getHeadOfFamily();
        var nworkload = p.getWorkEfficiency();
        var npregnant = p.getPregnant();
        var natschool = p.getAtSchool();
        var str = '';
        this.data.farmModel.updateWorkEfficiency();
        this.data.farmModel.main.whichFamilyMemberActive = p.getID();
        this.nameLabel.setText(nname);
        this.genderLabel.setText(ngender ? gameOptions.language.genderMale : gameOptions.language.genderFemale);
        this.ageLabel.setText(nage);
        this.workloadLabel.setText(nworkload + '%');
        this.healthLabel.setText(nhealth);
        this.drawHealthBar(nhealth, this.healthBar);
        if (nheadoffamily) {
            str = gameOptions.language.titleHead
        } else if (nspouse) {
            str = gameOptions.language.titleSpouse
        } else {
            str = gameOptions.language.titleMember
        }
        this.titleLabel.setText(str);
        if (neducation == 0) {
            str = gameOptions.language.edNone
        } else if (neducation > 0) {
            str = neducation + " " + gameOptions.language.edYears
        }
        if (natschool) {
            str += gameOptions.language.edInSchool
        }
        this.educationLabel.setText(str);
        if (!nfertile) {
            str = gameOptions.language.wordNo
        } else if (!npregnant) {
            str = gameOptions.language.wordYes
        } else {
            str = gameOptions.language.fertilePregnant
        }
        this.fertileLabel.setText(str);
        if (p.getMarriedTo() == -1) {
            this.maritalLabel.setText(gameOptions.language.unmarried)
        } else {
            let id = this.data.farmModel.getFamilyMemberById(p.getMarriedTo());
            let name = this.data.farmModel.family[id].getName();
            this.maritalLabel.setText(name)
        }
        if (nhealth < 100 && this.data.farmModel.getMoney() > 0) {
            this.giveMedicineButton.show()
        } else {
            this.giveMedicineButton.hide()
        }
        var someOnePregnant = false;
        for (var i = 0; i < this.data.farmModel.family.length; i++) {
            if (this.data.farmModel.family[i].getPregnant()) {
                someOnePregnant = true
            }
        }
        if (((nspouse || nheadoffamily) && !ngender) && (!npregnant) && (p.getMarriedTo() != -1) && (!someOnePregnant)) {
            this.haveBabyButton.show()
        } else {
            this.haveBabyButton.hide()
        }
        if ((p.getMarriedTo() == -1) && (nage > 17)) {
            this.marryButton.show()
        } else {
            this.marryButton.hide()
        }
        if (neducation < 10 && !natschool && nage > 4 && nhealth > 50) {
            var sPrice = this.data.farmModel.main.schoolFee;
            if (this.data.farmModel.main.schoolBuilt) {
                sPrice = Math.round(sPrice / 2)
            }
            if (this.data.farmModel.getMoney() >= sPrice) {
                this.goToSchoolButton.show()
            } else {
                this.goToSchoolButton.hide()
            }
        } else {
            this.goToSchoolButton.hide()
        }
        if (!nheadoffamily) {
            this.appointHeadOfFamilyButton.show()
        } else {
            this.appointHeadOfFamilyButton.hide()
        }
    }
    clickedGoToSchool() {
        eventsCenter.emit('clicked-go-to-school')
    }
    clickedMarry() {
        eventsCenter.emit('clicked-marry')
    }
    clickedHaveBaby() {
        eventsCenter.emit('clicked-have-baby')
    }
    clickedAppointHeadOfFamily() {
        eventsCenter.emit('clicked-appoint-family-head')
    }
    clickedLeaveFarm() {
        eventsCenter.emit('clicked-leave-farm')
    }
    clickedGiveMedicine() {
        eventsCenter.emit('clicked-give-medicine')
    }
    clickedHelp() {
        eventsCenter.emit('clicked-help')
    }
    closeClicked() {
        eventsCenter.emit('closed-family-member-info-box')
    }
}
export class GiveMedicineInfoBox extends ZigzagWindow {
    constructor() {
        super('GiveMedicineInfoBox')
    }
    init(data) {
        this.data = data
    }
    create() {
        this.windowX = 240;
        this.windowY = 210;
        this.createBackground(this.windowX, this.windowY, 240, 304);
        this.clinicLabel = this.add.text(30 + this.windowX, 16 + this.windowY, 'empty', {
            fontSize: 12,
            fontFamily: 'Arial',
            color: '#000000',
            wordWrap: {
                width: 180
            },
            lineSpacing: 3
        }).setOrigin(0, 0);
        this.buyMedicineFor = this.add.text(30 + this.windowX, 82 + this.windowY, gameOptions.language.buyMedicineFor, {
            fontSize: 12,
            fontFamily: 'Arial',
            color: '#000000',
            wordWrap: {
                width: 180
            },
            textAlign: 'center',
            lineSpacing: 3.5
        }).setOrigin(0, 0);
        this.wholeFamilyCostLabel = this.add.text(185 + this.windowX, 114 + this.windowY, '$ 500', {
            fontSize: 12,
            fontFamily: 'Arial',
            color: '#000000'
        }).setOrigin(0, 0);
        this.costLabel = this.add.text(185 + this.windowX, 158 + this.windowY, '$ 200', {
            fontSize: 12,
            fontFamily: 'Arial',
            color: '#000000'
        }).setOrigin(0, 0);
        this.oneUnitCostLabel = this.add.text(185 + this.windowX, 206 + this.windowY, '$ 2', {
            fontSize: 12,
            fontFamily: 'Arial',
            color: '#000000'
        }).setOrigin(0, 0);
        var graphics = this.add.graphics();
        graphics.fillStyle('#000000', 0.1);
        graphics.fillRoundedRect(22 + this.windowX, 101 + this.windowY, 156, 40, 4);
        graphics.fillRoundedRect(22 + this.windowX, 146 + this.windowY, 156, 40, 4);
        graphics.fillRoundedRect(22 + this.windowX, 191 + this.windowY, 156, 40, 4);
        this.wholeFamilyButton = new BigButton(this,22 + 80 + this.windowX,101 + 25 + this.windowY,gameOptions.language.wholeFamilyLbl);
        this.meFullyButton = new BigButton(this,22 + 80 + this.windowX,146 + 25 + this.windowY,gameOptions.language.meFullDoseLbl);
        this.meOneUnitButton = new BigButton(this,22 + 80 + this.windowX,191 + 25 + this.windowY,gameOptions.language.meOneUnitLbl);
        this.closeButton = new BigButton(this,40 + 80 + this.windowX,243 + 25 + this.windowY,gameOptions.language.bClose);
        this.add.existing(this.meFullyButton);
        this.add.existing(this.meOneUnitButton);
        this.add.existing(this.wholeFamilyButton);
        this.add.existing(this.closeButton);
        this.meFullyButton.setInteractive({
            useHandCursor: true
        }).on('pointerdown', this.clickedMeFully.bind(this));
        this.meOneUnitButton.setInteractive({
            useHandCursor: true
        }).on('pointerdown', this.clickedMeOneUnit.bind(this));
        this.wholeFamilyButton.setInteractive({
            useHandCursor: true
        }).on('pointerdown', this.clickedWholeFamily.bind(this));
        this.closeButton.setInteractive({
            useHandCursor: true
        }).on('pointerdown', this.clickedClose.bind(this));
        eventsCenter.emit('created-step', 'GiveMedicineInfoBox')
    }
    setContent(clinicText, costOneUnit, cost, costWholeFamily) {
        this.clinicLabel.setText(clinicText);
        this.oneUnitCostLabel.setText('$ ' + costOneUnit);
        this.costLabel.setText('$ ' + cost);
        this.wholeFamilyCostLabel.setText('$ ' + costWholeFamily);
        var mon = this.data.farmModel.getMoney();
        if ((mon >= cost) && (cost != 0)) {
            this.meFullyButton.show()
        } else {
            this.meFullyButton.hide()
        }
        if ((mon >= costWholeFamily) && (costWholeFamily != 0)) {
            this.wholeFamilyButton.show()
        } else {
            this.wholeFamilyButton.hide()
        }
        if ((mon >= costOneUnit) && (cost != 0)) {
            this.meOneUnitButton.show()
        } else {
            this.meOneUnitButton.hide()
        }
    }
    clickedMeFully() {
        eventsCenter.emit('heal-me-fully')
    }
    clickedMeOneUnit() {
        eventsCenter.emit('heal-me-one-unit')
    }
    clickedWholeFamily() {
        eventsCenter.emit('heal-whole-family')
    }
    clickedClose() {
        eventsCenter.emit('closed-give-medicine-infobox')
    }
}
export class GoToSchoolInfoBox extends ZigzagWindow {
    constructor() {
        super('GoToSchoolInfoBox')
    }
    init(data) {
        this.data = data
    }
    create() {
        this.windowX = 260;
        this.windowY = 210;
        this.createBackground(this.windowX, this.windowY, 224, 304);
        this.explanationLabel = this.add.text(18 + this.windowX, 16 + this.windowY, 'empty', {
            fontSize: 13,
            fontFamily: 'Arial',
            color: '#000000',
            wordWrap: {
                width: 180
            },
            lineSpacing: 3.5
        }).setOrigin(0, 0);
        this.schoolFee1 = this.add.text(50 + this.windowX, 158 + this.windowY, gameOptions.language.schoolFee1, {
            fontSize: 10,
            fontFamily: 'Arial',
            color: '#000000'
        }).setOrigin(0, 0);
        this.priceLabel = this.add.text(139 + this.windowX, 158 + this.windowY, '15 $', {
            fontSize: 10,
            fontFamily: 'Arial',
            color: '#000000'
        }).setOrigin(0, 0);
        this.acceptButton = new BigButton(this,35 + 80 + this.windowX,186 + 25 + this.windowY,gameOptions.language.bAccept);
        this.closeBoxButton = new BigButton(this,35 + 80 + this.windowX,237 + 25 + this.windowY,gameOptions.language.bClose);
        this.add.existing(this.acceptButton);
        this.add.existing(this.closeBoxButton);
        this.acceptButton.setInteractive({
            useHandCursor: true
        }).on('pointerdown', this.clickedAcceptSchool.bind(this));
        this.closeBoxButton.setInteractive({
            useHandCursor: true
        }).on('pointerdown', this.clickedCloseSchool.bind(this));
        eventsCenter.emit('created-step', 'GoToSchoolInfoBox')
    }
    setContent() {
        var nMessage;
        var nPrice;
        if (!this.data.farmModel.main.schoolBuilt) {
            nMessage = gameOptions.language.noSchoolNearby;
            nPrice = this.data.farmModel.main.schoolFee
        } else {
            nMessage = gameOptions.language.schoolNearby;
            nPrice = Math.round(this.data.farmModel.main.schoolFee / 2)
        }
        this.explanationLabel.setText(nMessage);
        this.priceLabel.setText(nPrice + ' $')
    }
    clickedCloseSchool() {
        eventsCenter.emit('closed-go-to-school-infobox')
    }
    clickedAcceptSchool() {
        var farmModel = this.data.farmModel;
        var fee = farmModel.main.schoolBuilt ? Math.round(farmModel.main.schoolFee / 2) : farmModel.main.schoolFee;
        if (farmModel.getMoney() >= fee) {
            farmModel.setMoney(farmModel.getMoney() - fee);
            farmModel.setPersonAtSchool(farmModel.getFamilyMemberById(farmModel.main.whichFamilyMemberActive), true);
            farmModel.main.totalSchoolCount++;
            eventsCenter.emit('accept-school')
        }
    }
}
export class HaveBabyInfoBox extends ZigzagWindow {
    constructor() {
        super('HaveBabyInfoBox')
    }
    init(data) {
        this.data = data
    }
    create() {
        this.windowX = 260;
        this.windowY = 210;
        this.createBackground(this.windowX, this.windowY, 224, 304);
        this.explanationLabel = this.add.text(18 + this.windowX, 16 + this.windowY, 'empty', {
            fontSize: 13,
            fontFamily: 'Arial',
            color: '#000000',
            wordWrap: {
                width: 180
            },
            lineSpacing: 3.5
        }).setOrigin(0, 0);
        this.closeBoxButton = new BigButton(this,35 + 80 + this.windowX,237 + 25 + this.windowY,gameOptions.language.bClose);
        this.add.existing(this.closeBoxButton);
        this.closeBoxButton.setInteractive({
            useHandCursor: true
        }).on('pointerdown', this.clickedClose.bind(this));
        eventsCenter.emit('created-step', 'HaveBabyInfoBox')
    }
    setContent(explanation) {
        this.explanationLabel.setText(explanation)
    }
    clickedClose() {
        eventsCenter.emit('closed-have-baby-infobox')
    }
}
export class LeaveFarmInfoBox extends ZigzagWindow {
    constructor() {
        super('LeaveFarmInfoBox')
    }
    init(data) {
        this.data = data
    }
    create() {
        this.windowX = 260;
        this.windowY = 210;
        this.createBackground(this.windowX, this.windowY, 224, 304);
        this.explanationLabel = this.add.text(18 + this.windowX, 16 + this.windowY, 'empty', {
            fontSize: 11,
            fontFamily: 'Arial',
            color: '#000000',
            wordWrap: {
                width: 180
            },
            lineSpacing: 3.5
        }).setOrigin(0, 0);
        this.leaveLabel = this.add.text(115 + this.windowX, 169 + this.windowY, gameOptions.language.leaveQuestion, {
            fontSize: 10,
            fontFamily: 'Arial',
            color: '#000000',
            wordWrap: {
                width: 180
            },
            textAlign: 'center',
            lineSpacing: 3.5
        }).setOrigin(0.5, 0);
        this.leaveButton = new BigButton(this,35 + 80 + this.windowX,190 + 25 + this.windowY,gameOptions.language.bLeave);
        this.stayButton = new BigButton(this,35 + 80 + this.windowX,241 + 25 + this.windowY,gameOptions.language.bStay);
        this.add.existing(this.leaveButton);
        this.add.existing(this.stayButton);
        this.leaveButton.setInteractive({
            useHandCursor: true
        }).on('pointerdown', this.clickedLeave.bind(this));
        this.stayButton.setInteractive({
            useHandCursor: true
        }).on('pointerdown', this.clickedStay.bind(this));
        eventsCenter.emit('created-step', 'LeaveFarmInfoBox')
    }
    setContent(explanation, canLeave) {
        this.explanationLabel.setText(explanation);
        if (canLeave) {
            this.leaveButton.show()
        } else {
            this.leaveButton.hide()
        }
    }
    clickedStay() {
        eventsCenter.emit('closed-leave-farm-infobox')
    }
    clickedLeave() {
        var farmModel = this.data.farmModel;
        farmModel.removeOneFamilyMember(farmModel.getFamilyMemberById(farmModel.main.whichFamilyMemberActive));
        farmModel.setMoney(farmModel.getMoney() + farmModel.main.leaveFarmReward);
        farmModel.main.newscore += farmModel.main.leaveFarmPointsAwarded;
        farmModel.main.marriageThisYear = true;
        if (farmModel.getFamilyMembers() < 1) {
            eventsCenter.emit('leave-farm-accepted');
            eventsCenter.emit('game-over')
        } else {
            eventsCenter.emit('leave-farm-accepted')
        }
    }
}
export class MarriageInfoBox extends ZigzagWindow {
    constructor() {
        super('MarriageInfoBox')
    }
    init(data) {
        this.data = data
    }
    create() {
        this.windowX = 260;
        this.windowY = 210;
        this.createBackground(this.windowX, this.windowY, 224, 304);
        this.explanationLabel = this.add.text(18 + this.windowX, 16 + this.windowY, 'empty', {
            fontSize: 12,
            fontFamily: 'Arial',
            color: '#000000',
            wordWrap: {
                width: 180
            },
            lineSpacing: 3.5
        }).setOrigin(0, 0);
        this.acceptLabel = this.add.text(115 + this.windowX, 124 + this.windowY, gameOptions.language.acceptTheProposal, {
            fontSize: 10,
            fontFamily: 'Arial',
            color: '#000000',
            wordWrap: {
                width: 180
            },
            textAlign: 'center',
            lineSpacing: 3.5
        }).setOrigin(0.5, 0);
        this.acceptButton = new BigButton(this,35 + 80 + this.windowX,139 + 25 + this.windowY,gameOptions.language.bAccept);
        this.declineButton = new BigButton(this,35 + 80 + this.windowX,190 + 25 + this.windowY,gameOptions.language.bDecline);
        this.closeButton = new BigButton(this,35 + 80 + this.windowX,241 + 25 + this.windowY,gameOptions.language.bClose);
        this.add.existing(this.acceptButton);
        this.add.existing(this.declineButton);
        this.add.existing(this.closeButton);
        this.acceptButton.setInteractive({
            useHandCursor: true
        }).on('pointerdown', this.clickedAccept.bind(this));
        this.declineButton.setInteractive({
            useHandCursor: true
        }).on('pointerdown', this.clickedDecline.bind(this));
        this.closeButton.setInteractive({
            useHandCursor: true
        }).on('pointerdown', this.clickedClose.bind(this));
        eventsCenter.emit('created-step', 'MarriageInfoBox')
    }
    setContent(explanation, proposalFound) {
        this.explanationLabel.setText(explanation);
        if (proposalFound) {
            this.acceptButton.show();
            this.declineButton.show();
            this.acceptLabel.setVisible(true)
        } else {
            this.acceptButton.hide();
            this.declineButton.hide();
            this.acceptLabel.setVisible(false)
        }
    }
    clickedAccept() {
        eventsCenter.emit('marriage-accepted')
    }
    clickedDecline() {
        eventsCenter.emit('closed-marriage-infobox')
    }
    clickedClose() {
        eventsCenter.emit('closed-marriage-infobox')
    }
}
export class NamePrompt extends ZigzagWindow {
    constructor() {
        super('NamePrompt')
    }
    preload() {
        this.load.plugin('rexinputtextplugin', 'rexinputtextplugin.min.js', true)
    }
    init(data) {
        this.data = data
    }
    create() {
        this.windowX = 960 / 2 - 308 / 2;
        this.windowY = 140;
        this.createBackground(this.windowX, this.windowY, 308, 240);
        this.createContent()
    }
    createContent() {
        this.plEnterName = this.add.text(960 / 2, 64 + this.windowY, gameOptions.language.scEnterName, {
            fontSize: 19,
            fontFamily: 'Arial',
            color: '#000000',
            textAlign: 'center',
            lineSpacing: 3.5
        }).setOrigin(0.5, 0);
        this.okayButton = new BigButton(this,75 + 80 + this.windowX,153 + 25 + this.windowY,gameOptions.language.scOkay);
        this.add.existing(this.okayButton);
        this.okayButton.setInteractive({
            useHandCursor: true
        }).on('pointerup', this.clickedSubmit.bind(this));
        this.inputText = this.add.rexInputText(43 + this.windowX, 100 + this.windowY, 232, 31, {
            type: 'text',
            text: '_',
            fontSize: '19px',
            color: '#000000',
            border: 1,
            backgroundColor: '#ffffff',
            borderColor: '#000000',
        }).setOrigin(0, 0).on('click', function(inputText) {
            console.log('On click');
            inputText.text = ''
        })
    }
    clickedSubmit() {
        eventsCenter.emit('clicked-submit-name', this.inputText.text)
    }
}
export class ProjectInfoBox extends ZigzagWindow {
    constructor() {
        super('ProjectInfoBox')
    }
    create() {
        this.windowX = 260;
        this.windowY = 215;
        this.createBackground(this.windowX, this.windowY, 224, 288);
        this.textField = this.add.text(this.windowX + 25, this.windowY + 25, '', {
            fontSize: 12,
            fontFamily: 'Arial',
            color: '#000000',
            wordWrap: {
                width: 170
            },
            lineSpacing: 3.5
        }).setOrigin(0, 0);
        this.closeButton = new BigButton(this,this.windowX + 36 + 75,this.windowY + 234 + 20,gameOptions.language.bClose);
        this.add.existing(this.closeButton);
        this.closeButton.setInteractive({
            useHandCursor: true
        }).on('pointerdown', this.closeButtonClick.bind(this));
        eventsCenter.on('update-projectinfobox', this.refreshWindow, this);
        eventsCenter.emit('created-step', 'ProjectInfoBox')
    }
    refreshWindow(s) {
        this.textField.setText(s)
    }
    closeButtonClick() {
        this.scene.sleep()
    }
}
export class SellInfoBox extends ZigzagWindow {
    constructor() {
        super('SellInfoBox')
    }
    init() {
        this.productNames = ['chicken', 'pig', 'cow', 'elephant', 'shovel', 'scythe', 'plow', 'tractor', 'well', 'shed', 'barn', 'harvester'];
        this.imageNames = ['sell_chicken', 'sell_pig', 'sell_cow', 'sell_elephant', 'sell_shovel', 'sell_scythe', 'sell_plow', 'sell_tractor', 'sell_well', 'sell_shed', 'sell_barn', 'sell_harvester']
    }
    create() {
        this.windowX = 107;
        this.windowY = 59;
        this.createBackground(this.windowX, this.windowY, 736, 432);
        eventsCenter.on('submit-sellinfo-data', this.refreshWindow, this);
        this.events.on('wake', this.requestRefreshWindowData);
        const firstX = 73;
        const firstY = 79;
        const offsetX = 215;
        const offsetY = 75;
        for (var i = 0; i < 3; i++) {
            for (var j = 0; j < 4; j++) {
                var index = (i * 4) + j;
                var s = this.productNames[index];
                var x = firstX + (i * offsetX) + this.windowX;
                var y = firstY + (j * offsetY) + this.windowY;
                this[s + 'AvailLabel'] = this.add.text(x, y, '0', {
                    fontSize: 18,
                    fontFamily: 'Arial',
                    color: '#000000'
                }).setOrigin(0, 0);
                this[s + 'Image'] = this.add.image(x + 20, y - 7, 'atlas', this.imageNames[index]).setOrigin(0, 0);
                this[s + 'DollarSign'] = this.add.text(x + 80, y, '$', {
                    fontSize: 14,
                    fontFamily: 'Arial',
                    color: '#000000'
                }).setOrigin(0, 0);
                this[s + 'PriceLabel'] = this.add.text(x + 94, y, '25', {
                    fontSize: 14,
                    fontFamily: 'Arial',
                    color: '#000000'
                }).setOrigin(0, 0);
                this[s + 'SellButton'] = this.add.sprite(x + 150, y + 10, 'sell_green_button').setInteractive({
                    useHandCursor: true
                });
                this[s + 'SellButton'].name = s;
                this[s + 'SellButton'].on('pointerdown', this.clickedSell.bind(this, this[s + 'SellButton']));
                this[s + 'SellButton'].on('pointerover', function() {
                    this.setFrame(1)
                }
                .bind(this[s + 'SellButton']));
                this[s + 'SellButton'].on('pointerout', function() {
                    this.setFrame(0)
                }
                .bind(this[s + 'SellButton']))
            }
        }
        this.cowImage.x -= 5;
        this.shovelImage.x += 10;
        this.scytheImage.x += 10;
        this.wellImage.x -= 7;
        this.barnImage.x -= 5;
        this.harvesterImage.x -= 5;
        this.instrLabel = this.add.text(this.windowX + Math.floor(736 / 2), this.windowY + 20, gameOptions.language.sellInfBoxTxt, {
            fontSize: 16,
            fontFamily: 'Arial',
            color: '#000000',
            align: 'center'
        }).setOrigin(0.5, 0);
        this.closeButton = new BigButton(this,480,450,gameOptions.language.bClose);
        this.add.existing(this.closeButton);
        this.closeButton.setInteractive({
            useHandCursor: true
        }).on('pointerdown', this.closeButtonClick.bind(this));
        eventsCenter.emit('created-step', 'SellInfoBox')
    }
    clickedSell(pointer) {
        eventsCenter.emit('sell-item', pointer.name);
        eventsCenter.emit('request-sellinfo-data')
    }
    requestRefreshWindowData() {
        eventsCenter.emit('request-sellinfo-data')
    }
    refreshWindow(arr) {
        for (var i = 0; i < 12; i++) {
            var s = this.productNames[i];
            this[s + 'AvailLabel'].setText(arr[i][0]);
            this[s + 'PriceLabel'].setText(arr[i][1]);
            this[s + 'SellButton'].setActive(arr[i][0] > 0 ? true : false).setVisible(arr[i][0] > 0 ? true : false)
        }
    }
    closeButtonClick() {
        eventsCenter.emit('close-sellinfobox')
    }
}
export class WarningBox extends ZigzagWindow {
    constructor() {
        super('WarningBox')
    }
    init(data) {
        this.data = data
    }
    create() {
        this.windowX = 60;
        this.windowY = 250;
        this.createBackground(this.windowX, this.windowY, 368, 240);
        this.explanationLabel = this.add.text(20 + this.windowX, 20 + this.windowY, gameOptions.language.lastProjectWarning, {
            fontSize: 14,
            fontFamily: 'Arial',
            color: '#000000',
            wordWrap: {
                width: 342
            },
            lineSpacing: 3.5
        }).setOrigin(0, 0);
        this.buyLabel = this.add.text(20 + this.windowX, 138 + this.windowY, gameOptions.language.buyPQuestion, {
            fontSize: 14,
            fontFamily: 'Arial',
            color: '#000000'
        }).setOrigin(0, 0);
        this.buildButton = new BigButton(this,21 + 80 + this.windowX,165 + 25 + this.windowY,gameOptions.language.bBuild);
        this.add.existing(this.buildButton);
        this.buildButton.setInteractive({
            useHandCursor: true
        }).on('pointerdown', this.clickedBuild.bind(this));
        this.closeButton = new BigButton(this,183 + 80 + this.windowX,165 + 25 + this.windowY,gameOptions.language.bDont);
        this.add.existing(this.closeButton);
        this.closeButton.setInteractive({
            useHandCursor: true
        }).on('pointerdown', this.clickedClose.bind(this));
        eventsCenter.emit('created-step', 'WarningBox')
    }
    clickedBuild() {
        eventsCenter.emit('warned-and-built')
    }
    clickedClose() {
        eventsCenter.emit('closed-warning-box')
    }
}
export class ItemDetails extends Phaser.Scene {
    constructor(scene, x, y, children) {
        super('ItemDetails')
    }
    create() {
        let x = this.data.x;
        let y = this.data.y;
        this.bg = this.add.image(x - 2, y, 'atlas', 'item-details-bg').setOrigin(0, 0);
        this.roundbg = this.add.image(x + 217, y + 21, 'atlas', 'round-button-bg').setOrigin(0, 0);
        this.itemName = this.add.text(x + 4, y + 4, 'ItemName', {
            fontSize: 12,
            fontFamily: 'Arial',
            color: '#483A24'
        });
        this.itemPrice = this.add.text(x + 201, y + 4, '$ 400', {
            fontSize: 12,
            fontFamily: 'Arial',
            color: '#483A24',
            align: 'right'
        }).setOrigin(1, 0);
        this.itemDescription = this.add.text(x + 4, y + 20, 'The item is good for this and that, and the description is this long so we can test word wrap.', {
            fontSize: 10,
            fontFamily: 'Arial',
            color: '#483A24',
            wordWrap: {
                width: 201
            }
        });
        this.itemReq = this.add.text(x + 4, y + 71, 'Needs: Representative', {
            fontSize: 9,
            fontFamily: 'Arial',
            color: '#483A24',
            wordWrap: {
                width: 201
            }
        });
        this.itemImage = this.add.image(x + 232, y + 21, 'atlas', 'crop-corn-small').setOrigin(0, 0);
        this.all = new Phaser.GameObjects.Container(this,0,0,[this.bg, this.roundbg, this.itemName, this.itemPrice, this.itemDescription, this.itemReq, this.itemImage]);
        this.add.existing(this.all);
        this.buyButton = new BigButton(this,x + 157,y + 72,gameOptions.language.bBuild);
        this.add.existing(this.buyButton);
        this.buyButton.setDimW(110);
        this.buyButton.setInteractive({
            useHandCursor: true
        });
        this.buyButton.on('pointerdown', this.handleBuyProjectButton.bind(this));
        eventsCenter.emit('created-step', 'ItemDetails')
    }
    setContent(isCrop, header, tip, req, price, imageName, isProject, canAffordProject, projectNotBuilt, pointer) {
        this.all.remove(this.itemImage, true);
        this.itemImage = this.add.image(this.data.x + 219 + pointer.x, this.data.y + 14 + pointer.y, 'atlas', imageName).setOrigin(0, 0).setDisplaySize(pointer.w, pointer.h);
        this.all.add(this.itemImage);
        if (isCrop) {
            this.moveDown()
        } else {
            this.moveUp()
        }
        this.itemName.setText(header);
        this.itemDescription.setText(tip);
        this.itemReq.setText(req);
        this.itemPrice.setText(price);
        if (isProject) {
            if (canAffordProject && projectNotBuilt) {
                this.buyButton.show();
                this.buyButton.setVisible(true).setInteractive({
                    useHandCursor: true
                })
            } else {
                this.buyButton.hide();
                this.buyButton.disableInteractive().setVisible(false)
            }
        } else {
            this.buyButton.hide();
            this.buyButton.disableInteractive().setVisible(false)
        }
    }
    moveDown() {
        this.roundbg.setY(this.data.y);
        this.itemImage.setY(this.itemImage.y - 22);
        this.all.setY(35)
    }
    moveUp() {
        this.roundbg.setY(this.data.y + 21);
        this.all.setY(0)
    }
    handleBuyProjectButton() {
        eventsCenter.emit('handle-buy-project-button')
    }
    init(data) {
        this.data = data
    }
}
export class BigButton extends Phaser.GameObjects.Container {
    constructor(scene, x, y, text) {
        super(scene, x, y);
        this.xx = x;
        this.yy = y;
        this.bg = scene.add.image(x, y, 'atlas', 'big-button-bg');
        this.tf = scene.add.text(x, y, text, {
            fontSize: 16,
            fontFamily: 'Arial',
            color: '#483A24',
            align: 'center'
        }).setOrigin(0.5, 0.7);
        this.setSize(this.bg.displayWidth, this.bg.displayHeight);
        if (this.tf.displayWidth > this.bg.displayWidth) {
            this.tf.setFontSize(12)
        }
    }
    setText(t) {
        this.tf.setText(t)
    }
    setDim(w, h) {
        this.bg.displayWidth = w;
        this.bg.displayHeight = h;
        this.tf.scaleX = this.tf.scaleY = this.bg.scaleX;
        this.setSize(this.bg.displayWidth, this.bg.displayHeight)
    }
    setDimW(w) {
        this.bg.displayWidth = w;
        this.bg.scaleY = this.tf.scaleX = this.tf.scaleY = this.bg.scaleX;
        this.setSize(this.bg.displayWidth, this.bg.displayHeight)
    }
    hide() {
        this.disableInteractive().setVisible(false);
        this.bg.disableInteractive().setVisible(false);
        this.tf.setVisible(false)
    }
    show() {
        this.setInteractive({
            useHandCursor: true
        }).setVisible(true);
        this.bg.setInteractive({
            useHandCursor: true
        }).setVisible(true);
        this.tf.setVisible(true)
    }
}
